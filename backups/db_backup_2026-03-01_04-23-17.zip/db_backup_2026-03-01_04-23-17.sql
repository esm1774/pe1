-- PE Smart School DB Backup 
-- Date: 2026-03-01 04:23:17

SET FOREIGN_KEY_CHECKS=0;



CREATE TABLE `activity_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`),
  KEY `idx_activity_log_school` (`school_id`),
  CONSTRAINT `fk_log_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=537 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `activity_log` VALUES("3","1","1","start","tournament","4",NULL,"188.49.112.189","2026-02-14 06:54:47");
INSERT INTO `activity_log` VALUES("4","1","1","match_result","match","153","1 - 0","188.49.112.189","2026-02-14 06:55:12");
INSERT INTO `activity_log` VALUES("5","1","1","match_result","match","154","1 - 0","188.49.112.189","2026-02-14 06:55:17");
INSERT INTO `activity_log` VALUES("6","1","1","match_result","match","155","0 - 1","188.49.112.189","2026-02-14 06:55:27");
INSERT INTO `activity_log` VALUES("7","1","1","match_result","match","157","0 - 1","188.49.112.189","2026-02-14 06:55:36");
INSERT INTO `activity_log` VALUES("8","1","1","complete","tournament","1",NULL,"188.49.112.189","2026-02-14 06:56:00");
INSERT INTO `activity_log` VALUES("9","1","1","create","tournament","5","تجربةي","188.49.112.189","2026-02-14 06:56:31");
INSERT INTO `activity_log` VALUES("10","1","1","add_teams","tournament","5","Added 7 classes","188.49.112.189","2026-02-14 06:56:51");
INSERT INTO `activity_log` VALUES("11","1","1","match_result","match","162","1 - 0","188.49.112.189","2026-02-14 06:57:05");
INSERT INTO `activity_log` VALUES("12","1","1","match_result","match","163","1 - 0","188.49.112.189","2026-02-14 06:57:27");
INSERT INTO `activity_log` VALUES("13","1","1","match_result","match","164","1 - 0","188.49.112.189","2026-02-14 06:57:41");
INSERT INTO `activity_log` VALUES("14","1","1","match_result","match","166","0 - 1","188.49.112.189","2026-02-14 06:58:03");
INSERT INTO `activity_log` VALUES("15","1","1","match_result","match","167","1 - 0","188.49.112.189","2026-02-14 06:58:10");
INSERT INTO `activity_log` VALUES("16","1","1","match_result","match","168","1 - 0","188.49.112.189","2026-02-14 06:58:20");
INSERT INTO `activity_log` VALUES("17","1","1","match_result","match","176","1 - 0","188.49.112.189","2026-02-14 07:06:40");
INSERT INTO `activity_log` VALUES("18","1","1","match_result","match","177","1 - 0","188.49.112.189","2026-02-14 07:06:45");
INSERT INTO `activity_log` VALUES("19","1","1","match_result","match","178","1 - 0","188.49.112.189","2026-02-14 07:06:52");
INSERT INTO `activity_log` VALUES("20","1","1","match_result","match","180","1 - 0","188.49.112.189","2026-02-14 07:07:03");
INSERT INTO `activity_log` VALUES("21","1","1","match_result","match","181","1 - 0","188.49.112.189","2026-02-14 07:07:12");
INSERT INTO `activity_log` VALUES("22","1","1","match_result","match","182","1 - 0","188.49.112.189","2026-02-14 07:07:19");
INSERT INTO `activity_log` VALUES("23","1","1","update","tournament","5",NULL,"188.49.112.189","2026-02-14 07:07:40");
INSERT INTO `activity_log` VALUES("24","1","1","match_result","match","267","1 - 0","188.49.112.189","2026-02-14 07:14:12");
INSERT INTO `activity_log` VALUES("25","1","1","match_result","match","268","1 - 0","188.49.112.189","2026-02-14 07:14:20");
INSERT INTO `activity_log` VALUES("26","1","1","match_result","match","269","1 - 0","188.49.112.189","2026-02-14 07:14:28");
INSERT INTO `activity_log` VALUES("27","1","1","match_result","match","271","1 - 0","188.49.112.189","2026-02-14 07:14:47");
INSERT INTO `activity_log` VALUES("28","1","1","match_result","match","272","1 - 0","188.49.112.189","2026-02-14 07:15:05");
INSERT INTO `activity_log` VALUES("29","1","1","match_result","match","274","1 - 0","188.49.112.189","2026-02-14 07:15:15");
INSERT INTO `activity_log` VALUES("30","1","1","match_result","match","276","1 - 0","188.49.112.189","2026-02-14 07:15:29");
INSERT INTO `activity_log` VALUES("31","1","1","match_result","match","273","1 - 0","188.49.112.189","2026-02-14 07:15:55");
INSERT INTO `activity_log` VALUES("32","1","1","match_result","match","281","1 - 0","188.49.112.189","2026-02-14 07:23:41");
INSERT INTO `activity_log` VALUES("33","1","1","match_result","match","282","1 - 0","188.49.112.189","2026-02-14 07:23:47");
INSERT INTO `activity_log` VALUES("34","1","1","match_result","match","283","1 - 0","188.49.112.189","2026-02-14 07:23:51");
INSERT INTO `activity_log` VALUES("35","1","1","match_result","match","285","1 - 0","188.49.112.189","2026-02-14 07:24:03");
INSERT INTO `activity_log` VALUES("36","1","1","match_result","match","295","1 - 0","188.49.112.189","2026-02-14 07:25:13");
INSERT INTO `activity_log` VALUES("37","1","1","match_result","match","296","1 - 0","188.49.112.189","2026-02-14 07:25:35");
INSERT INTO `activity_log` VALUES("38","1","1","match_result","match","297","1 - 0","188.49.112.189","2026-02-14 07:25:47");
INSERT INTO `activity_log` VALUES("39","1","1","match_result","match","299","1 - 0","188.49.112.189","2026-02-14 07:26:07");
INSERT INTO `activity_log` VALUES("40","1","1","login","user","1",NULL,"2a02:cb80:4144:bab1:6ce5:e2e:cbb2:6a8d","2026-02-14 17:41:16");
INSERT INTO `activity_log` VALUES("41","1","1","match_result","match","309","1 - 0","2a02:cb80:4144:bab1:6ce5:e2e:cbb2:6a8d","2026-02-14 17:41:40");
INSERT INTO `activity_log` VALUES("42","1","1","match_result","match","310","1 - 0","2a02:cb80:4144:bab1:6ce5:e2e:cbb2:6a8d","2026-02-14 17:42:02");
INSERT INTO `activity_log` VALUES("43","1","1","match_result","match","311","0 - 1","2a02:cb80:4144:bab1:6ce5:e2e:cbb2:6a8d","2026-02-14 17:43:23");
INSERT INTO `activity_log` VALUES("44","1","1","login","user","1",NULL,"2001:16a2:c091:2a5:3955:e93c:964f:afd0","2026-02-14 18:21:50");
INSERT INTO `activity_log` VALUES("45","1","1","login","user","1",NULL,"46.153.169.14","2026-02-14 19:18:55");
INSERT INTO `activity_log` VALUES("46","1","1","logout","user","1",NULL,"46.153.169.14","2026-02-14 20:13:16");
INSERT INTO `activity_log` VALUES("47","1","2","login","user","2",NULL,"46.153.169.14","2026-02-14 20:13:30");
INSERT INTO `activity_log` VALUES("48","1","1","login","user","1",NULL,"46.153.169.14","2026-02-14 20:23:51");
INSERT INTO `activity_log` VALUES("49","1","1","login","user","1",NULL,"2a02:cb80:4144:bab1:6ce5:e2e:cbb2:6a8d","2026-02-14 20:56:33");
INSERT INTO `activity_log` VALUES("50","1","1","login","user","1",NULL,"2a02:cb80:4144:bab1:6ce5:e2e:cbb2:6a8d","2026-02-14 21:40:21");
INSERT INTO `activity_log` VALUES("51","1","1","login","user","1",NULL,"2a02:cb80:4144:bab1:7986:665b:f41:ee32","2026-02-14 22:42:19");
INSERT INTO `activity_log` VALUES("52","1","1","login","user","1",NULL,"2a02:cb80:4144:bab1:7986:665b:f41:ee32","2026-02-14 22:54:12");
INSERT INTO `activity_log` VALUES("53","1","1","login","user","1",NULL,"188.49.112.189","2026-02-14 23:20:44");
INSERT INTO `activity_log` VALUES("54","1","1","logout","user","1",NULL,"188.49.112.189","2026-02-14 23:21:29");
INSERT INTO `activity_log` VALUES("55","1","1","login","user","1",NULL,"188.49.112.189","2026-02-14 23:21:37");
INSERT INTO `activity_log` VALUES("56","1","1","match_result","match","323","1 - 0","188.49.112.189","2026-02-15 00:04:40");
INSERT INTO `activity_log` VALUES("57","1","1","match_result","match","324","1 - 0","188.49.112.189","2026-02-15 00:04:53");
INSERT INTO `activity_log` VALUES("58","1","1","match_result","match","325","1 - 0","188.49.112.189","2026-02-15 00:05:10");
INSERT INTO `activity_log` VALUES("59","1","1","match_result","match","327","1 - 0","188.49.112.189","2026-02-15 00:05:20");
INSERT INTO `activity_log` VALUES("60","1","1","match_result","match","328","1 - 0","188.49.112.189","2026-02-15 00:05:33");
INSERT INTO `activity_log` VALUES("61","1","1","match_result","match","329","1 - 0","188.49.112.189","2026-02-15 00:05:49");
INSERT INTO `activity_log` VALUES("62","1","1","match_result","match","353","0 - 1","188.49.112.189","2026-02-15 00:08:53");
INSERT INTO `activity_log` VALUES("63","1","1","match_result","match","368","0 - 1","188.49.112.189","2026-02-15 00:12:05");
INSERT INTO `activity_log` VALUES("64","1","1","update","tournament","5",NULL,"188.49.112.189","2026-02-15 00:22:02");
INSERT INTO `activity_log` VALUES("65","1","1","match_result","match","396","1 - 0","188.49.112.189","2026-02-15 00:22:34");
INSERT INTO `activity_log` VALUES("66","1","1","update","tournament","5",NULL,"188.49.112.189","2026-02-15 00:24:16");
INSERT INTO `activity_log` VALUES("67","1","1","update","tournament","5",NULL,"188.49.112.189","2026-02-15 00:25:07");
INSERT INTO `activity_log` VALUES("68","1","1","update","tournament","5",NULL,"188.49.112.189","2026-02-15 00:36:25");
INSERT INTO `activity_log` VALUES("69","1","1","match_result","match","439","1 - 0","188.49.112.189","2026-02-15 00:36:42");
INSERT INTO `activity_log` VALUES("70","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 07:41:03");
INSERT INTO `activity_log` VALUES("71","1","1","save_fitness","student_fitness","1","Records: 3","46.153.169.14","2026-02-15 07:43:29");
INSERT INTO `activity_log` VALUES("72","1","1","update","tournament","5",NULL,"46.153.169.14","2026-02-15 07:44:04");
INSERT INTO `activity_log` VALUES("73","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 08:44:12");
INSERT INTO `activity_log` VALUES("74","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 08:45:23");
INSERT INTO `activity_log` VALUES("75","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 09:28:34");
INSERT INTO `activity_log` VALUES("76","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 09:38:00");
INSERT INTO `activity_log` VALUES("77","1","1","logout","user","1",NULL,"46.153.169.14","2026-02-15 09:45:48");
INSERT INTO `activity_log` VALUES("78","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 09:45:56");
INSERT INTO `activity_log` VALUES("79","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 09:53:39");
INSERT INTO `activity_log` VALUES("80","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 09:54:26");
INSERT INTO `activity_log` VALUES("81","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 10:03:31");
INSERT INTO `activity_log` VALUES("82","1","1","update","tournament","5",NULL,"46.153.169.14","2026-02-15 10:38:13");
INSERT INTO `activity_log` VALUES("83","1","1","update","tournament","5",NULL,"46.153.169.14","2026-02-15 10:41:58");
INSERT INTO `activity_log` VALUES("84","1","1","add_teams","tournament","5","Added 7 classes","46.153.169.14","2026-02-15 10:43:39");
INSERT INTO `activity_log` VALUES("85","1","1","start","tournament","5",NULL,"46.153.169.14","2026-02-15 10:43:57");
INSERT INTO `activity_log` VALUES("86","1","1","match_result","match","518","1 - 0","46.153.169.14","2026-02-15 10:44:07");
INSERT INTO `activity_log` VALUES("87","1","1","match_result","match","519","0 - 1","46.153.169.14","2026-02-15 10:44:22");
INSERT INTO `activity_log` VALUES("88","1","1","match_result","match","520","1 - 0","46.153.169.14","2026-02-15 10:44:36");
INSERT INTO `activity_log` VALUES("89","1","1","match_result","match","522","1 - 0","46.153.169.14","2026-02-15 10:45:13");
INSERT INTO `activity_log` VALUES("90","1","1","match_result","match","523","1 - 0","46.153.169.14","2026-02-15 10:45:18");
INSERT INTO `activity_log` VALUES("91","1","1","match_result","match","524","1 - 0","46.153.169.14","2026-02-15 10:45:26");
INSERT INTO `activity_log` VALUES("92","1","1","create","tournament","6","تجربة خروج المغلوب من مباراتين","46.153.169.14","2026-02-15 10:46:48");
INSERT INTO `activity_log` VALUES("93","1","1","add_teams","tournament","6","Added 7 classes","46.153.169.14","2026-02-15 10:46:59");
INSERT INTO `activity_log` VALUES("94","1","1","start","tournament","6",NULL,"46.153.169.14","2026-02-15 10:55:29");
INSERT INTO `activity_log` VALUES("95","1","1","match_result","match","539","1 - 2","46.153.169.14","2026-02-15 10:55:40");
INSERT INTO `activity_log` VALUES("96","1","1","match_result","match","540","1 - 0","46.153.169.14","2026-02-15 10:56:24");
INSERT INTO `activity_log` VALUES("97","1","1","match_result","match","541","1 - 0","46.153.169.14","2026-02-15 10:56:30");
INSERT INTO `activity_log` VALUES("98","1","1","match_result","match","543","1 - 0","46.153.169.14","2026-02-15 10:56:55");
INSERT INTO `activity_log` VALUES("99","1","1","match_result","match","544","1 - 0","46.153.169.14","2026-02-15 10:57:01");
INSERT INTO `activity_log` VALUES("100","1","1","match_result","match","545","1 - 0","46.153.169.14","2026-02-15 10:57:17");
INSERT INTO `activity_log` VALUES("101","1","1","create","tournament","7","بطولة خروج المغلوب من مرتين تجربة (2)","46.153.169.14","2026-02-15 11:40:08");
INSERT INTO `activity_log` VALUES("102","1","1","add_teams","tournament","7","Added 7 classes","46.153.169.14","2026-02-15 11:40:15");
INSERT INTO `activity_log` VALUES("103","1","1","start","tournament","7",NULL,"46.153.169.14","2026-02-15 11:42:18");
INSERT INTO `activity_log` VALUES("104","1","1","match_result","match","553","1 - 0","46.153.169.14","2026-02-15 11:42:22");
INSERT INTO `activity_log` VALUES("105","1","1","match_result","match","554","1 - 0","46.153.169.14","2026-02-15 11:42:46");
INSERT INTO `activity_log` VALUES("106","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 11:49:24");
INSERT INTO `activity_log` VALUES("107","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 11:54:04");
INSERT INTO `activity_log` VALUES("108","1","1","login","user","1",NULL,"46.153.169.14","2026-02-15 12:49:35");
INSERT INTO `activity_log` VALUES("109","1","1","delete","class","3",NULL,"46.153.169.14","2026-02-15 13:21:53");
INSERT INTO `activity_log` VALUES("110","1","1","update","class","8","3/3","46.153.169.14","2026-02-15 13:22:05");
INSERT INTO `activity_log` VALUES("111","1","1","update","class","9","2/3","46.153.169.14","2026-02-15 13:22:13");
INSERT INTO `activity_log` VALUES("112","1","1","delete","student","10",NULL,"46.153.169.14","2026-02-15 13:22:23");
INSERT INTO `activity_log` VALUES("113","1","1","delete","student","9",NULL,"46.153.169.14","2026-02-15 13:22:27");
INSERT INTO `activity_log` VALUES("114","1","1","delete","student","2",NULL,"46.153.169.14","2026-02-15 13:22:29");
INSERT INTO `activity_log` VALUES("115","1","1","delete","student","40",NULL,"46.153.169.14","2026-02-15 13:22:32");
INSERT INTO `activity_log` VALUES("116","1","1","delete","student","31",NULL,"46.153.169.14","2026-02-15 13:22:34");
INSERT INTO `activity_log` VALUES("117","1","1","delete","student","17",NULL,"46.153.169.14","2026-02-15 13:22:37");
INSERT INTO `activity_log` VALUES("118","1","1","login","user","1",NULL,"2a02:cb80:4072:6cdb:9854:9206:906e:1a05","2026-02-15 18:58:35");
INSERT INTO `activity_log` VALUES("119","1","1","login","user","1",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 19:09:00");
INSERT INTO `activity_log` VALUES("120","1","1","import_students","students",NULL,"Imported: 118, Updated: 0, Skipped: 0","2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:34:00");
INSERT INTO `activity_log` VALUES("121","1","1","logout","user","1",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:40:01");
INSERT INTO `activity_log` VALUES("122","1","2","login","user","2",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:40:11");
INSERT INTO `activity_log` VALUES("123","1","2","logout","user","2",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:42:12");
INSERT INTO `activity_log` VALUES("124","1","1","login","user","1",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:42:19");
INSERT INTO `activity_log` VALUES("125","1","1","update","user","2","إسماعيل البساوي","2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:42:40");
INSERT INTO `activity_log` VALUES("126","1","1","update","user","3","مدير المدرسة","2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:43:04");
INSERT INTO `activity_log` VALUES("127","1","1","logout","user","1",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:43:19");
INSERT INTO `activity_log` VALUES("128","1","3","login","user","3",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 20:43:27");
INSERT INTO `activity_log` VALUES("129","1","3","logout","user","3",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 21:40:18");
INSERT INTO `activity_log` VALUES("130","1","2","login","user","2",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 21:40:33");
INSERT INTO `activity_log` VALUES("131","1","2","logout","user","2",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 22:01:13");
INSERT INTO `activity_log` VALUES("132","1","1","login","user","1",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 22:01:17");
INSERT INTO `activity_log` VALUES("133","1","1","update","user","4","أيمن محمد","2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 22:01:56");
INSERT INTO `activity_log` VALUES("134","1","1","logout","user","1",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 22:02:19");
INSERT INTO `activity_log` VALUES("135","1","4","login","user","4",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 22:02:34");
INSERT INTO `activity_log` VALUES("136","1","1","login","user","1",NULL,"2a02:cb80:4072:6cdb:991a:5957:35ed:5e27","2026-02-15 22:36:50");
INSERT INTO `activity_log` VALUES("137","1","1","login","user","1",NULL,"46.153.169.14","2026-02-16 06:50:26");
INSERT INTO `activity_log` VALUES("138","1","1","save_attendance","attendance",NULL,"Date: 2026-02-16, Records: 22","46.153.169.14","2026-02-16 06:51:54");
INSERT INTO `activity_log` VALUES("139","1","1","login","user","1",NULL,"46.153.169.14","2026-02-16 08:58:18");
INSERT INTO `activity_log` VALUES("140","1","1","login","user","1",NULL,"2001:16a4:19:aa65:cc52:5dd0:bac7:1096","2026-02-18 12:26:17");
INSERT INTO `activity_log` VALUES("141","1","1","login","user","1",NULL,"::1","2026-02-20 22:38:13");
INSERT INTO `activity_log` VALUES("142","1","1","login","user","1",NULL,"::1","2026-02-20 22:38:45");
INSERT INTO `activity_log` VALUES("143","1","1","create","tournament","8","تجربة خروج المغلوب من مرتين","::1","2026-02-20 23:03:11");
INSERT INTO `activity_log` VALUES("144","1","1","add_teams","tournament","8","Added 8 classes","::1","2026-02-20 23:03:29");
INSERT INTO `activity_log` VALUES("145","1","1","login","user","1",NULL,"::1","2026-02-20 23:10:29");
INSERT INTO `activity_log` VALUES("146","1","1","create","tournament","9","Test Double Elimination","::1","2026-02-20 23:11:26");
INSERT INTO `activity_log` VALUES("147","1","1","update","tournament","9",NULL,"::1","2026-02-20 23:15:59");
INSERT INTO `activity_log` VALUES("148","1","1","match_result","match","555","2 - 0","::1","2026-02-20 23:31:21");
INSERT INTO `activity_log` VALUES("149","1","1","create","tournament","10","Final Test DE","::1","2026-02-20 23:39:49");
INSERT INTO `activity_log` VALUES("150","1","1","create","tournament","11","New DE Test","::1","2026-02-20 23:47:35");
INSERT INTO `activity_log` VALUES("151","1","1","start","tournament","9",NULL,"::1","2026-02-21 00:01:42");
INSERT INTO `activity_log` VALUES("152","1","1","match_result","match","581","1 - 0","::1","2026-02-21 00:01:48");
INSERT INTO `activity_log` VALUES("153","1","1","match_result","match","582","1 - 0","::1","2026-02-21 00:01:52");
INSERT INTO `activity_log` VALUES("154","1","1","match_result","match","584","1 - 0","::1","2026-02-21 00:02:21");
INSERT INTO `activity_log` VALUES("155","1","1","match_result","match","583","1 - 0","::1","2026-02-21 00:02:43");
INSERT INTO `activity_log` VALUES("156","1","1","match_result","match","585","0 - 1","::1","2026-02-21 00:03:15");
INSERT INTO `activity_log` VALUES("157","1","1","match_result","match","586","0 - 1","::1","2026-02-21 00:04:00");
INSERT INTO `activity_log` VALUES("158","1","1","match_result","match","587","0 - 1","::1","2026-02-21 00:04:19");
INSERT INTO `activity_log` VALUES("159","1","1","create","tournament","12","Double Elimination Test","::1","2026-02-21 00:14:54");
INSERT INTO `activity_log` VALUES("160","1","1","delete","tournament","12",NULL,"::1","2026-02-21 00:34:43");
INSERT INTO `activity_log` VALUES("161","1","1","logout","user","1",NULL,"::1","2026-02-21 00:59:24");
INSERT INTO `activity_log` VALUES("162","1","1","login","user","1",NULL,"::1","2026-02-21 00:59:58");
INSERT INTO `activity_log` VALUES("163","1","1","create","sports_team","1","فصل ١ / ١","::1","2026-02-21 01:09:21");
INSERT INTO `activity_log` VALUES("164","1","1","create","sports_team","2","منتخب كرة القدم بالمدرسة","::1","2026-02-21 01:11:40");
INSERT INTO `activity_log` VALUES("165","1","1","lottery_create","sports_team","3","فريق البراكين","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("166","1","1","lottery_create","sports_team","4","فريق الدروع","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("167","1","1","lottery_create","sports_team","5","فريق الأسود","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("168","1","1","lottery_create","sports_team","6","فريق النسور","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("169","1","1","lottery_create","sports_team","7","فريق الثيران","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("170","1","1","lottery_create","sports_team","8","فريق النمور","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("171","1","1","lottery_create","sports_team","9","فريق السيوف","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("172","1","1","lottery_create","sports_team","10","فريق الصقور","::1","2026-02-21 01:41:17");
INSERT INTO `activity_log` VALUES("173","1","1","create","tournament","13","تجربة خروج المغلوب من مرتين","::1","2026-02-21 01:41:59");
INSERT INTO `activity_log` VALUES("174","1","1","delete","sports_team","5",NULL,"::1","2026-02-21 01:43:11");
INSERT INTO `activity_log` VALUES("175","1","1","delete","sports_team","3",NULL,"::1","2026-02-21 01:43:18");
INSERT INTO `activity_log` VALUES("176","1","1","delete","sports_team","7",NULL,"::1","2026-02-21 01:43:23");
INSERT INTO `activity_log` VALUES("177","1","1","update","sports_team","4","فريق الأشبال","::1","2026-02-21 01:43:38");
INSERT INTO `activity_log` VALUES("178","1","1","delete","sports_team","4",NULL,"::1","2026-02-21 01:43:44");
INSERT INTO `activity_log` VALUES("179","1","1","delete","sports_team","9",NULL,"::1","2026-02-21 01:43:51");
INSERT INTO `activity_log` VALUES("180","1","1","delete","sports_team","10",NULL,"::1","2026-02-21 01:43:56");
INSERT INTO `activity_log` VALUES("181","1","1","delete","sports_team","8",NULL,"::1","2026-02-21 01:44:01");
INSERT INTO `activity_log` VALUES("182","1","1","logout","user","1",NULL,"::1","2026-02-21 02:22:22");
INSERT INTO `activity_log` VALUES("183","1","2","login","user","2",NULL,"::1","2026-02-21 02:22:43");
INSERT INTO `activity_log` VALUES("184","1","1","logout","user","1",NULL,"::1","2026-02-21 02:25:08");
INSERT INTO `activity_log` VALUES("185","1","2","login","user","2",NULL,"::1","2026-02-21 02:25:22");
INSERT INTO `activity_log` VALUES("186","1","2","logout","user","2",NULL,"::1","2026-02-21 02:25:49");
INSERT INTO `activity_log` VALUES("187","1","1","login","user","1",NULL,"::1","2026-02-21 02:25:53");
INSERT INTO `activity_log` VALUES("188","1","1","login","user","1",NULL,"::1","2026-02-21 02:30:30");
INSERT INTO `activity_log` VALUES("189","1","1","delete","tournament","10",NULL,"::1","2026-02-21 02:35:38");
INSERT INTO `activity_log` VALUES("190","1","1","delete","tournament","11",NULL,"::1","2026-02-21 02:35:47");
INSERT INTO `activity_log` VALUES("191","1","1","update","user","8","Test","::1","2026-02-21 02:36:38");
INSERT INTO `activity_log` VALUES("192","1","1","login","user","1",NULL,"127.0.0.1","2026-02-21 02:50:33");
INSERT INTO `activity_log` VALUES("193","1","1","logout","user","1",NULL,"::1","2026-02-21 02:51:16");
INSERT INTO `activity_log` VALUES("194","1","1","login","user","1",NULL,"::1","2026-02-21 02:51:28");
INSERT INTO `activity_log` VALUES("195","1","1","update","class","10","1/4","127.0.0.1","2026-02-21 02:58:53");
INSERT INTO `activity_log` VALUES("196","1","1","logout","user","1",NULL,"::1","2026-02-21 03:05:31");
INSERT INTO `activity_log` VALUES("197","1","1","login","user","1",NULL,"::1","2026-02-21 03:05:39");
INSERT INTO `activity_log` VALUES("198","1","1","logout","user","1",NULL,"::1","2026-02-21 03:05:45");
INSERT INTO `activity_log` VALUES("199","1","1","login","user","1",NULL,"::1","2026-02-21 03:07:27");
INSERT INTO `activity_log` VALUES("200","1","1","unassign_class","teacher_classes","2","Class: 8","::1","2026-02-21 03:09:09");
INSERT INTO `activity_log` VALUES("201","1","1","unassign_class","teacher_classes","2","Class: 7","::1","2026-02-21 03:09:12");
INSERT INTO `activity_log` VALUES("202","1","1","unassign_class","teacher_classes","2","Class: 6","::1","2026-02-21 03:09:15");
INSERT INTO `activity_log` VALUES("203","1","1","assign_class","teacher_classes","4","Class: 6, Temp: 0","::1","2026-02-21 03:09:48");
INSERT INTO `activity_log` VALUES("204","1","1","assign_class","teacher_classes","4","Class: 7, Temp: 0","::1","2026-02-21 03:09:53");
INSERT INTO `activity_log` VALUES("205","1","1","assign_class","teacher_classes","4","Class: 8, Temp: 0","::1","2026-02-21 03:09:56");
INSERT INTO `activity_log` VALUES("206","1","1","assign_class","teacher_classes","8","Class: 1, Temp: 0","::1","2026-02-21 03:10:12");
INSERT INTO `activity_log` VALUES("207","1","1","logout","user","1",NULL,"::1","2026-02-21 03:10:56");
INSERT INTO `activity_log` VALUES("208","1","2","login","user","2",NULL,"::1","2026-02-21 03:11:15");
INSERT INTO `activity_log` VALUES("209","1","2","logout","user","2",NULL,"::1","2026-02-21 03:12:35");
INSERT INTO `activity_log` VALUES("210","1","1","login","user","1",NULL,"::1","2026-02-21 03:12:44");
INSERT INTO `activity_log` VALUES("211","1","1","logout","user","1",NULL,"::1","2026-02-21 03:23:52");
INSERT INTO `activity_log` VALUES("212","1","1","logout","user","1",NULL,"::1","2026-02-21 03:24:08");
INSERT INTO `activity_log` VALUES("213","1","2","login","user","2",NULL,"::1","2026-02-21 03:24:26");
INSERT INTO `activity_log` VALUES("214","1","1","login","user","1",NULL,"::1","2026-02-21 03:24:35");
INSERT INTO `activity_log` VALUES("215","1","1","update","user","9","Supervisor Test","::1","2026-02-21 03:29:08");
INSERT INTO `activity_log` VALUES("216","1","1","logout","user","1",NULL,"::1","2026-02-21 03:32:42");
INSERT INTO `activity_log` VALUES("217","1",NULL,"login_failed","user",NULL,"Username: testusersuper1","::1","2026-02-21 03:33:17");
INSERT INTO `activity_log` VALUES("218","1",NULL,"login_failed","user",NULL,"Username: testusersuper1admin","::1","2026-02-21 03:33:54");
INSERT INTO `activity_log` VALUES("219","1",NULL,"login_failed","user",NULL,"Username: testusersuper1adminadmin","::1","2026-02-21 03:34:44");
INSERT INTO `activity_log` VALUES("220","1","1","login","user","1",NULL,"::1","2026-02-21 03:35:14");
INSERT INTO `activity_log` VALUES("221","1","1","update","user","10","Marwan Supervisor","::1","2026-02-21 03:37:40");
INSERT INTO `activity_log` VALUES("222","1","1","update","user","10","Marwan Supervisor","::1","2026-02-21 03:38:22");
INSERT INTO `activity_log` VALUES("223","1","2","update_profile","user","2",NULL,"::1","2026-02-21 03:44:42");
INSERT INTO `activity_log` VALUES("224","1","2","update_profile","user","2",NULL,"::1","2026-02-21 03:45:01");
INSERT INTO `activity_log` VALUES("225","1","2","logout","user","2",NULL,"::1","2026-02-21 03:46:17");
INSERT INTO `activity_log` VALUES("226","1","1","login","user","1",NULL,"::1","2026-02-21 03:46:27");
INSERT INTO `activity_log` VALUES("227","1","1","delete","class","10",NULL,"::1","2026-02-21 03:46:36");
INSERT INTO `activity_log` VALUES("228","1","1","update_profile","user","1",NULL,"::1","2026-02-21 03:47:37");
INSERT INTO `activity_log` VALUES("229","1","1","update","user","9","Supervisor Test","::1","2026-02-21 03:48:08");
INSERT INTO `activity_log` VALUES("230","1","1","delete","user","10",NULL,"::1","2026-02-21 03:48:30");
INSERT INTO `activity_log` VALUES("231","1","1","logout","user","1",NULL,"::1","2026-02-21 04:59:05");
INSERT INTO `activity_log` VALUES("232","1","1","login","user","1",NULL,"::1","2026-02-21 04:59:23");
INSERT INTO `activity_log` VALUES("233","1","1","login","user","1",NULL,"127.0.0.1","2026-02-21 05:19:10");
INSERT INTO `activity_log` VALUES("234","1","1","logout","user","1",NULL,"127.0.0.1","2026-02-21 05:21:08");
INSERT INTO `activity_log` VALUES("235","1",NULL,"login_failed","user",NULL,"Username: 1146521727","127.0.0.1","2026-02-21 05:21:31");
INSERT INTO `activity_log` VALUES("236","1",NULL,"login_failed","user",NULL,"Username: admin123","127.0.0.1","2026-02-21 05:21:56");
INSERT INTO `activity_log` VALUES("237","1","1","login","user","1",NULL,"127.0.0.1","2026-02-21 05:22:22");
INSERT INTO `activity_log` VALUES("238","1","1","logout","user","1",NULL,"127.0.0.1","2026-02-21 05:29:29");
INSERT INTO `activity_log` VALUES("239","1",NULL,"login_failed","user",NULL,"Username: 1146521727","127.0.0.1","2026-02-21 05:30:02");
INSERT INTO `activity_log` VALUES("240","1","1","logout","user","1",NULL,"::1","2026-02-21 05:32:41");
INSERT INTO `activity_log` VALUES("241","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:32:59");
INSERT INTO `activity_log` VALUES("242","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:33:06");
INSERT INTO `activity_log` VALUES("243","1","1","login","user","1",NULL,"127.0.0.1","2026-02-21 05:33:22");
INSERT INTO `activity_log` VALUES("244","1","1","login","user","1",NULL,"::1","2026-02-21 05:34:34");
INSERT INTO `activity_log` VALUES("245","1","1","logout","user","1",NULL,"127.0.0.1","2026-02-21 05:35:48");
INSERT INTO `activity_log` VALUES("246","1","1","logout","user","1",NULL,"::1","2026-02-21 05:36:00");
INSERT INTO `activity_log` VALUES("247","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:36:10");
INSERT INTO `activity_log` VALUES("248","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:36:19");
INSERT INTO `activity_log` VALUES("249","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:36:21");
INSERT INTO `activity_log` VALUES("250","1",NULL,"login_failed","user",NULL,"Username: 1146521727","127.0.0.1","2026-02-21 05:36:39");
INSERT INTO `activity_log` VALUES("251","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:37:30");
INSERT INTO `activity_log` VALUES("252","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:37:33");
INSERT INTO `activity_log` VALUES("253","1","1","login","user","1",NULL,"127.0.0.1","2026-02-21 05:37:34");
INSERT INTO `activity_log` VALUES("254","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:38:15");
INSERT INTO `activity_log` VALUES("255","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:38:17");
INSERT INTO `activity_log` VALUES("256","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:38:25");
INSERT INTO `activity_log` VALUES("257","1",NULL,"login_failed","user",NULL,"Username: 1002","::1","2026-02-21 05:38:47");
INSERT INTO `activity_log` VALUES("258","1",NULL,"login_failed","user",NULL,"Username: 1001","::1","2026-02-21 05:38:52");
INSERT INTO `activity_log` VALUES("259","1",NULL,"login_failed","user",NULL,"Username: 1146521727","::1","2026-02-21 05:40:07");
INSERT INTO `activity_log` VALUES("260","1",NULL,"login_failed","user",NULL,"Username: 1146521727","::1","2026-02-21 05:40:59");
INSERT INTO `activity_log` VALUES("261","1",NULL,"login_failed","user",NULL,"Username: 1146521727","::1","2026-02-21 05:41:02");
INSERT INTO `activity_log` VALUES("262","1",NULL,"login_failed","user",NULL,"Username: 1146521727","::1","2026-02-21 05:41:25");
INSERT INTO `activity_log` VALUES("263","1","1","logout","user","1",NULL,"127.0.0.1","2026-02-21 05:41:54");
INSERT INTO `activity_log` VALUES("264","1",NULL,"login_failed","user",NULL,"Username: 1146521727","127.0.0.1","2026-02-21 05:42:49");
INSERT INTO `activity_log` VALUES("265","1",NULL,"login_failed","user",NULL,"Username: 1146521727","127.0.0.1","2026-02-21 05:45:13");
INSERT INTO `activity_log` VALUES("271","1","1","login","user","1",NULL,"127.0.0.1","2026-02-21 05:48:28");
INSERT INTO `activity_log` VALUES("272","1","1","logout","user","1",NULL,"::1","2026-02-21 05:54:47");
INSERT INTO `activity_log` VALUES("286","1","1","login","user","1",NULL,"::1","2026-02-21 06:25:04");
INSERT INTO `activity_log` VALUES("287","1",NULL,"logout","user",NULL,NULL,"::1","2026-02-21 10:24:21");
INSERT INTO `activity_log` VALUES("288","1",NULL,"login_failed","auth",NULL,"Input: 1001","::1","2026-02-21 10:24:32");
INSERT INTO `activity_log` VALUES("289","1",NULL,"login_failed","auth",NULL,"Input: 1001","::1","2026-02-21 10:24:37");
INSERT INTO `activity_log` VALUES("290","1",NULL,"login_failed","auth",NULL,"Input: 1001","::1","2026-02-21 10:24:41");
INSERT INTO `activity_log` VALUES("291","1",NULL,"login_failed","auth",NULL,"Input: 1006","::1","2026-02-21 10:25:02");
INSERT INTO `activity_log` VALUES("292","1",NULL,"login_failed","auth",NULL,"Input: 1006","::1","2026-02-21 10:25:10");
INSERT INTO `activity_log` VALUES("293","1",NULL,"login_failed","auth",NULL,"Input: 1011","::1","2026-02-21 10:26:19");
INSERT INTO `activity_log` VALUES("294","1",NULL,"login_failed","auth",NULL,"Input: 1011","::1","2026-02-21 10:26:25");
INSERT INTO `activity_log` VALUES("295","1","1","login","user","1",NULL,"::1","2026-02-21 10:26:37");
INSERT INTO `activity_log` VALUES("296","1","1","logout","user","1",NULL,"::1","2026-02-21 10:27:21");
INSERT INTO `activity_log` VALUES("299","1",NULL,"logout","user",NULL,NULL,"::1","2026-02-21 13:27:15");
INSERT INTO `activity_log` VALUES("300","1",NULL,"login_failed","auth",NULL,"Input: 1001","::1","2026-02-21 13:27:29");
INSERT INTO `activity_log` VALUES("301","1",NULL,"login_failed","auth",NULL,"Input: 1018","::1","2026-02-21 13:27:36");
INSERT INTO `activity_log` VALUES("302","1",NULL,"login_failed","auth",NULL,"Input: 1018","::1","2026-02-21 13:27:38");
INSERT INTO `activity_log` VALUES("303","1",NULL,"login_failed","auth",NULL,"Input: 1018","::1","2026-02-21 13:27:40");
INSERT INTO `activity_log` VALUES("304","1",NULL,"login_failed","auth",NULL,"Input: 1018","::1","2026-02-21 13:27:49");
INSERT INTO `activity_log` VALUES("305","1","1","login","user","1",NULL,"::1","2026-02-21 13:28:16");
INSERT INTO `activity_log` VALUES("306","1","1","import_students","students",NULL,"Imported: 0, Updated: 2, Skipped: 1","::1","2026-02-21 13:32:45");
INSERT INTO `activity_log` VALUES("307","1","1","import_students","students",NULL,"Imported: 0, Updated: 2, Skipped: 1","::1","2026-02-21 13:51:09");
INSERT INTO `activity_log` VALUES("308","1","1","import_students","students",NULL,"Imported: 0, Updated: 2, Skipped: 1","::1","2026-02-21 13:51:30");
INSERT INTO `activity_log` VALUES("309","1","1","import_students","students",NULL,"Imported: 0, Updated: 152, Skipped: 7","::1","2026-02-21 13:56:36");
INSERT INTO `activity_log` VALUES("310","1","1","login_failed","auth",NULL,"Input: 1018","::1","2026-02-21 13:59:51");
INSERT INTO `activity_log` VALUES("311","1","1","login_failed","auth",NULL,"Input: 1153670979","::1","2026-02-21 14:00:08");
INSERT INTO `activity_log` VALUES("312","1","1","login_failed","auth",NULL,"Input: 1153670979","::1","2026-02-21 14:00:10");
INSERT INTO `activity_log` VALUES("313","1","1","login_failed","auth",NULL,"Input: 1153670979","::1","2026-02-21 14:00:11");
INSERT INTO `activity_log` VALUES("314","1","1","login_failed","auth",NULL,"Input: adim","::1","2026-02-21 14:00:33");
INSERT INTO `activity_log` VALUES("315","1","1","login_failed","auth",NULL,"Input: adim","::1","2026-02-21 14:00:35");
INSERT INTO `activity_log` VALUES("316","1","1","login_failed","auth",NULL,"Input: adim","::1","2026-02-21 14:00:36");
INSERT INTO `activity_log` VALUES("317","1","1","login","user","1",NULL,"::1","2026-02-21 14:00:45");
INSERT INTO `activity_log` VALUES("318","1",NULL,"login_failed","auth",NULL,"Input: 1153670979","::1","2026-02-21 14:02:08");
INSERT INTO `activity_log` VALUES("321","1",NULL,"login_failed","auth",NULL,"Input: 1001","::1","2026-02-21 14:03:56");
INSERT INTO `activity_log` VALUES("322","1","1","import_students","students",NULL,"Imported: 0, Updated: 2, Skipped: 1","::1","2026-02-21 14:06:20");
INSERT INTO `activity_log` VALUES("323","1","1","import_students","students",NULL,"Imported: 0, Updated: 2, Skipped: 1","::1","2026-02-21 14:09:34");
INSERT INTO `activity_log` VALUES("324","1","1","import_students","students",NULL,"Imported: 0, Updated: 3, Skipped: 0","::1","2026-02-21 14:11:52");
INSERT INTO `activity_log` VALUES("325","1",NULL,"login_failed","auth",NULL,"Input: 1002","::1","2026-02-21 14:12:31");
INSERT INTO `activity_log` VALUES("326","1",NULL,"login_failed","auth",NULL,"Input: 1002","::1","2026-02-21 14:12:33");
INSERT INTO `activity_log` VALUES("327","1","2","student_login","student","2",NULL,"::1","2026-02-21 14:17:55");
INSERT INTO `activity_log` VALUES("328","1","1","logout","user","1",NULL,"::1","2026-02-21 14:35:36");
INSERT INTO `activity_log` VALUES("329","1","1","login","user","1",NULL,"::1","2026-02-21 14:35:46");
INSERT INTO `activity_log` VALUES("330","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 14:38:06");
INSERT INTO `activity_log` VALUES("331","1","2","logout","user","2",NULL,"::1","2026-02-21 14:38:33");
INSERT INTO `activity_log` VALUES("332","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 14:38:52");
INSERT INTO `activity_log` VALUES("333","1",NULL,"login","user","12",NULL,"::1","2026-02-21 14:38:59");
INSERT INTO `activity_log` VALUES("334","1",NULL,"login","user","12",NULL,"::1","2026-02-21 14:39:06");
INSERT INTO `activity_log` VALUES("335","1",NULL,"login","user","13",NULL,"::1","2026-02-21 14:44:45");
INSERT INTO `activity_log` VALUES("336","1",NULL,"login","user","13",NULL,"::1","2026-02-21 14:45:21");
INSERT INTO `activity_log` VALUES("337","1","1","parent_login","parent","1",NULL,"::1","2026-02-21 15:07:40");
INSERT INTO `activity_log` VALUES("338","1","1","logout","user","1",NULL,"::1","2026-02-21 15:13:44");
INSERT INTO `activity_log` VALUES("339","1","1","login","user","1",NULL,"::1","2026-02-21 15:14:16");
INSERT INTO `activity_log` VALUES("340","1","1","login","user","1",NULL,"::1","2026-02-21 15:25:12");
INSERT INTO `activity_log` VALUES("341","1","1","login","user","1",NULL,"::1","2026-02-21 15:27:16");
INSERT INTO `activity_log` VALUES("342","1","1","login","user","1",NULL,"::1","2026-02-21 15:29:44");
INSERT INTO `activity_log` VALUES("343","1","1","login","user","1",NULL,"::1","2026-02-21 15:34:52");
INSERT INTO `activity_log` VALUES("344","1","1","login","user","1",NULL,"::1","2026-02-21 15:35:32");
INSERT INTO `activity_log` VALUES("345","1","1","login","user","1",NULL,"::1","2026-02-21 16:18:42");
INSERT INTO `activity_log` VALUES("346","1","2","login","user","2",NULL,"::1","2026-02-21 16:19:02");
INSERT INTO `activity_log` VALUES("347","1","1","login","user","1",NULL,"::1","2026-02-21 16:20:55");
INSERT INTO `activity_log` VALUES("348","1","1","login","user","1",NULL,"::1","2026-02-21 16:22:07");
INSERT INTO `activity_log` VALUES("349","1","1","login_failed","auth",NULL,"Input: parent_testadmin","::1","2026-02-21 16:24:04");
INSERT INTO `activity_log` VALUES("350","1","1","login_failed","auth",NULL,"Input: adminparent_testadmin","::1","2026-02-21 16:24:28");
INSERT INTO `activity_log` VALUES("351","1","1","login","user","1",NULL,"::1","2026-02-21 16:24:58");
INSERT INTO `activity_log` VALUES("352","1","1","login","user","1",NULL,"::1","2026-02-21 16:26:35");
INSERT INTO `activity_log` VALUES("353","1","1","logout","user","1",NULL,"::1","2026-02-21 16:29:07");
INSERT INTO `activity_log` VALUES("354","1","1","login","user","1",NULL,"::1","2026-02-21 16:29:35");
INSERT INTO `activity_log` VALUES("355","1","1","create_parent","parents","2","محمد العنزي","::1","2026-02-21 16:29:54");
INSERT INTO `activity_log` VALUES("356","1","1","link_parent_student","parent_students","2","Student: 11","::1","2026-02-21 16:30:15");
INSERT INTO `activity_log` VALUES("357","1","2","parent_login","parent","2",NULL,"::1","2026-02-21 16:31:33");
INSERT INTO `activity_log` VALUES("358","1","1","save_health","student_health","13",NULL,"::1","2026-02-21 16:32:20");
INSERT INTO `activity_log` VALUES("359","1","1","logout","user","1",NULL,"::1","2026-02-21 16:33:14");
INSERT INTO `activity_log` VALUES("360","1","1","save_attendance","attendance",NULL,"Date: 2026-02-21, Records: 25","::1","2026-02-21 16:33:38");
INSERT INTO `activity_log` VALUES("361","1","1","login","user","1",NULL,"::1","2026-02-21 16:33:54");
INSERT INTO `activity_log` VALUES("362","1","1","logout","user","1",NULL,"::1","2026-02-21 16:42:36");
INSERT INTO `activity_log` VALUES("363","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 16:43:01");
INSERT INTO `activity_log` VALUES("364","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 16:43:14");
INSERT INTO `activity_log` VALUES("365","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 16:43:33");
INSERT INTO `activity_log` VALUES("366","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 16:43:35");
INSERT INTO `activity_log` VALUES("367","1","1","save_measurement","student_measurements","95",NULL,"::1","2026-02-21 16:48:29");
INSERT INTO `activity_log` VALUES("368","1","2","logout","user","2",NULL,"::1","2026-02-21 16:48:47");
INSERT INTO `activity_log` VALUES("369","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 16:49:07");
INSERT INTO `activity_log` VALUES("370","1","1","parent_login","parent","1",NULL,"::1","2026-02-21 16:53:00");
INSERT INTO `activity_log` VALUES("371","1",NULL,"login_failed","auth",NULL,"Input: parent_test","::1","2026-02-21 16:55:07");
INSERT INTO `activity_log` VALUES("372","1","1","login","user","1",NULL,"::1","2026-02-21 16:55:56");
INSERT INTO `activity_log` VALUES("373","1","1","update_parent","parents","1","Parent Test","::1","2026-02-21 16:56:47");
INSERT INTO `activity_log` VALUES("374","1","1","logout","user","1",NULL,"::1","2026-02-21 16:57:18");
INSERT INTO `activity_log` VALUES("375","1","1","parent_login","parent","1",NULL,"::1","2026-02-21 16:57:50");
INSERT INTO `activity_log` VALUES("376","1","1","parent_login","parent","1",NULL,"::1","2026-02-21 17:11:40");
INSERT INTO `activity_log` VALUES("377","1","2","login","user","2",NULL,"::1","2026-02-22 02:45:52");
INSERT INTO `activity_log` VALUES("378","1","2","logout","user","2",NULL,"::1","2026-02-22 02:53:45");
INSERT INTO `activity_log` VALUES("379","1","1","login","user","1",NULL,"::1","2026-02-22 02:53:55");
INSERT INTO `activity_log` VALUES("380","1","1","award_badge","student","97","Badge ID: 5","::1","2026-02-22 03:36:09");
INSERT INTO `activity_log` VALUES("381","1","1","award_badge","student","11","Badge ID: 6","::1","2026-02-22 03:37:53");
INSERT INTO `activity_log` VALUES("382","1","1","create","tournament","14","تجربة التوزيع العشوائي","::1","2026-02-22 04:29:15");
INSERT INTO `activity_log` VALUES("383","1","1","delete","tournament","14",NULL,"::1","2026-02-22 04:32:22");
INSERT INTO `activity_log` VALUES("384","1","1","delete","tournament","13",NULL,"::1","2026-02-22 04:32:28");
INSERT INTO `activity_log` VALUES("385","1","1","delete","tournament","1",NULL,"::1","2026-02-22 04:32:51");
INSERT INTO `activity_log` VALUES("386","1","1","complete","tournament","5",NULL,"::1","2026-02-22 04:32:59");
INSERT INTO `activity_log` VALUES("387","1","1","delete","tournament","5",NULL,"::1","2026-02-22 04:33:02");
INSERT INTO `activity_log` VALUES("388","1","1","create","tournament","15","تجربة التوزيع العشوائي","::1","2026-02-22 04:34:36");
INSERT INTO `activity_log` VALUES("389","1","1","add_teams","tournament","15","Added 8 classes","::1","2026-02-22 04:34:51");
INSERT INTO `activity_log` VALUES("390","1","1","update","tournament","15",NULL,"::1","2026-02-22 04:35:15");
INSERT INTO `activity_log` VALUES("391","1","1","delete","tournament","15",NULL,"::1","2026-02-22 04:36:34");
INSERT INTO `activity_log` VALUES("392","1","1","delete","tournament","8",NULL,"::1","2026-02-22 04:36:41");
INSERT INTO `activity_log` VALUES("393","1","1","create","tournament","16","تجربة التوزيع العشوائي","::1","2026-02-22 04:37:13");
INSERT INTO `activity_log` VALUES("394","1","1","create","tournament","17","تجربة خروج المغلوب من مرتين","::1","2026-02-22 04:38:26");
INSERT INTO `activity_log` VALUES("395","1","1","start","tournament","17",NULL,"::1","2026-02-22 04:50:38");
INSERT INTO `activity_log` VALUES("396","1","1","login","user","1",NULL,"::1","2026-02-22 11:55:56");
INSERT INTO `activity_log` VALUES("397","1","1","create","tournament","18","تجربة دوري من دور واحد","::1","2026-02-22 11:57:58");
INSERT INTO `activity_log` VALUES("398","1","1","add_teams","tournament","18","Added 8 classes","::1","2026-02-22 11:58:12");
INSERT INTO `activity_log` VALUES("399","1","1","update","tournament","18",NULL,"::1","2026-02-22 12:01:57");
INSERT INTO `activity_log` VALUES("400","1","1","update","tournament","18",NULL,"::1","2026-02-22 12:02:13");
INSERT INTO `activity_log` VALUES("401","1","1","login","user","1",NULL,"::1","2026-02-22 12:46:14");
INSERT INTO `activity_log` VALUES("402","1","1","login","user","1",NULL,"::1","2026-02-22 15:34:14");
INSERT INTO `activity_log` VALUES("403","1","1","create","tournament","19","تجربة طريقة الخلط والمزج","::1","2026-02-22 15:34:57");
INSERT INTO `activity_log` VALUES("404","1","1","add_teams","tournament","19","Added 8 classes","::1","2026-02-22 15:35:07");
INSERT INTO `activity_log` VALUES("405","1","1","login","user","1",NULL,"::1","2026-02-22 18:39:57");
INSERT INTO `activity_log` VALUES("406","1","1","start","tournament","19",NULL,"::1","2026-02-22 18:40:08");
INSERT INTO `activity_log` VALUES("407","1","1","match_result","match","706","1 - 0","::1","2026-02-22 18:42:44");
INSERT INTO `activity_log` VALUES("408","1","1","match_result","match","701","1 - 0","::1","2026-02-22 18:42:54");
INSERT INTO `activity_log` VALUES("409","1","1","match_result","match","708","0 - 1","::1","2026-02-22 18:43:04");
INSERT INTO `activity_log` VALUES("410","1","1","match_result","match","703","1 - 0","::1","2026-02-22 18:43:52");
INSERT INTO `activity_log` VALUES("411","1","1","match_result","match","704","0 - 1","::1","2026-02-22 18:43:56");
INSERT INTO `activity_log` VALUES("412","1","1","match_result","match","709","1 - 0","::1","2026-02-22 18:44:01");
INSERT INTO `activity_log` VALUES("413","1","1","match_result","match","710","0 - 1","::1","2026-02-22 18:44:06");
INSERT INTO `activity_log` VALUES("414","1","1","match_result","match","711","1 - 0","::1","2026-02-22 18:44:13");
INSERT INTO `activity_log` VALUES("415","1","1","match_result","match","712","0 - 1","::1","2026-02-22 18:44:21");
INSERT INTO `activity_log` VALUES("416","1","1","login","user","1",NULL,"::1","2026-02-23 02:51:41");
INSERT INTO `activity_log` VALUES("417","1","1","create","tournament","20","تجربة ٢ لطريقة المزيج","::1","2026-02-23 02:55:18");
INSERT INTO `activity_log` VALUES("418","1","1","add_teams","tournament","20","Added 8 classes","::1","2026-02-23 02:55:32");
INSERT INTO `activity_log` VALUES("419","1","1","start","tournament","20",NULL,"::1","2026-02-23 02:55:48");
INSERT INTO `activity_log` VALUES("420","1","1","match_result","match","714","1 - 0","::1","2026-02-23 02:56:16");
INSERT INTO `activity_log` VALUES("421","1","1","match_result","match","715","1 - 0","::1","2026-02-23 02:56:20");
INSERT INTO `activity_log` VALUES("422","1","1","match_result","match","720","1 - 0","::1","2026-02-23 02:56:24");
INSERT INTO `activity_log` VALUES("423","1","1","match_result","match","721","1 - 0","::1","2026-02-23 02:56:29");
INSERT INTO `activity_log` VALUES("424","1","1","match_result","match","716","1 - 0","::1","2026-02-23 02:56:35");
INSERT INTO `activity_log` VALUES("425","1","1","match_result","match","717","1 - 0","::1","2026-02-23 02:56:40");
INSERT INTO `activity_log` VALUES("426","1","1","match_result","match","722","1 - 0","::1","2026-02-23 02:56:45");
INSERT INTO `activity_log` VALUES("427","1","1","match_result","match","723","0 - 1","::1","2026-02-23 02:56:50");
INSERT INTO `activity_log` VALUES("428","1","1","match_result","match","718","1 - 0","::1","2026-02-23 02:57:58");
INSERT INTO `activity_log` VALUES("429","1","1","match_result","match","719","1 - 0","::1","2026-02-23 02:58:03");
INSERT INTO `activity_log` VALUES("430","1","1","match_result","match","724","1 - 0","::1","2026-02-23 02:58:08");
INSERT INTO `activity_log` VALUES("431","1","1","match_result","match","725","1 - 0","::1","2026-02-23 02:58:13");
INSERT INTO `activity_log` VALUES("432","1","1","match_result","match","726","1 - 0","::1","2026-02-23 02:59:46");
INSERT INTO `activity_log` VALUES("433","1","1","match_result","match","727","1 - 0","::1","2026-02-23 02:59:52");
INSERT INTO `activity_log` VALUES("434","1","1","create","tournament","21","تجربة ٣","::1","2026-02-23 03:07:09");
INSERT INTO `activity_log` VALUES("435","1","1","add_teams","tournament","21","Added 8 classes","::1","2026-02-23 03:07:16");
INSERT INTO `activity_log` VALUES("436","1","1","start","tournament","21",NULL,"::1","2026-02-23 03:11:04");
INSERT INTO `activity_log` VALUES("437","1","1","match_result","match","729","1 - 0","::1","2026-02-23 03:11:44");
INSERT INTO `activity_log` VALUES("438","1","1","match_result","match","730","1 - 0","::1","2026-02-23 03:11:49");
INSERT INTO `activity_log` VALUES("439","1","1","match_result","match","735","1 - 0","::1","2026-02-23 03:11:53");
INSERT INTO `activity_log` VALUES("440","1","1","match_result","match","736","0 - 1","::1","2026-02-23 03:11:58");
INSERT INTO `activity_log` VALUES("441","1","1","match_result","match","731","1 - 0","::1","2026-02-23 03:12:04");
INSERT INTO `activity_log` VALUES("442","1","1","match_result","match","732","1 - 0","::1","2026-02-23 03:12:09");
INSERT INTO `activity_log` VALUES("443","1","1","match_result","match","737","1 - 0","::1","2026-02-23 03:12:13");
INSERT INTO `activity_log` VALUES("444","1","1","match_result","match","738","1 - 0","::1","2026-02-23 03:12:18");
INSERT INTO `activity_log` VALUES("445","1","1","match_result","match","733","1 - 0","::1","2026-02-23 03:12:23");
INSERT INTO `activity_log` VALUES("446","1","1","match_result","match","734","0 - 1","::1","2026-02-23 03:12:28");
INSERT INTO `activity_log` VALUES("447","1","1","match_result","match","739","1 - 0","::1","2026-02-23 03:12:34");
INSERT INTO `activity_log` VALUES("448","1","1","match_result","match","740","0 - 1","::1","2026-02-23 03:12:40");
INSERT INTO `activity_log` VALUES("449","1","1","match_result","match","741","1 - 0","::1","2026-02-23 03:12:53");
INSERT INTO `activity_log` VALUES("450","1","1","match_result","match","742","0 - 1","::1","2026-02-23 03:12:59");
INSERT INTO `activity_log` VALUES("451","1","1","match_result","match","743","1 - 0","::1","2026-02-23 03:13:05");
INSERT INTO `activity_log` VALUES("452","1","1","create","tournament","22","تجربة ٤","::1","2026-02-23 03:35:17");
INSERT INTO `activity_log` VALUES("453","1","1","update","tournament","22",NULL,"::1","2026-02-23 03:35:33");
INSERT INTO `activity_log` VALUES("454","1","1","add_teams","tournament","22","Added 8 classes","::1","2026-02-23 03:35:38");
INSERT INTO `activity_log` VALUES("455","1","1","start","tournament","22",NULL,"::1","2026-02-23 03:36:31");
INSERT INTO `activity_log` VALUES("456","1","1","create","tournament","23","تجربة التوزيع العشوائي١","::1","2026-02-23 03:42:13");
INSERT INTO `activity_log` VALUES("457","1","1","add_teams","tournament","23","Added 8 classes","::1","2026-02-23 03:42:27");
INSERT INTO `activity_log` VALUES("458","1","1","start","tournament","23",NULL,"::1","2026-02-23 03:42:53");
INSERT INTO `activity_log` VALUES("459","1","1","create","sports_team","11","فريق فصل ١ / ٢","::1","2026-02-23 03:50:54");
INSERT INTO `activity_log` VALUES("460","1","1","delete","tournament","18",NULL,"::1","2026-02-23 04:01:50");
INSERT INTO `activity_log` VALUES("461","1","1","create","sports_team","12","فصل ٢ / ١","::1","2026-02-23 04:03:02");
INSERT INTO `activity_log` VALUES("462","1","1","create","sports_team","13","فريق فصل ٢ / ٢","::1","2026-02-23 04:03:38");
INSERT INTO `activity_log` VALUES("463","1","1","create","tournament","24","يب","::1","2026-02-23 04:03:58");
INSERT INTO `activity_log` VALUES("464","1","1","start","tournament","24",NULL,"::1","2026-02-23 04:08:59");
INSERT INTO `activity_log` VALUES("465","1","1","create","sports_team","14","فصل ٣ / ١","::1","2026-02-23 04:13:06");
INSERT INTO `activity_log` VALUES("466","1","1","update","sports_team","14","فصل ٣ / ١","::1","2026-02-23 04:13:21");
INSERT INTO `activity_log` VALUES("467","1","1","add_member","sports_team","14",NULL,"::1","2026-02-23 04:13:43");
INSERT INTO `activity_log` VALUES("468","1","1","add_member","sports_team","14",NULL,"::1","2026-02-23 04:13:48");
INSERT INTO `activity_log` VALUES("469","1","1","add_member","sports_team","14",NULL,"::1","2026-02-23 04:13:51");
INSERT INTO `activity_log` VALUES("470","1","1","add_member","sports_team","14",NULL,"::1","2026-02-23 04:13:55");
INSERT INTO `activity_log` VALUES("471","1","1","add_member","sports_team","14",NULL,"::1","2026-02-23 04:14:03");
INSERT INTO `activity_log` VALUES("472","1","1","update","sports_team","14","فصل ٣ / ١","::1","2026-02-23 04:14:36");
INSERT INTO `activity_log` VALUES("473","1","1","add_member","sports_team","14",NULL,"::1","2026-02-23 04:15:13");
INSERT INTO `activity_log` VALUES("474","1","1","match_result","match","768","1 - 2","::1","2026-02-23 04:22:00");
INSERT INTO `activity_log` VALUES("475","1","1","match_result","match","769","2 - 1","::1","2026-02-23 04:30:07");
INSERT INTO `activity_log` VALUES("476","1","1","match_result","match","756","1 - 0","::1","2026-02-23 05:32:44");
INSERT INTO `activity_log` VALUES("477","1","1","create","tournament","25","تجربة دوري من دورين","::1","2026-02-23 05:56:25");
INSERT INTO `activity_log` VALUES("478","1","1","delete","tournament","25",NULL,"::1","2026-02-23 05:58:17");
INSERT INTO `activity_log` VALUES("479","1","1","schedule_matches","tournament","16","3 matches","::1","2026-02-23 06:09:48");
INSERT INTO `activity_log` VALUES("480","1","1","update","tournament","16",NULL,"::1","2026-02-23 06:10:53");
INSERT INTO `activity_log` VALUES("481","1","1","start","tournament","16",NULL,"::1","2026-02-23 06:11:16");
INSERT INTO `activity_log` VALUES("482","1","1","login","user","1",NULL,"::1","2026-02-23 08:18:18");
INSERT INTO `activity_log` VALUES("483","1","1","logout","user","1",NULL,"::1","2026-02-23 08:19:28");
INSERT INTO `activity_log` VALUES("484","1","2","login","user","2",NULL,"::1","2026-02-23 08:19:39");
INSERT INTO `activity_log` VALUES("485","1","2","logout","user","2",NULL,"::1","2026-02-23 09:47:26");
INSERT INTO `activity_log` VALUES("486","1","1","login","user","1",NULL,"::1","2026-02-23 09:47:31");
INSERT INTO `activity_log` VALUES("487","1","1","login","user","1",NULL,"::1","2026-02-24 07:25:33");
INSERT INTO `activity_log` VALUES("488","1","1","save_fitness","student_fitness","1","Records: 10","::1","2026-02-24 09:16:38");
INSERT INTO `activity_log` VALUES("489","1","1","update","fitness_test","1","جري 50 متر","::1","2026-02-24 09:38:39");
INSERT INTO `activity_log` VALUES("490","1","1","save_fitness","student_fitness","1","Records: 8","::1","2026-02-24 09:41:27");
INSERT INTO `activity_log` VALUES("491","1","1","save_criteria","fitness_criteria","1","Records: 6","::1","2026-02-24 09:46:42");
INSERT INTO `activity_log` VALUES("492","1","1","login","user","1",NULL,"::1","2026-02-24 12:54:35");
INSERT INTO `activity_log` VALUES("493","1","1","login","user","1",NULL,"::1","2026-02-25 05:46:45");
INSERT INTO `activity_log` VALUES("494","1","1","login","user","1",NULL,"::1","2026-02-25 06:16:51");
INSERT INTO `activity_log` VALUES("495","1",NULL,"login_failed","auth",NULL,"Input: admin","::1","2026-02-25 06:40:59");
INSERT INTO `activity_log` VALUES("496","1",NULL,"login_failed","auth",NULL,"Input: adminadmin","::1","2026-02-25 06:41:12");
INSERT INTO `activity_log` VALUES("497","1","1","login","user","1",NULL,"::1","2026-02-25 06:41:28");
INSERT INTO `activity_log` VALUES("498","1","1","logout","user","1",NULL,"::1","2026-02-25 12:04:03");
INSERT INTO `activity_log` VALUES("499","1",NULL,"login_failed","auth",NULL,"Input: mohamed","::1","2026-02-25 12:04:16");
INSERT INTO `activity_log` VALUES("500","1","2","parent_login","parent","2",NULL,"::1","2026-02-25 12:05:35");
INSERT INTO `activity_log` VALUES("501","1","2","logout","user","2",NULL,"::1","2026-02-25 12:57:39");
INSERT INTO `activity_log` VALUES("502","1",NULL,"logout","user",NULL,NULL,"::1","2026-02-25 13:04:26");
INSERT INTO `activity_log` VALUES("503","1","1","login","user","1",NULL,"::1","2026-02-27 04:23:46");
INSERT INTO `activity_log` VALUES("504",NULL,"14","login","user","14",NULL,"::1","2026-02-28 06:20:06");
INSERT INTO `activity_log` VALUES("505",NULL,"14","logout","user","14",NULL,"::1","2026-02-28 06:22:05");
INSERT INTO `activity_log` VALUES("506",NULL,"14","login","user","14",NULL,"::1","2026-02-28 06:24:29");
INSERT INTO `activity_log` VALUES("507",NULL,"1","logout","user","1",NULL,"::1","2026-02-28 07:21:58");
INSERT INTO `activity_log` VALUES("508",NULL,"1","login","user","1",NULL,"::1","2026-02-28 12:47:41");
INSERT INTO `activity_log` VALUES("509",NULL,"1","logout","user","1",NULL,"::1","2026-02-28 12:50:02");
INSERT INTO `activity_log` VALUES("510",NULL,NULL,"login_failed","auth",NULL,"Input: superadmin","::1","2026-02-28 12:50:25");
INSERT INTO `activity_log` VALUES("511",NULL,NULL,"login_failed","auth",NULL,"Input: superadmin","::1","2026-02-28 12:50:33");
INSERT INTO `activity_log` VALUES("512",NULL,NULL,"login_failed","auth",NULL,"Input: superadmin","::1","2026-02-28 12:51:29");
INSERT INTO `activity_log` VALUES("513",NULL,NULL,"login_failed","auth",NULL,"Input: superadmin","::1","2026-02-28 12:51:54");
INSERT INTO `activity_log` VALUES("514",NULL,NULL,"login_failed","auth",NULL,"Input: superadmin","::1","2026-02-28 12:51:56");
INSERT INTO `activity_log` VALUES("515",NULL,"14","login","user","14",NULL,"::1","2026-02-28 14:24:59");
INSERT INTO `activity_log` VALUES("516",NULL,"14","logout","user","14",NULL,"::1","2026-02-28 15:05:25");
INSERT INTO `activity_log` VALUES("517",NULL,"1","login","user","1",NULL,"::1","2026-02-28 15:05:36");
INSERT INTO `activity_log` VALUES("518",NULL,"1","create","tournament","26","تجربة الإشعارات","::1","2026-02-28 15:17:27");
INSERT INTO `activity_log` VALUES("519",NULL,"1","add_teams","tournament","26","Added 1 classes","::1","2026-02-28 15:17:50");
INSERT INTO `activity_log` VALUES("520",NULL,"1","add_teams","tournament","26","Added 1 classes","::1","2026-02-28 15:18:03");
INSERT INTO `activity_log` VALUES("521",NULL,"1","schedule_matches","tournament","26","4 matches","::1","2026-02-28 15:19:19");
INSERT INTO `activity_log` VALUES("522",NULL,"2","parent_login","parent","2",NULL,"::1","2026-02-28 15:28:15");
INSERT INTO `activity_log` VALUES("523",NULL,"1","complete","tournament","23",NULL,"::1","2026-02-28 15:31:45");
INSERT INTO `activity_log` VALUES("524",NULL,"1","match_result","match","848","1 - 0","::1","2026-02-28 15:32:24");
INSERT INTO `activity_log` VALUES("525",NULL,"1","complete","tournament","26",NULL,"::1","2026-02-28 15:39:54");
INSERT INTO `activity_log` VALUES("526",NULL,"1","delete","tournament","26",NULL,"::1","2026-02-28 15:40:15");
INSERT INTO `activity_log` VALUES("527",NULL,"1","complete","tournament","24",NULL,"::1","2026-02-28 15:40:21");
INSERT INTO `activity_log` VALUES("528",NULL,"1","delete","tournament","24",NULL,"::1","2026-02-28 15:40:24");
INSERT INTO `activity_log` VALUES("529",NULL,"1","create","tournament","27","تجربة بطولة إشعارات","::1","2026-03-01 03:06:22");
INSERT INTO `activity_log` VALUES("530",NULL,"1","start","tournament","27",NULL,"::1","2026-03-01 03:06:57");
INSERT INTO `activity_log` VALUES("531",NULL,"1","complete","tournament","27",NULL,"::1","2026-03-01 03:07:42");
INSERT INTO `activity_log` VALUES("532",NULL,"1","delete","tournament","23",NULL,"::1","2026-03-01 03:11:09");
INSERT INTO `activity_log` VALUES("533",NULL,"1","delete","tournament","27",NULL,"::1","2026-03-01 03:11:13");
INSERT INTO `activity_log` VALUES("534",NULL,"1","calendar_save","calendar","1","بطولة كرة القدم","::1","2026-03-01 03:27:42");
INSERT INTO `activity_log` VALUES("535",NULL,"1","logout","user","1",NULL,"::1","2026-03-01 03:38:11");
INSERT INTO `activity_log` VALUES("536",NULL,"1","login","user","1",NULL,"::1","2026-03-01 04:01:24");





CREATE TABLE `attendance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('present','absent','late') NOT NULL DEFAULT 'present',
  `notes` varchar(255) DEFAULT NULL,
  `recorded_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_date` (`student_id`,`attendance_date`),
  KEY `idx_date` (`attendance_date`),
  KEY `idx_status` (`status`),
  KEY `fk_attendance_user` (`recorded_by`),
  CONSTRAINT `fk_attendance_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_attendance_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=283 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `attendance` VALUES("1","1","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("2","2","2026-02-14","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("3","3","2026-02-14","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("4","4","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("5","5","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("6","6","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("7","7","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("8","8","2026-02-14","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("9","9","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("10","10","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("11","11","2026-02-14","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("12","12","2026-02-14","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("13","13","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("14","14","2026-02-14","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("15","15","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("16","16","2026-02-14","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("17","17","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("18","18","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("19","19","2026-02-14","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("20","20","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("21","21","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("22","22","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("23","23","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("24","24","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("25","25","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("26","26","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("27","27","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("28","28","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("29","29","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("30","30","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("31","31","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("32","32","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("33","33","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("34","34","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("35","35","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("36","36","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("37","37","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("38","38","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("39","39","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("40","40","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("41","41","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("42","42","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("43","43","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("44","44","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("45","45","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("46","46","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("47","47","2026-02-14","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("48","1","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("49","2","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("50","3","2026-02-13","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("51","4","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("52","5","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("53","6","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("54","7","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("55","8","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("56","9","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("57","10","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("58","11","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("59","12","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("60","13","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("61","14","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("62","15","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("63","16","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("64","17","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("65","18","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("66","19","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("67","20","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("68","21","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("69","22","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("70","23","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("71","24","2026-02-13","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("72","25","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("73","26","2026-02-13","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("74","27","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("75","28","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("76","29","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("77","30","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("78","31","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("79","32","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("80","33","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("81","34","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("82","35","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("83","36","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("84","37","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("85","38","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("86","39","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("87","40","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("88","41","2026-02-13","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("89","42","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("90","43","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("91","44","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("92","45","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("93","46","2026-02-13","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("94","47","2026-02-13","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("95","1","2026-02-12","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("96","2","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("97","3","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("98","4","2026-02-12","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("99","5","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("100","6","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("101","7","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("102","8","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("103","9","2026-02-12","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("104","10","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("105","11","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("106","12","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("107","13","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("108","14","2026-02-12","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("109","15","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("110","16","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("111","17","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("112","18","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("113","19","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("114","20","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("115","21","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("116","22","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("117","23","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("118","24","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("119","25","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("120","26","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("121","27","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("122","28","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("123","29","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("124","30","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("125","31","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("126","32","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("127","33","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("128","34","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("129","35","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("130","36","2026-02-12","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("131","37","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("132","38","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("133","39","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("134","40","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("135","41","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("136","42","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("137","43","2026-02-12","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("138","44","2026-02-12","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("139","45","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("140","46","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("141","47","2026-02-12","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("142","1","2026-02-11","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("143","2","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("144","3","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("145","4","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("146","5","2026-02-11","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("147","6","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("148","7","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("149","8","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("150","9","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("151","10","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("152","11","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("153","12","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("154","13","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("155","14","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("156","15","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("157","16","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("158","17","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("159","18","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("160","19","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("161","20","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("162","21","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("163","22","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("164","23","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("165","24","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("166","25","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("167","26","2026-02-11","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("168","27","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("169","28","2026-02-11","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("170","29","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("171","30","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("172","31","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("173","32","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("174","33","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("175","34","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("176","35","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("177","36","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("178","37","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("179","38","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("180","39","2026-02-11","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("181","40","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("182","41","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("183","42","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("184","43","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("185","44","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("186","45","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("187","46","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("188","47","2026-02-11","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("189","1","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("190","2","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("191","3","2026-02-10","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("192","4","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("193","5","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("194","6","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("195","7","2026-02-10","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("196","8","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("197","9","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("198","10","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("199","11","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("200","12","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("201","13","2026-02-10","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("202","14","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("203","15","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("204","16","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("205","17","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("206","18","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("207","19","2026-02-10","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("208","20","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("209","21","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("210","22","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("211","23","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("212","24","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("213","25","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("214","26","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("215","27","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("216","28","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("217","29","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("218","30","2026-02-10","absent",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("219","31","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("220","32","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("221","33","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("222","34","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("223","35","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("224","36","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("225","37","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("226","38","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("227","39","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("228","40","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("229","41","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("230","42","2026-02-10","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("231","43","2026-02-10","late",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("232","44","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("233","45","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("234","46","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("235","47","2026-02-10","present",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `attendance` VALUES("236","48","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("237","49","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("238","50","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("239","51","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("240","52","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("241","53","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("242","54","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("243","1","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("244","5","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("245","55","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("246","56","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("247","57","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("248","58","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("249","4","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("250","59","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("251","6","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("252","3","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("253","60","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("254","61","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("255","62","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("256","63","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("257","64","2026-02-16","present",NULL,"1","2026-02-16 06:51:54","2026-02-16 06:51:54");
INSERT INTO `attendance` VALUES("258","147","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("259","11","2026-02-21","absent",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("260","7","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("261","2","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("262","148","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("263","149","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("264","150","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("265","151","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("266","12","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("267","152","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("268","153","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("269","154","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("270","155","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("271","156","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("272","157","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("273","158","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("274","159","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("275","13","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("276","8","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("277","160","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("278","161","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("279","162","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("280","163","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("281","164","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");
INSERT INTO `attendance` VALUES("282","165","2026-02-21","present",NULL,"1","2026-02-21 16:33:38","2026-02-21 16:33:38");





CREATE TABLE `badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `badge_type` varchar(50) DEFAULT 'manual',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `criteria_value` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_badges_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `badges` VALUES("1","1","بطل المواظبة","يُمنح للطلاب الذين لم يتغيبوا أبداً خلال الشهر","📅","bg-blue-500","attendance_100","2026-02-22 02:53:04",NULL);
INSERT INTO `badges` VALUES("2","1","المتفوق البدني","يُمنح للطلاب الذين حققوا أعلى درجات اللياقة","💪","bg-purple-500","fitness_pro","2026-02-22 02:53:04",NULL);
INSERT INTO `badges` VALUES("3","1","النمر الصاعد","يُمنح لأكثر الطلاب تطوراً في الأداء","🐯","bg-orange-500","improvement","2026-02-22 02:53:04",NULL);
INSERT INTO `badges` VALUES("4","1","الروح الرياضية","يُمنح للتميز في السلوك والتعاون","🤝","bg-teal-500","manual","2026-02-22 02:53:04",NULL);
INSERT INTO `badges` VALUES("5","1","قائد الفريق","يُمنح للطلاب الذين أظهروا مهارات قيادية","👑","bg-yellow-500","manual","2026-02-22 02:53:04",NULL);
INSERT INTO `badges` VALUES("6","1","وحش اللياقة","يمنح الطالب هذا الوسام إذا زاد مستوى لياقته بمعدل درجتين عن آخر اختبار له","⭐","bg-emerald-500","improvement","2026-02-22 03:22:15","2.00");





CREATE TABLE `class_points` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `total_score` decimal(10,2) DEFAULT 0.00,
  `average_score` decimal(5,2) DEFAULT 0.00,
  `total_points` int(10) unsigned DEFAULT 0,
  `students_count` int(10) unsigned DEFAULT 0,
  `rank_position` int(10) unsigned DEFAULT 0,
  `last_calculated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_class` (`class_id`),
  CONSTRAINT `fk_points_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `class_points` VALUES("1","1","77.00","6.42","64","21","2","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("2","2","153.00","6.12","61","25","3","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("4","3","167.00","5.39","79","8","1","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("5","4","150.00","5.56","56","39","5","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("6","5","87.00","4.83","48","34","7","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("7","6","101.00","5.61","56","5","6","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("8","7","177.00","5.90","59","7","4","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("16","8","0.00","0.00","0","0","8","2026-02-24 09:16:38");
INSERT INTO `class_points` VALUES("17","9","0.00","0.00","0","22","9","2026-02-24 09:16:38");





CREATE TABLE `classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `grade_id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `section` varchar(10) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_grade` (`grade_id`),
  KEY `idx_active` (`active`),
  KEY `fk_classes_created_by` (`created_by`),
  KEY `idx_classes_school` (`school_id`),
  CONSTRAINT `fk_classes_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_classes_grade` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `classes` VALUES("1","1","1","1/1","1","1","2","2026-02-14 06:42:23");
INSERT INTO `classes` VALUES("2","1","1","1/2","2","1","2","2026-02-14 06:42:23");
INSERT INTO `classes` VALUES("3","1","1","1/3","3","0",NULL,"2026-02-14 06:42:23");
INSERT INTO `classes` VALUES("4","1","2","2/1","1","1","2","2026-02-14 06:42:23");
INSERT INTO `classes` VALUES("5","1","2","2/2","2","1","2","2026-02-14 06:42:23");
INSERT INTO `classes` VALUES("6","1","3","3/1","1","1","2","2026-02-14 06:42:23");
INSERT INTO `classes` VALUES("7","1","3","3/2","2","1","2","2026-02-14 06:42:23");
INSERT INTO `classes` VALUES("8","1","3","3/3","3","1","2","2026-02-15 13:22:05");
INSERT INTO `classes` VALUES("9","1","2","2/3","3","1","2","2026-02-15 13:22:13");
INSERT INTO `classes` VALUES("10","1","1","1/4","4","0","1","2026-02-21 02:58:53");





CREATE TABLE `fitness_criteria` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned NOT NULL,
  `min_value` decimal(10,2) NOT NULL,
  `max_value` decimal(10,2) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_criteria_test` (`test_id`),
  CONSTRAINT `fk_criteria_test` FOREIGN KEY (`test_id`) REFERENCES `fitness_tests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fitness_criteria` VALUES("1","1","10.00","11.00","7");
INSERT INTO `fitness_criteria` VALUES("2","1","11.01","12.00","6");
INSERT INTO `fitness_criteria` VALUES("3","1","12.01","13.00","5");
INSERT INTO `fitness_criteria` VALUES("4","1","8.00","9.00","9");
INSERT INTO `fitness_criteria` VALUES("5","1","9.01","10.00","8");
INSERT INTO `fitness_criteria` VALUES("6","1","3.00","7.59","10");





CREATE TABLE `fitness_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `unit` varchar(30) NOT NULL,
  `type` enum('higher_better','lower_better') NOT NULL DEFAULT 'higher_better',
  `max_score` int(10) unsigned NOT NULL DEFAULT 10,
  `description` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_active` (`active`),
  KEY `idx_fitness_tests_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fitness_tests` VALUES("1","1","جري 50 متر","ثانية","lower_better","10",NULL,"1","2026-02-14 06:42:23");
INSERT INTO `fitness_tests` VALUES("2","1","الضغط","عدة","higher_better","10",NULL,"1","2026-02-14 06:42:23");
INSERT INTO `fitness_tests` VALUES("3","1","الجلوس من الرقود","عدة","higher_better","10",NULL,"1","2026-02-14 06:42:23");
INSERT INTO `fitness_tests` VALUES("4","1","المرونة","سم","higher_better","10",NULL,"1","2026-02-14 06:42:23");
INSERT INTO `fitness_tests` VALUES("5","1","جري المكوك","ثانية","lower_better","10",NULL,"1","2026-02-14 06:42:23");





CREATE TABLE `grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `sort_order` int(10) unsigned DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_active` (`active`),
  KEY `idx_sort` (`sort_order`),
  KEY `idx_grades_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `grades` VALUES("1","1","الأول الثانوي","1","1","1","2026-02-14 06:42:23");
INSERT INTO `grades` VALUES("2","1","الثاني الثانوي","2","2","1","2026-02-14 06:42:23");
INSERT INTO `grades` VALUES("3","1","الثالث الثانوي","3","3","1","2026-02-14 06:42:23");
INSERT INTO `grades` VALUES("4","2","الصف الأول","1","1","1","2026-02-28 06:19:45");
INSERT INTO `grades` VALUES("5","2","الصف الثاني","2","2","1","2026-02-28 06:19:45");





CREATE TABLE `match_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `match_id` int(10) unsigned NOT NULL COMMENT 'معرف المباراة',
  `team_id` int(10) unsigned NOT NULL COMMENT 'معرف الفريق',
  `student_id` int(10) unsigned DEFAULT NULL COMMENT 'معرف الطالب',
  `event_type` enum('goal','own_goal','penalty','yellow_card','red_card','substitution','injury') NOT NULL COMMENT 'نوع الحدث',
  `minute` int(10) unsigned DEFAULT NULL COMMENT 'الدقيقة',
  `notes` varchar(255) DEFAULT NULL COMMENT 'ملاحظات',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_match` (`match_id`),
  KEY `idx_team` (`team_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_event_type` (`event_type`),
  CONSTRAINT `fk_me_match` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_me_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_me_team` FOREIGN KEY (`team_id`) REFERENCES `tournament_teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='أحداث المباريات';






CREATE TABLE `match_media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `match_id` int(10) unsigned NOT NULL,
  `media_type` enum('photo','video') NOT NULL DEFAULT 'photo',
  `media_url` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mm_match` (`match_id`),
  CONSTRAINT `fk_mm_match` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;






CREATE TABLE `matches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tournament_id` int(10) unsigned NOT NULL COMMENT 'معرف البطولة',
  `school_id` int(10) unsigned DEFAULT NULL,
  `round_number` int(10) unsigned NOT NULL DEFAULT 1 COMMENT 'رقم الجولة',
  `match_number` int(10) unsigned NOT NULL COMMENT 'رقم المباراة',
  `bracket_type` enum('main','losers','final','third_place') NOT NULL DEFAULT 'main',
  `team1_id` int(10) unsigned DEFAULT NULL COMMENT 'الفريق الأول',
  `team2_id` int(10) unsigned DEFAULT NULL COMMENT 'الفريق الثاني',
  `team1_score` int(10) unsigned DEFAULT NULL COMMENT 'نتيجة الفريق الأول',
  `team2_score` int(10) unsigned DEFAULT NULL COMMENT 'نتيجة الفريق الثاني',
  `winner_team_id` int(10) unsigned DEFAULT NULL COMMENT 'الفريق الفائز',
  `loser_team_id` int(10) unsigned DEFAULT NULL COMMENT 'الفريق الخاسر',
  `is_bye` tinyint(1) DEFAULT 0 COMMENT 'مباراة BYE',
  `match_date` date DEFAULT NULL COMMENT 'تاريخ المباراة',
  `match_time` time DEFAULT NULL COMMENT 'وقت المباراة',
  `venue` varchar(100) DEFAULT NULL COMMENT 'مكان المباراة',
  `status` enum('scheduled','in_progress','completed','postponed','cancelled') NOT NULL DEFAULT 'scheduled' COMMENT 'حالة المباراة',
  `next_match_id` int(10) unsigned DEFAULT NULL COMMENT 'المباراة التالية للفائز',
  `next_match_slot` enum('team1','team2') DEFAULT NULL COMMENT 'موقع الفائز في المباراة التالية',
  `loser_next_match_id` int(10) unsigned DEFAULT NULL COMMENT 'المباراة التالية للخاسر (للخروج المزدوج)',
  `loser_next_match_slot` enum('team1','team2') DEFAULT NULL,
  `notes` text DEFAULT NULL COMMENT 'ملاحظات',
  `man_of_match_student_id` int(10) unsigned DEFAULT NULL,
  `man_of_match_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `group_name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tournament` (`tournament_id`),
  KEY `idx_round` (`round_number`),
  KEY `idx_bracket` (`bracket_type`),
  KEY `idx_status` (`status`),
  KEY `idx_teams` (`team1_id`,`team2_id`),
  KEY `idx_winner` (`winner_team_id`),
  KEY `idx_next_match` (`next_match_id`),
  KEY `fk_m_team2` (`team2_id`),
  KEY `fk_m_loser` (`loser_team_id`),
  KEY `fk_m_loser_next` (`loser_next_match_id`),
  KEY `idx_saas_school` (`school_id`),
  CONSTRAINT `fk_m_loser` FOREIGN KEY (`loser_team_id`) REFERENCES `tournament_teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_m_loser_next` FOREIGN KEY (`loser_next_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_m_next` FOREIGN KEY (`next_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_m_team1` FOREIGN KEY (`team1_id`) REFERENCES `tournament_teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_m_team2` FOREIGN KEY (`team2_id`) REFERENCES `tournament_teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_m_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournaments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_m_winner` FOREIGN KEY (`winner_team_id`) REFERENCES `tournament_teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=864 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مباريات البطولات';

INSERT INTO `matches` VALUES("36","2","1","1","1","main","11","9","1","0","11","9","0",NULL,NULL,NULL,"completed","40","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:46:31","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("37","2","1","1","2","main","13","14","0","1","14","13","0",NULL,NULL,NULL,"completed","40","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:46:31","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("38","2","1","1","3","main","10","12",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","41","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:46:31","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("39","2","1","1","4","main",NULL,NULL,NULL,NULL,NULL,NULL,"1",NULL,NULL,NULL,"completed","41","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:46:31","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("40","2","1","2","5","main","11","14",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","42","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:46:31","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("41","2","1","2","6","main",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","42","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:46:31","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("42","2","1","3","7","main",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:46:31","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("43","2","1","1","1","main","13","10","1","0","13","10","0",NULL,NULL,NULL,"completed","47","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:47:02","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("44","2","1","1","2","main","14","11","1","0","14","11","0",NULL,NULL,NULL,"completed","47","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:47:02","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("45","2","1","1","3","main","12","9",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","48","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:47:02","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("46","2","1","1","4","main",NULL,NULL,NULL,NULL,NULL,NULL,"1",NULL,NULL,NULL,"completed","48","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:47:02","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("47","2","1","2","5","main","13","14",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","49","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:47:02","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("48","2","1","2","6","main",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","49","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:47:02","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("49","2","1","3","7","main",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-14 00:47:02","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("50","3","1","1","1","main","18","17","1","0","18","17","0",NULL,NULL,NULL,"completed","54","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 02:00:38","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("51","3","1","1","2","main","19","15","1","0","19","15","0",NULL,NULL,NULL,"completed","54","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 02:00:38","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("52","3","1","1","3","main","20","16","0","1","16","20","0",NULL,NULL,NULL,"completed","55","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 02:00:38","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("53","3","1","1","4","main",NULL,NULL,NULL,NULL,NULL,NULL,"1",NULL,NULL,NULL,"completed","55","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 02:00:38","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("54","3","1","2","5","main","18","19","1","0","18","19","0",NULL,NULL,NULL,"completed","56","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 02:00:38","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("55","3","1","2","6","main","16",NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","56","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 02:00:38","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("56","3","1","3","7","final","18",NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-14 02:00:38","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("153","4","1","1","1","main","22","23","1","0","22","23","0",NULL,NULL,NULL,"completed","157","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("154","4","1","1","2","main","26","24","1","0","26","24","0",NULL,NULL,NULL,"completed","157","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("155","4","1","1","3","main","21","25","0","1","25","21","0",NULL,NULL,NULL,"completed","158","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("156","4","1","1","4","main",NULL,NULL,NULL,NULL,NULL,NULL,"1",NULL,NULL,NULL,"completed","158","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("157","4","1","2","5","main","22","26","0","1","26","22","0",NULL,NULL,NULL,"completed","159","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("158","4","1","2","6","main","25",NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","159","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("159","4","1","3","7","main","26",NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("160","4","1","1","8","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("161","4","1","1","9","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-14 06:54:35","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("539","6","1","1","1","main","46","42","1","2","42","46","0",NULL,NULL,NULL,"completed","543","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("540","6","1","1","2","main","47","41","1","0","47","41","0",NULL,NULL,NULL,"completed","543","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("541","6","1","1","3","main","43","45","1","0","43","45","0",NULL,NULL,NULL,"completed","544","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("542","6","1","1","4","main","44",NULL,NULL,NULL,"44",NULL,"1",NULL,NULL,NULL,"completed","544","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("543","6","1","2","5","main","42","47","1","0","42","47","0",NULL,NULL,NULL,"completed","545","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("544","6","1","2","6","main","43","44","1","0","43","44","0",NULL,NULL,NULL,"completed","545","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("545","6","1","3","7","final","42","43","1","0","42","43","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("546","6","1","1","8","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("547","6","1","1","9","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("548","6","1","2","10","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("549","6","1","2","11","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("550","6","1","3","12","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("551","6","1","4","13","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("552","6","1","4","14","final",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 10:55:14","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("553","7","1","1","1","main","52","54","1","0","52","54","0",NULL,NULL,NULL,"completed","557","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("554","7","1","1","2","main","48","49","1","0","48","49","0",NULL,NULL,NULL,"completed","557","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("555","7","1","1","3","main","50","51","2","0","50","51","0",NULL,NULL,NULL,"completed","558","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("556","7","1","1","4","main","53",NULL,NULL,NULL,"53",NULL,"1",NULL,NULL,NULL,"completed","558","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("557","7","1","2","5","main","52","48","1","0","52","48","0",NULL,NULL,NULL,"completed","559","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("558","7","1","2","6","main","50","53",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","559","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("559","7","1","3","7","final",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("560","7","1","1","8","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("561","7","1","1","9","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("562","7","1","2","10","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("563","7","1","2","11","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("564","7","1","3","12","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("565","7","1","4","13","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("566","7","1","4","14","final",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-15 11:40:23","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("581","9","1","1","1","main","65","63","1","0","65","63","0",NULL,NULL,NULL,"completed","583","team1","584",NULL,NULL,NULL,NULL,"2026-02-21 00:01:03","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("582","9","1","1","2","main","64","66","1","0","64","66","0",NULL,NULL,NULL,"completed","583","team2","584",NULL,NULL,NULL,NULL,"2026-02-21 00:01:03","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("583","9","1","2","3","main","65","64","1","0","65","64","0",NULL,NULL,NULL,"completed","586","team1","585",NULL,NULL,NULL,NULL,"2026-02-21 00:01:03","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("584","9","1","1","4","losers","63","66","1","0","63","66","0",NULL,NULL,NULL,"completed","585","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-21 00:01:03","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("585","9","1","2","5","losers","63","64","0","1","64","63","0",NULL,NULL,NULL,"completed","586","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-21 00:01:03","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("586","9","1","3","6","final","65","64","0","1","64","65","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-21 00:01:03","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("587","9","1","4","7","final","64","65","0","1","65","64","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-21 00:04:00","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("602","17","1","1","1","main","81","79","1","0","81","79","0",NULL,NULL,NULL,"completed","604","team1","605",NULL,NULL,NULL,NULL,"2026-02-22 04:39:37","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("603","17","1","1","2","main","82","80","1","0","82","80","0",NULL,NULL,NULL,"completed","604","team2","605",NULL,NULL,NULL,NULL,"2026-02-22 04:39:37","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("604","17","1","2","3","main",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","607","team1","606",NULL,NULL,NULL,NULL,"2026-02-22 04:39:37","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("605","17","1","1","4","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","606","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-22 04:39:37","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("606","17","1","2","5","losers",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","607","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-22 04:39:37","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("607","17","1","3","6","final",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 04:39:37","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("699","19","1","1","1","main","98","95","1","0","98","95","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("700","19","1","1","2","main","96","97","1","0","96","97","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("701","19","1","2","3","main","98","97","1","0","98","97","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("702","19","1","2","4","main","95","96","1","0","95","96","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("703","19","1","3","5","main","98","96","1","0","98","96","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("704","19","1","3","6","main","97","95","0","1","95","97","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("705","19","1","1","7","main","92","99","1","0","92","99","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("706","19","1","1","8","main","94","93","1","0","94","93","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("707","19","1","2","9","main","92","93","0","1","93","92","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("708","19","1","2","10","main","99","94","0","1","94","99","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("709","19","1","3","11","main","92","94","1","0","92","94","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("710","19","1","3","12","main","93","99","0","1","99","93","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 16:31:50","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("711","19","1","4","13","main","98","92","1","0","98","92","0",NULL,NULL,NULL,"completed","713","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-22 18:44:06","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("712","19","1","4","14","main","94","95","0","1","95","94","0",NULL,NULL,NULL,"completed","713","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-22 18:44:06","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("713","19","1","5","15","final",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-22 18:44:06","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("714","20","1","1","1","main","101","105","1","0","101","105","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("715","20","1","1","2","main","103","102","1","0","103","102","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("716","20","1","2","3","main","101","102","1","0","101","102","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("717","20","1","2","4","main","105","103","1","0","105","103","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("718","20","1","3","5","main","101","103","1","0","101","103","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("719","20","1","3","6","main","102","105","1","0","102","105","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("720","20","1","1","7","main","106","107","1","0","106","107","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("721","20","1","1","8","main","100","104","1","0","100","104","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("722","20","1","2","9","main","106","104","1","0","106","104","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("723","20","1","2","10","main","107","100","0","1","100","107","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("724","20","1","3","11","main","106","100","1","0","106","100","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("725","20","1","3","12","main","104","107","1","0","104","107","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:55:45","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("726","20","1","4","13","main","101","100","1","0","101","100","0",NULL,NULL,NULL,"completed","728","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:58:13","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("727","20","1","4","14","main","106","105","1","0","106","105","0",NULL,NULL,NULL,"completed","728","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:58:13","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("728","20","1","5","15","final",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 02:58:13","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("729","21","1","1","1","main","113","114","1","0","113","114","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("730","21","1","1","2","main","108","110","1","0","108","110","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("731","21","1","2","3","main","113","110","1","0","113","110","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("732","21","1","2","4","main","114","108","1","0","114","108","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("733","21","1","3","5","main","113","108","1","0","113","108","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("734","21","1","3","6","main","110","114","0","1","114","110","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("735","21","1","1","7","main","111","115","1","0","111","115","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("736","21","1","1","8","main","109","112","0","1","112","109","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("737","21","1","2","9","main","111","112","1","0","111","112","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("738","21","1","2","10","main","115","109","1","0","115","109","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("739","21","1","3","11","main","111","109","1","0","111","109","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("740","21","1","3","12","main","112","115","0","1","115","112","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:07:27","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("741","21","1","4","13","main","113","115","1","0","113","115","0",NULL,NULL,NULL,"completed","743","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:12:40","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("742","21","1","4","14","main","111","114","0","1","114","111","0",NULL,NULL,NULL,"completed","743","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:12:40","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("743","21","1","5","15","final","113","114","1","0","113","114","0",NULL,NULL,NULL,"completed",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:12:40","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("744","22","1","1","1","main","118","121",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("745","22","1","1","2","main","119","116",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("746","22","1","2","3","main","118","116",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("747","22","1","2","4","main","121","119",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("748","22","1","3","5","main","118","119",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("749","22","1","3","6","main","116","121",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","A");
INSERT INTO `matches` VALUES("750","22","1","1","7","main","117","123",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("751","22","1","1","8","main","122","120",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("752","22","1","2","9","main","117","120",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("753","22","1","2","10","main","123","122",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("754","22","1","3","11","main","117","122",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("755","22","1","3","12","main","120","123",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 03:35:51","2026-02-28 06:50:24","B");
INSERT INTO `matches` VALUES("840","16","1","1","1","main","145","149",NULL,NULL,NULL,NULL,"0","2026-03-03","08:00:00",NULL,"scheduled","844","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("841","16","1","1","2","main","150","151",NULL,NULL,NULL,NULL,"0","2026-03-02","08:00:00",NULL,"scheduled","844","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("842","16","1","1","3","main","148","146",NULL,NULL,NULL,NULL,"0","2026-03-01","08:00:00",NULL,"scheduled","845","team1",NULL,NULL,NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("843","16","1","1","4","main","147",NULL,NULL,NULL,"147",NULL,"1",NULL,NULL,NULL,"completed","845","team2",NULL,NULL,NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("844","16","1","2","5","main",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","846","team1","847","team1",NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("845","16","1","2","6","main",NULL,"147",NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled","846","team2","847","team2",NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("846","16","1","3","7","final",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);
INSERT INTO `matches` VALUES("847","16","1","3","8","third_place",NULL,NULL,NULL,NULL,NULL,NULL,"0",NULL,NULL,NULL,"scheduled",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2026-02-23 06:09:19","2026-02-28 06:50:24",NULL);





CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned DEFAULT NULL,
  `type` enum('attendance','fitness','health','general','tournament_started') NOT NULL DEFAULT 'general',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notif_parent` (`parent_id`),
  KEY `idx_notif_read` (`parent_id`,`is_read`),
  KEY `fk_notif_student` (`student_id`),
  CONSTRAINT `fk_notif_parent` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_notif_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notifications` VALUES("1","2","11","health","تحديث الحالة الصحية: تركي العنزي","تم إضافة/تحديث حالة صحية للطالب (تركي العنزي): ارتفاع درجة الحرارة.","1","2026-02-21 16:32:20");
INSERT INTO `notifications` VALUES("2","2","11","attendance","إشعار حضور: تركي العنزي","نفيدكم بأن الطالب (تركي العنزي) تم رصده كـ (غائب) في حصة التربية البدنية بتاريخ 2026-02-21.","1","2026-02-21 16:33:38");
INSERT INTO `notifications` VALUES("3","1","1","health","قياسات جديدة: محمد أحمد العتيبي","تم تحديث القياسات البدنية للطالب (محمد أحمد العتيبي) بتاريخ (2026-02-21).","0","2026-02-21 16:48:29");
INSERT INTO `notifications` VALUES("4","1","1","general","تنبيه تجريبي","هذا تنبيه للتأكد من عمل الجرس","0","2026-02-21 16:54:15");
INSERT INTO `notifications` VALUES("5","2","11","general","🎉 وسام جديد!","حصل ابنكم على وسام: وحش اللياقة","1","2026-02-22 03:37:53");
INSERT INTO `notifications` VALUES("6","2",NULL,"general","نتيجة مباراة: تجربة طريقة الخلط والمزج","انتهت المباراة بين فريق (الثاني الثانوي - 2/1) وفريق (الأول الثانوي - 1/2) بنتيجة (1 - 0).","1","2026-02-22 18:42:44");
INSERT INTO `notifications` VALUES("7","1",NULL,"general","نتيجة مباراة: تجربة طريقة الخلط والمزج","انتهت المباراة بين فريق (الأول الثانوي - 1/1) وفريق (الثاني الثانوي - 2/1) بنتيجة (1 - 0).","0","2026-02-22 18:44:01");
INSERT INTO `notifications` VALUES("8","2",NULL,"general","نتيجة مباراة: تجربة طريقة الخلط والمزج","انتهت المباراة بين فريق (الأول الثانوي - 1/2) وفريق (الثالث الثانوي - 3/3) بنتيجة (0 - 1).","1","2026-02-22 18:44:06");
INSERT INTO `notifications` VALUES("9","1",NULL,"general","نتيجة مباراة: تجربة طريقة الخلط والمزج","انتهت المباراة بين فريق (الثالث الثانوي - 3/2) وفريق (الأول الثانوي - 1/1) بنتيجة (1 - 0).","0","2026-02-22 18:44:13");
INSERT INTO `notifications` VALUES("10","2",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الأول الثانوي - 1/2) وفريق (الثالث الثانوي - 3/1) بنتيجة (1 - 0).","1","2026-02-23 02:56:16");
INSERT INTO `notifications` VALUES("11","1",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الأول الثانوي - 1/1) وفريق (الثاني الثانوي - 2/3) بنتيجة (1 - 0).","0","2026-02-23 02:56:29");
INSERT INTO `notifications` VALUES("12","2",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الأول الثانوي - 1/2) وفريق (الثاني الثانوي - 2/1) بنتيجة (1 - 0).","1","2026-02-23 02:56:35");
INSERT INTO `notifications` VALUES("13","1",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الثالث الثانوي - 3/3) وفريق (الأول الثانوي - 1/1) بنتيجة (0 - 1).","0","2026-02-23 02:56:50");
INSERT INTO `notifications` VALUES("14","2",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الأول الثانوي - 1/2) وفريق (الثاني الثانوي - 2/2) بنتيجة (1 - 0).","1","2026-02-23 02:57:58");
INSERT INTO `notifications` VALUES("15","1",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الثالث الثانوي - 3/2) وفريق (الأول الثانوي - 1/1) بنتيجة (1 - 0).","0","2026-02-23 02:58:08");
INSERT INTO `notifications` VALUES("16","2",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الأول الثانوي - 1/2) وفريق (الأول الثانوي - 1/1) بنتيجة (1 - 0).","1","2026-02-23 02:59:46");
INSERT INTO `notifications` VALUES("17","1",NULL,"general","نتيجة مباراة: تجربة ٢ لطريقة المزيج","انتهت المباراة بين فريق (الأول الثانوي - 1/2) وفريق (الأول الثانوي - 1/1) بنتيجة (1 - 0).","0","2026-02-23 02:59:46");
INSERT INTO `notifications` VALUES("18","1",NULL,"general","نتيجة مباراة: تجربة ٣","انتهت المباراة بين فريق (الأول الثانوي - 1/1) وفريق (الثاني الثانوي - 2/1) بنتيجة (1 - 0).","0","2026-02-23 03:11:49");
INSERT INTO `notifications` VALUES("19","2",NULL,"general","نتيجة مباراة: تجربة ٣","انتهت المباراة بين فريق (الأول الثانوي - 1/2) وفريق (الثاني الثانوي - 2/3) بنتيجة (0 - 1).","1","2026-02-23 03:11:58");
INSERT INTO `notifications` VALUES("20","1",NULL,"general","نتيجة مباراة: تجربة ٣","انتهت المباراة بين فريق (الثالث الثانوي - 3/2) وفريق (الأول الثانوي - 1/1) بنتيجة (1 - 0).","0","2026-02-23 03:12:09");
INSERT INTO `notifications` VALUES("21","2",NULL,"general","نتيجة مباراة: تجربة ٣","انتهت المباراة بين فريق (الثالث الثانوي - 3/3) وفريق (الأول الثانوي - 1/2) بنتيجة (1 - 0).","1","2026-02-23 03:12:18");
INSERT INTO `notifications` VALUES("22","1",NULL,"general","نتيجة مباراة: تجربة ٣","انتهت المباراة بين فريق (الثالث الثانوي - 3/1) وفريق (الأول الثانوي - 1/1) بنتيجة (1 - 0).","0","2026-02-23 03:12:23");
INSERT INTO `notifications` VALUES("23","2",NULL,"general","نتيجة مباراة: تجربة ٣","انتهت المباراة بين فريق (الثاني الثانوي - 2/2) وفريق (الأول الثانوي - 1/2) بنتيجة (1 - 0).","1","2026-02-23 03:12:34");
INSERT INTO `notifications` VALUES("24","2","11","fitness","نتيجة اختبار لياقة: تركي العنزي","تم رصد نتيجة الطالب (تركي العنزي) في اختبار (جري 50 متر) بقيمة (12.9) ودرجة (4).","1","2026-02-24 09:16:38");
INSERT INTO `notifications` VALUES("25","2","11","fitness","نتيجة اختبار لياقة: تركي العنزي","تم رصد نتيجة الطالب (تركي العنزي) في اختبار (جري 50 متر) بقيمة (12.9) ودرجة (4).","1","2026-02-24 09:16:38");
INSERT INTO `notifications` VALUES("26","1","1","tournament_started","🏆 انطلقت البطولة تجربة بطولة إشعارات!","🔴 تابعوا النتائج والأهداف مباشرة من هنا.\nرابط: http://localhost/pe1/tournament.php?t=fd3b7c82a0160cba449ae02eb745202d","0","2026-03-01 03:06:57");
INSERT INTO `notifications` VALUES("27","1","48","tournament_started","🏆 انطلقت البطولة تجربة بطولة إشعارات!","🔴 تابعوا النتائج والأهداف مباشرة من هنا.\nرابط: http://localhost/pe1/tournament.php?t=fd3b7c82a0160cba449ae02eb745202d","0","2026-03-01 03:06:57");
INSERT INTO `notifications` VALUES("28","2","11","tournament_started","🏆 انطلقت البطولة تجربة بطولة إشعارات!","🔴 تابعوا النتائج والأهداف مباشرة من هنا.\nرابط: http://localhost/pe1/tournament.php?t=fd3b7c82a0160cba449ae02eb745202d","1","2026-03-01 03:06:57");





CREATE TABLE `parent_students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_parent_student` (`parent_id`,`student_id`),
  KEY `idx_ps_parent` (`parent_id`),
  KEY `idx_ps_student` (`student_id`),
  CONSTRAINT `fk_ps_parent` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `parent_students` VALUES("3","1","1","2026-02-21 14:44:15");
INSERT INTO `parent_students` VALUES("4","2","11","2026-02-21 16:30:15");
INSERT INTO `parent_students` VALUES("5","1","48","2026-02-21 18:37:13");





CREATE TABLE `parents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_school_parent_username` (`school_id`,`username`),
  KEY `idx_parents_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `parents` VALUES("1","1","parent_test","$2y$12$Mpu2A5aq/DSFqQXEz8Yr9.TavyM6GbZkuYREPG.DOvPyN7vauWHUS","Parent Test","","0512345678","1","2026-02-21 17:11:40","2026-02-21 14:44:15","2026-02-28 06:14:44");
INSERT INTO `parents` VALUES("2","1","parent_test2","$2y$12$8rY8teuFljdLrhr5DTAqROkojk7L7faVu5zoW5cn6VwiqLwcBsR4O","محمد العنزي","","0572623308","1","2026-02-28 15:28:15","2026-02-21 16:29:54","2026-02-28 15:28:15");





CREATE TABLE `password_resets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `otp` varchar(10) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pr_email` (`email`),
  KEY `idx_pr_otp` (`otp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `password_resets` VALUES("1","1","esm1774@gmail.com","user","1","443230","2026-03-01 03:54:17","2026-03-01 03:39:17");





CREATE TABLE `plans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT 'اسم الخطة',
  `name_en` varchar(100) DEFAULT NULL COMMENT 'English name',
  `slug` varchar(50) NOT NULL COMMENT 'معرف فريد',
  `description` text DEFAULT NULL,
  `price_monthly` decimal(10,2) DEFAULT 0.00 COMMENT 'السعر الشهري',
  `price_yearly` decimal(10,2) DEFAULT 0.00 COMMENT 'السعر السنوي',
  `max_students` int(10) unsigned DEFAULT 100,
  `max_teachers` int(10) unsigned DEFAULT 5,
  `max_classes` int(10) unsigned DEFAULT 10,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"tournaments": true, "badges": true, ...}' CHECK (json_valid(`features`)),
  `is_default` tinyint(1) DEFAULT 0 COMMENT 'الخطة الافتراضية للتسجيل',
  `active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_plan_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='خطط الاشتراك';

INSERT INTO `plans` VALUES("1","مجاني","Free","free",NULL,"0.00","0.00","50","2","5","{\"tournaments\": false, \"badges\": false, \"notifications\": true, \"reports\": false, \"sports_teams\": false, \"certificates\": false}","0","1","1","2026-02-28 06:14:44");
INSERT INTO `plans` VALUES("2","أساسي","Basic","basic",NULL,"99.00","999.00","200","5","15","{\"tournaments\": false, \"badges\": true, \"notifications\": true, \"reports\": true, \"sports_teams\": false, \"certificates\": true}","1","1","2","2026-02-28 06:14:44");
INSERT INTO `plans` VALUES("3","متقدم","Advanced","advanced",NULL,"199.00","1999.00","500","15","30","{\"tournaments\": true, \"badges\": true, \"notifications\": true, \"reports\": true, \"sports_teams\": true, \"certificates\": true}","0","1","3","2026-02-28 06:14:44");
INSERT INTO `plans` VALUES("4","مؤسسي","Enterprise","enterprise",NULL,"499.00","4999.00","9999","999","999","{\"tournaments\": true, \"badges\": true, \"notifications\": true, \"reports\": true, \"sports_teams\": true, \"certificates\": true}","0","1","4","2026-02-28 06:14:44");





CREATE TABLE `platform_admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('super_admin','support') DEFAULT 'super_admin',
  `active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_platform_admin_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مديرو المنصة';

INSERT INTO `platform_admins` VALUES("1","superadmin","$2y$12$mGQ.1xGh51712d5sMKc6ie9XKFNP/snk/Z/IB0PnemvnECyWFe4dS","مدير المنصة","admin@pesmart.com","super_admin","1","2026-03-01 04:16:17","2026-02-28 06:14:44");





CREATE TABLE `schools` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL COMMENT 'اسم المدرسة',
  `slug` varchar(50) NOT NULL COMMENT 'المعرف الفريد (للنطاق الفرعي)',
  `logo_url` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT 'Asia/Riyadh',
  `plan_id` int(10) unsigned DEFAULT NULL COMMENT 'خطة الاشتراك',
  `subscription_status` enum('trial','active','suspended','cancelled') DEFAULT 'trial',
  `trial_ends_at` date DEFAULT NULL,
  `subscription_ends_at` date DEFAULT NULL,
  `max_students` int(10) unsigned DEFAULT 100,
  `max_teachers` int(10) unsigned DEFAULT 5,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'إعدادات خاصة بالمدرسة' CHECK (json_valid(`settings`)),
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_school_slug` (`slug`),
  KEY `idx_school_status` (`subscription_status`),
  KEY `idx_school_active` (`active`),
  KEY `fk_school_plan` (`plan_id`),
  CONSTRAINT `fk_school_plan` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='المدارس (المستأجرين)';

INSERT INTO `schools` VALUES("1","المدرسة الافتراضية","default",NULL,NULL,NULL,NULL,NULL,NULL,"Asia/Riyadh","3","trial","2026-03-30",NULL,"9999","999",NULL,"1","2026-02-28 06:14:44","2026-02-28 06:14:44");
INSERT INTO `schools` VALUES("2","school_test1","sch_test1",NULL,"admin@sch.com",NULL,NULL,NULL,NULL,"Asia/Riyadh","1","trial","2026-03-14",NULL,"50","2",NULL,"1","2026-02-28 06:19:45","2026-02-28 06:19:45");





CREATE TABLE `sports_calendar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `event_type` enum('match','training','tournament','fitness','ceremony','meeting','holiday','other') NOT NULL DEFAULT 'other',
  `location` varchar(255) DEFAULT NULL,
  `color` varchar(20) DEFAULT '#10b981',
  `icon` varchar(50) DEFAULT '?',
  `is_recurring` tinyint(1) DEFAULT 0,
  `recurrence_pattern` varchar(50) DEFAULT NULL,
  `target_grades` varchar(255) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cal_school` (`school_id`),
  KEY `idx_cal_date` (`event_date`),
  KEY `idx_cal_type` (`event_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sports_calendar` VALUES("1","1","بطولة كرة القدم","","2026-02-03",NULL,NULL,NULL,"ceremony","الملعب","#3410b7","📅","0","","","1","1","2026-03-01 03:27:42","2026-03-01 03:27:42");





CREATE TABLE `sports_teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `sport_type` varchar(50) NOT NULL DEFAULT 'كرة قدم',
  `team_type` enum('class','school','mixed') NOT NULL DEFAULT 'mixed',
  `class_id` int(10) unsigned DEFAULT NULL,
  `coach_id` int(10) unsigned DEFAULT NULL,
  `color` varchar(20) NOT NULL DEFAULT '#10b981',
  `logo_emoji` varchar(10) DEFAULT '⚽',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sport` (`sport_type`),
  KEY `idx_type` (`team_type`),
  KEY `idx_active` (`is_active`),
  KEY `idx_sports_teams_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sports_teams` VALUES("1","1","فصل ١ / ١","كرة قدم","class","1",NULL,"#1b10b7","⚽","","1","1","2026-02-21 01:09:21","2026-02-28 06:14:44");
INSERT INTO `sports_teams` VALUES("2","1","منتخب كرة القدم بالمدرسة","كرة قدم","school",NULL,NULL,"#10b981","⚽","","1","1","2026-02-21 01:11:40","2026-02-28 06:14:44");
INSERT INTO `sports_teams` VALUES("6","1","فريق النسور","كرة قدم","mixed",NULL,NULL,"#f59e0b","⚽",NULL,"1","1","2026-02-21 01:41:17","2026-02-28 06:14:44");
INSERT INTO `sports_teams` VALUES("11","1","فريق فصل ١ / ٢","كرة قدم","class","2",NULL,"#b7107a","⚽","","1","1","2026-02-23 03:50:54","2026-02-28 06:14:44");
INSERT INTO `sports_teams` VALUES("12","1","فصل ٢ / ١","كرة قدم","class","4",NULL,"#102cb7","⚽","","1","1","2026-02-23 04:03:02","2026-02-28 06:14:44");
INSERT INTO `sports_teams` VALUES("13","1","فريق فصل ٢ / ٢","كرة قدم","class","5",NULL,"#8ab710","⚽","","1","1","2026-02-23 04:03:38","2026-02-28 06:14:44");
INSERT INTO `sports_teams` VALUES("14","1","فصل ٣ / ١","كرة قدم","mixed",NULL,NULL,"#b71058","⚽","","1","1","2026-02-23 04:13:06","2026-02-28 06:14:44");





CREATE TABLE `standings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tournament_id` int(10) unsigned NOT NULL COMMENT 'معرف البطولة',
  `school_id` int(10) unsigned DEFAULT NULL,
  `team_id` int(10) unsigned NOT NULL COMMENT 'معرف الفريق',
  `played` int(10) unsigned DEFAULT 0 COMMENT 'المباريات الملعوبة',
  `wins` int(10) unsigned DEFAULT 0 COMMENT 'الانتصارات',
  `draws` int(10) unsigned DEFAULT 0 COMMENT 'التعادلات',
  `losses` int(10) unsigned DEFAULT 0 COMMENT 'الخسائر',
  `goals_for` int(10) unsigned DEFAULT 0 COMMENT 'الأهداف المسجلة',
  `goals_against` int(10) unsigned DEFAULT 0 COMMENT 'الأهداف المستقبلة',
  `goal_difference` int(11) DEFAULT 0 COMMENT 'فارق الأهداف',
  `points` int(10) unsigned DEFAULT 0 COMMENT 'النقاط',
  `form` varchar(20) DEFAULT NULL COMMENT 'آخر 5 نتائج (WWLDW)',
  `last_updated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `group_name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tournament_team` (`tournament_id`,`team_id`),
  KEY `idx_points` (`points`,`goal_difference`,`goals_for`),
  KEY `fk_s_team` (`team_id`),
  KEY `idx_saas_school` (`school_id`),
  CONSTRAINT `fk_s_team` FOREIGN KEY (`team_id`) REFERENCES `tournament_teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_s_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournaments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول ترتيب الدوري';

INSERT INTO `standings` VALUES("38","19","1","98","3","3","0","0","3","0","3","9","WWW","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("39","19","1","95","2","2","0","0","2","0","2","6","WW","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("40","19","1","96","1","0","0","1","0","1","-1","0","L","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("41","19","1","97","2","0","0","2","0","2","-2","0","LL","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("42","19","1","92","2","1","0","1","1","1","0","3","WL","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("43","19","1","99","2","1","0","1","1","1","0","3","LW","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("44","19","1","94","4","2","0","2","2","2","0","6","WWLL","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("45","19","1","93","2","0","0","2","0","2","-2","0","LL","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("46","20","1","101","4","4","0","0","4","0","4","12","WWWW","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("47","20","1","105","4","1","0","3","1","3","-2","3","LWLL","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("48","20","1","103","3","1","0","2","1","2","-1","3","WLL","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("49","20","1","102","3","1","0","2","1","2","-1","3","LLW","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("50","20","1","106","4","4","0","0","4","0","4","12","WWWW","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("51","20","1","107","3","0","0","3","0","3","-3","0","LLL","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("52","20","1","100","4","2","0","2","2","2","0","6","WWLL","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("53","20","1","104","3","1","0","2","1","2","-1","3","LLW","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("54","21","1","113","3","3","0","0","3","0","3","9","WWW","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("55","21","1","114","3","2","0","1","2","1","1","6","LWW","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("56","21","1","108","3","1","0","2","1","2","-1","3","WLL","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("57","21","1","110","3","0","0","3","0","3","-3","0","LLL","2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("58","21","1","111","3","3","0","0","3","0","3","9","WWW","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("59","21","1","115","3","2","0","1","2","1","1","6","LWW","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("60","21","1","109","3","0","0","3","0","3","-3","0","LLL","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("61","21","1","112","3","1","0","2","1","2","-1","3","WLL","2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("62","22","1","118","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("63","22","1","121","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("64","22","1","119","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("65","22","1","116","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","A");
INSERT INTO `standings` VALUES("66","22","1","117","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("67","22","1","123","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("68","22","1","122","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","B");
INSERT INTO `standings` VALUES("69","22","1","120","0","0","0","0","0","0","0","0",NULL,"2026-02-28 06:50:24","B");





CREATE TABLE `student_badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `badge_id` int(11) NOT NULL,
  `awarded_by` int(11) DEFAULT NULL,
  `awarded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `student_badges` VALUES("1","97","5","1","2026-02-22 03:36:09","");
INSERT INTO `student_badges` VALUES("2","11","6","1","2026-02-22 03:37:53","");
INSERT INTO `student_badges` VALUES("3","27","1",NULL,"2026-02-24 09:41:27","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("4","23","1",NULL,"2026-02-24 09:41:27","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("5","6","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("6","21","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("7","25","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("8","32","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("9","34","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("10","35","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("11","37","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("12","38","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("13","45","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");
INSERT INTO `student_badges` VALUES("14","46","1",NULL,"2026-02-24 09:48:44","تلقائي: نسبة حضور متميزة (100%) خلال آخر 30 يوم");





CREATE TABLE `student_fitness` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `test_id` int(10) unsigned NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `score` int(10) unsigned NOT NULL DEFAULT 0,
  `test_date` date NOT NULL,
  `recorded_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_test` (`student_id`,`test_id`),
  KEY `idx_test` (`test_id`),
  KEY `idx_score` (`score`),
  KEY `fk_fitness_user` (`recorded_by`),
  CONSTRAINT `fk_fitness_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fitness_test` FOREIGN KEY (`test_id`) REFERENCES `fitness_tests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fitness_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `student_fitness` VALUES("1","1","1","6.10","9","2026-02-15","1","2026-02-14 06:42:23","2026-02-15 07:43:29");
INSERT INTO `student_fitness` VALUES("2","1","2","7.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("3","1","3","11.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("4","1","5","7.70","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("5","2","2","7.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("6","2","3","32.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("7","2","5","9.10","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("8","3","3","5.00","1","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("9","3","4","8.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("10","4","3","31.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("11","4","5","7.70","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("12","5","1","6.10","9","2026-02-15","1","2026-02-14 06:42:23","2026-02-15 07:43:29");
INSERT INTO `student_fitness` VALUES("13","5","2","18.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("14","5","3","29.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("15","6","2","12.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("16","6","3","19.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("17","6","4","29.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("18","7","1","14.50","2","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:16:38");
INSERT INTO `student_fitness` VALUES("19","7","2","22.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("20","7","3","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("21","7","4","6.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("22","7","5","14.70","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("23","8","1","6.60","9","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:16:38");
INSERT INTO `student_fitness` VALUES("24","8","3","17.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("25","8","4","29.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("26","8","5","6.80","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("27","9","1","5.90","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("28","9","2","14.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("29","9","3","27.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("30","9","4","28.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("31","10","1","12.50","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("32","10","2","26.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("33","10","3","34.00","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("34","10","4","6.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("35","10","5","5.60","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("36","11","1","12.90","4","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:16:38");
INSERT INTO `student_fitness` VALUES("37","11","2","29.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("38","11","3","23.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("39","11","4","27.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("40","11","5","8.80","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("41","12","3","11.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("42","12","4","21.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("43","12","5","6.60","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("44","13","1","8.10","8","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:16:38");
INSERT INTO `student_fitness` VALUES("45","13","2","33.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("46","13","4","10.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("47","13","5","10.50","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("48","14","2","29.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("49","14","3","18.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("50","14","5","8.90","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("51","15","1","7.10","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("52","15","2","10.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("53","15","3","10.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("54","15","4","33.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("55","15","5","13.70","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("56","16","1","13.20","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("57","16","3","31.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("58","16","4","12.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("59","16","5","9.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("60","17","4","10.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("61","17","5","7.50","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("62","18","1","14.70","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("63","18","2","22.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("64","18","3","35.00","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("65","18","5","7.30","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("66","19","1","14.70","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("67","19","2","32.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("68","19","3","24.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("69","19","4","11.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("70","19","5","6.80","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("71","20","1","14.10","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("72","20","2","19.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("73","20","3","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("74","20","4","14.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("75","20","5","6.10","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("76","21","1","12.80","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("77","21","2","8.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("78","21","3","5.00","1","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("79","22","2","25.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("80","22","3","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("81","22","5","7.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("82","23","1","9.40","6","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:41:27");
INSERT INTO `student_fitness` VALUES("83","23","4","15.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("84","23","5","12.90","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("85","24","1","12.40","4","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:41:27");
INSERT INTO `student_fitness` VALUES("86","24","4","27.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("87","24","5","10.20","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("88","25","3","22.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("89","25","4","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("90","25","5","8.10","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("91","26","2","23.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("92","26","3","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("93","26","4","21.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("94","27","1","7.40","8","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:41:27");
INSERT INTO `student_fitness` VALUES("95","27","2","35.00","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("96","27","3","26.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("97","27","5","10.40","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("98","28","3","9.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("99","28","4","34.00","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("100","29","1","11.40","5","2026-02-24","1","2026-02-14 06:42:23","2026-02-24 09:41:27");
INSERT INTO `student_fitness` VALUES("101","29","3","7.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("102","29","4","9.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("103","29","5","9.20","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("104","30","1","11.40","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("105","30","3","19.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("106","30","4","6.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("107","30","5","5.40","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("108","31","1","13.10","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("109","31","2","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("110","31","3","28.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("111","31","5","10.10","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("112","32","1","8.90","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("113","32","2","7.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("114","32","3","19.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("115","32","4","22.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("116","32","5","14.70","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("117","33","1","8.70","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("118","33","2","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("119","33","3","6.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("120","33","4","17.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("121","33","5","12.80","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("122","34","1","10.20","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("123","34","2","6.00","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("124","34","4","21.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("125","34","5","8.30","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("126","35","2","22.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("127","35","4","35.00","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("128","36","1","11.80","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("129","36","2","23.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("130","36","3","15.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("131","36","4","10.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("132","37","1","11.60","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("133","37","2","19.00","5","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("134","37","3","31.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("135","37","4","5.00","1","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("136","37","5","7.80","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("137","38","2","21.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("138","38","3","9.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("139","38","4","33.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("140","38","5","6.90","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("141","39","2","5.00","1","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("142","39","3","27.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("143","39","5","13.90","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("144","40","1","8.80","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("145","40","5","13.60","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("146","41","2","5.00","1","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("147","41","3","13.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("148","41","4","20.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("149","41","5","13.90","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("150","42","1","6.50","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("151","42","2","9.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("152","42","3","25.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("153","42","4","14.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("154","43","1","14.20","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("155","43","3","22.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("156","43","4","27.00","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("157","43","5","5.60","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("158","44","2","20.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("159","44","3","34.00","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("160","44","4","15.00","4","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("161","44","5","7.60","8","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("162","45","1","6.10","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("163","45","3","12.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("164","45","4","25.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("165","45","5","10.10","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("166","46","1","5.20","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("167","46","2","32.00","9","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("168","46","3","23.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("169","46","4","22.00","6","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("170","46","5","5.30","10","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("171","47","1","14.50","2","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("172","47","2","26.00","7","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("173","47","3","9.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("174","47","4","11.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("175","47","5","14.00","3","2025-01-15",NULL,"2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_fitness` VALUES("176","2","1","5.00","10","2026-02-24","1","2026-02-15 07:43:29","2026-02-24 09:16:38");





CREATE TABLE `student_health` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `condition_type` enum('asthma','diabetes','heart','allergy','bones','vision','exemption','other') NOT NULL,
  `condition_name` varchar(150) NOT NULL,
  `severity` enum('mild','moderate','severe') NOT NULL DEFAULT 'mild',
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `recorded_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_type` (`condition_type`),
  KEY `idx_active` (`is_active`),
  KEY `idx_severity` (`severity`),
  KEY `fk_health_user` (`recorded_by`),
  CONSTRAINT `fk_health_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_health_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `student_health` VALUES("1","46","asthma","ربو","mild","يحتاج بخاخ قبل الجري الطويل","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("2","39","asthma","ربو شديد","severe","يحتاج بخاخ دائم - تجنب الجري المطول","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("3","18","diabetes","سكري نوع 1","moderate","يحتاج متابعة مستوى السكر قبل التمارين","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("4","24","heart","عيب خلقي بالقلب","severe","تجنب التمارين العنيفة - حسب تقرير الطبيب","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("5","21","allergy","حساسية صدرية","mild","تظهر مع الغبار والأتربة","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("6","36","bones","كسر سابق بالذراع","mild","تعافى - يحتاج حذر في تمارين الذراعين","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("7","22","bones","خشونة بالركبة","moderate","تجنب القفز والجري الطويل","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("8","19","vision","ضعف نظر شديد","moderate","يرتدي نظارة - حذر في الرياضات الجماعية","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("9","34","exemption","إعفاء طبي جزئي","moderate","معفى من اختبارات الجري فقط","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("10","25","exemption","إعفاء طبي كامل","severe","معفى من جميع الاختبارات البدنية","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("11","16","other","صداع نصفي متكرر","mild","يحتاج راحة عند الإحساس بالصداع","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("12","4","allergy","حساسية من الشمس","mild","تجنب التمارين في الشمس المباشرة","1","2024-09-01",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_health` VALUES("13","11","other","ارتفاع درجة الحرارة","mild",NULL,"1",NULL,NULL,"1","2026-02-21 16:32:20","2026-02-21 16:32:20");





CREATE TABLE `student_measurements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `measurement_date` date NOT NULL,
  `height_cm` decimal(5,1) DEFAULT NULL,
  `weight_kg` decimal(5,1) DEFAULT NULL,
  `bmi` decimal(4,1) DEFAULT NULL,
  `bmi_category` enum('underweight','normal','overweight','obese') DEFAULT NULL,
  `waist_cm` decimal(5,1) DEFAULT NULL,
  `resting_heart_rate` int(10) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recorded_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_date` (`measurement_date`),
  KEY `idx_bmi` (`bmi_category`),
  KEY `fk_measurements_user` (`recorded_by`),
  CONSTRAINT `fk_measurements_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_measurements_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `student_measurements` VALUES("1","1","2024-09-15","165.0","73.0","26.8","overweight","64.0","87",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("2","1","2025-01-15","166.0","76.0","27.6","overweight","87.0","66",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("3","2","2024-09-15","184.0","86.0","25.4","overweight","65.0","91",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("4","2","2025-01-15","185.0","87.0","25.4","overweight","66.0","90",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("5","3","2024-09-15","170.0","65.0","22.5","normal","71.0","73",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("6","3","2025-01-15","172.0","65.0","22.0","normal","67.0","70",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("7","4","2024-09-15","181.0","45.0","13.7","underweight","99.0","93",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("8","4","2025-01-15","182.0","43.0","13.0","underweight","74.0","83",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("9","5","2024-09-15","183.0","88.0","26.3","overweight","100.0","70",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("10","5","2025-01-15","183.0","91.0","27.2","overweight","86.0","83",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("11","6","2024-09-15","172.0","77.0","26.0","overweight","90.0","66",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("12","6","2025-01-15","172.0","77.0","26.0","overweight","69.0","70",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("13","7","2024-09-15","163.0","56.0","21.1","normal","69.0","68",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("14","7","2025-01-15","164.0","56.0","20.8","normal","69.0","93",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("15","8","2024-09-15","168.0","47.0","16.7","underweight","70.0","88",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("16","8","2025-01-15","169.0","48.0","16.8","underweight","72.0","72",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("17","9","2024-09-15","167.0","84.0","30.1","obese","60.0","75",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("18","9","2025-01-15","169.0","85.0","29.8","overweight","72.0","80",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("19","10","2024-09-15","185.0","86.0","25.1","overweight","98.0","86",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("20","10","2025-01-15","188.0","89.0","25.2","overweight","96.0","84",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("21","11","2024-09-15","164.0","91.0","33.8","obese","81.0","80",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("22","11","2025-01-15","165.0","94.0","34.5","obese","71.0","89",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("23","12","2024-09-15","171.0","73.0","25.0","overweight","99.0","71",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("24","12","2025-01-15","173.0","75.0","25.1","overweight","84.0","84",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("25","13","2024-09-15","165.0","72.0","26.4","overweight","99.0","68",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("26","13","2025-01-15","168.0","72.0","25.5","overweight","78.0","81",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("27","14","2024-09-15","159.0","84.0","33.2","obese","95.0","72",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("28","14","2025-01-15","160.0","86.0","33.6","obese","73.0","61",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("29","15","2024-09-15","157.0","95.0","38.5","obese","81.0","69",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("30","15","2025-01-15","157.0","94.0","38.1","obese","100.0","93",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("31","16","2024-09-15","164.0","61.0","22.7","normal","90.0","82",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("32","16","2025-01-15","166.0","62.0","22.5","normal","85.0","91",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("33","17","2024-09-15","171.0","88.0","30.1","obese","78.0","81",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("34","17","2025-01-15","173.0","88.0","29.4","overweight","83.0","77",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("35","18","2024-09-15","159.0","81.0","32.0","obese","88.0","89",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("36","18","2025-01-15","162.0","82.0","31.2","obese","89.0","85",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("37","19","2024-09-15","185.0","57.0","16.7","underweight","74.0","78",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("38","19","2025-01-15","186.0","59.0","17.1","underweight","97.0","89",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("39","20","2024-09-15","180.0","55.0","17.0","underweight","83.0","88",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("40","20","2025-01-15","182.0","53.0","16.0","underweight","73.0","92",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("41","21","2024-09-15","173.0","81.0","27.1","overweight","73.0","90",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("42","21","2025-01-15","173.0","80.0","26.7","overweight","94.0","65",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("43","22","2024-09-15","176.0","48.0","15.5","underweight","84.0","86",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("44","22","2025-01-15","178.0","51.0","16.1","underweight","75.0","68",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("45","23","2024-09-15","163.0","85.0","32.0","obese","97.0","74",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("46","23","2025-01-15","166.0","86.0","31.2","obese","78.0","68",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("47","24","2024-09-15","182.0","91.0","27.5","overweight","66.0","62",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("48","24","2025-01-15","182.0","92.0","27.8","overweight","100.0","69",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("49","25","2024-09-15","160.0","82.0","32.0","obese","74.0","86",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("50","25","2025-01-15","163.0","83.0","31.2","obese","62.0","86",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("51","26","2024-09-15","163.0","62.0","23.3","normal","64.0","92",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("52","26","2025-01-15","165.0","63.0","23.1","normal","61.0","83",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("53","27","2024-09-15","176.0","95.0","30.7","obese","90.0","84",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("54","27","2025-01-15","179.0","94.0","29.3","overweight","91.0","85",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("55","28","2024-09-15","160.0","52.0","20.3","normal","92.0","92",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("56","28","2025-01-15","162.0","51.0","19.4","normal","76.0","69",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("57","29","2024-09-15","168.0","58.0","20.5","normal","60.0","79",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("58","29","2025-01-15","169.0","60.0","21.0","normal","89.0","81",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("59","30","2024-09-15","167.0","60.0","21.5","normal","91.0","75",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("60","30","2025-01-15","167.0","58.0","20.8","normal","95.0","88",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("61","31","2024-09-15","157.0","75.0","30.4","obese","91.0","63",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("62","31","2025-01-15","157.0","77.0","31.2","obese","82.0","80",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("63","32","2024-09-15","171.0","80.0","27.4","overweight","81.0","72",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("64","32","2025-01-15","171.0","81.0","27.7","overweight","86.0","94",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("65","33","2024-09-15","182.0","62.0","18.7","normal","81.0","91",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("66","33","2025-01-15","184.0","61.0","18.0","underweight","84.0","85",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("67","34","2024-09-15","185.0","87.0","25.4","overweight","70.0","63",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("68","34","2025-01-15","186.0","87.0","25.1","overweight","96.0","75",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("69","35","2024-09-15","168.0","75.0","26.6","overweight","93.0","90",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("70","35","2025-01-15","171.0","78.0","26.7","overweight","100.0","83",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("71","36","2024-09-15","184.0","72.0","21.3","normal","78.0","82",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("72","36","2025-01-15","185.0","73.0","21.3","normal","79.0","95",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("73","37","2024-09-15","159.0","74.0","29.3","overweight","97.0","60",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("74","37","2025-01-15","161.0","74.0","28.5","overweight","92.0","73",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("75","38","2024-09-15","185.0","52.0","15.2","underweight","79.0","81",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("76","38","2025-01-15","185.0","53.0","15.5","underweight","100.0","86",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("77","39","2024-09-15","159.0","86.0","34.0","obese","83.0","93",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("78","39","2025-01-15","159.0","85.0","33.6","obese","98.0","65",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("79","40","2024-09-15","179.0","51.0","15.9","underweight","68.0","64",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("80","40","2025-01-15","179.0","53.0","16.5","underweight","83.0","91",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("81","41","2024-09-15","157.0","48.0","19.5","normal","71.0","74",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("82","41","2025-01-15","158.0","51.0","20.4","normal","81.0","90",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("83","42","2024-09-15","171.0","61.0","20.9","normal","77.0","86",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("84","42","2025-01-15","174.0","60.0","19.8","normal","91.0","68",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("85","43","2024-09-15","185.0","83.0","24.3","normal","79.0","61",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("86","43","2025-01-15","185.0","86.0","25.1","overweight","74.0","79",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("87","44","2024-09-15","180.0","66.0","20.4","normal","93.0","88",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("88","44","2025-01-15","180.0","66.0","20.4","normal","63.0","69",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("89","45","2024-09-15","176.0","93.0","30.0","obese","97.0","85",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("90","45","2025-01-15","179.0","94.0","29.3","overweight","61.0","71",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("91","46","2024-09-15","179.0","77.0","24.0","normal","89.0","74",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("92","46","2025-01-15","179.0","80.0","25.0","overweight","65.0","88",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("93","47","2024-09-15","163.0","93.0","35.0","obese","98.0","82",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("94","47","2025-01-15","164.0","93.0","34.6","obese","63.0","76",NULL,"1","2026-02-14 06:42:23","2026-02-14 06:42:23");
INSERT INTO `student_measurements` VALUES("95","1","2026-02-21",NULL,"70.0",NULL,NULL,NULL,NULL,NULL,"1","2026-02-21 16:48:29","2026-02-21 16:48:29");





CREATE TABLE `student_team_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_team_id` int(10) unsigned NOT NULL COMMENT 'معرف فريق الطلاب',
  `student_id` int(10) unsigned NOT NULL COMMENT 'معرف الطالب',
  `position` varchar(50) DEFAULT NULL COMMENT 'المركز',
  `jersey_number` int(10) unsigned DEFAULT NULL COMMENT 'رقم القميص',
  `is_substitute` tinyint(1) DEFAULT 0 COMMENT 'احتياطي',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_team_student` (`student_team_id`,`student_id`),
  KEY `idx_student` (`student_id`),
  CONSTRAINT `fk_stm_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_stm_team` FOREIGN KEY (`student_team_id`) REFERENCES `student_teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='أعضاء فرق الطلاب';

INSERT INTO `student_team_members` VALUES("1","1","4",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("2","1","63",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("3","1","48",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("4","1","54",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("5","1","55",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("6","2","5",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("7","2","62",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("8","2","64",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("9","2","53",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("10","2","56",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("11","3","1",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("12","3","61",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("13","3","49",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("14","3","52",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("15","3","57",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("16","4","6",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("17","4","60",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("18","4","50",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("19","4","51",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("20","4","58",NULL,NULL,"0","2026-02-22 04:38:42");
INSERT INTO `student_team_members` VALUES("21","4","59",NULL,NULL,"0","2026-02-22 04:38:42");





CREATE TABLE `student_teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tournament_team_id` int(10) unsigned NOT NULL COMMENT 'معرف فريق البطولة',
  `team_name` varchar(100) NOT NULL COMMENT 'اسم الفريق',
  `captain_student_id` int(10) unsigned DEFAULT NULL COMMENT 'قائد الفريق',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tournament_team` (`tournament_team_id`),
  KEY `idx_captain` (`captain_student_id`),
  CONSTRAINT `fk_st_captain` FOREIGN KEY (`captain_student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_st_tournament_team` FOREIGN KEY (`tournament_team_id`) REFERENCES `tournament_teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='فرق الطلاب';

INSERT INTO `student_teams` VALUES("1","79","الأسود","4","2026-02-22 04:38:42");
INSERT INTO `student_teams` VALUES("2","80","النمور","5","2026-02-22 04:38:42");
INSERT INTO `student_teams` VALUES("3","81","الصقور","1","2026-02-22 04:38:42");
INSERT INTO `student_teams` VALUES("4","82","الفهود","6","2026-02-22 04:38:42");





CREATE TABLE `students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `name` varchar(150) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `blood_type` enum('A+','A-','B+','B-','O+','O-','AB+','AB-') DEFAULT NULL,
  `guardian_phone` varchar(20) DEFAULT NULL,
  `medical_notes` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_school_student_number` (`school_id`,`student_number`),
  KEY `idx_class` (`class_id`),
  KEY `idx_active` (`active`),
  KEY `idx_name` (`name`),
  KEY `idx_dob` (`date_of_birth`),
  KEY `idx_students_school` (`school_id`),
  CONSTRAINT `fk_students_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `students` VALUES("1","1","1","محمد أحمد العتيبي","1001","$2y$10$TpYo8uDfLU8BZt7xb8vY/ubTQ0mlgchekQ6S8qXMKTb2tF1wUB1C6","2008-05-15","A+","0512345678",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("2","1","2","خالد سعد الشمري","1002","$2y$10$wHiFMsHNccA4yCQ.f4vawOnLvO.n.mRFUTY1ak1l21s27q4ZikNGO","2007-11-20","B+","0587654321","حساسية صدرية","1","2026-02-21 14:17:55","2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("3","1","4","عبدالله فهد القحطاني","1003","$2y$10$jLtC6Gh1amMA9Hfzvkr8r.1NkncwJ5IonpEeeQXQBwxHYZrwyvsX6","2008-03-10","O+","0556789012",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("4","1","1","عمر المطيري","1004","$2y$10$oWMG8ud5dC4JSyLgWlI1AOjHQx/h4eXgpEdJiaWiJUR9UrGWvTd6C","2007-07-06","B+","0510255673",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("5","1","1","عبدالرحمن الشهري","1005","$2y$10$rnxslwbvvRmqypEWzpIri.pPgPEr3DMAY1Ygez0q3/JhuNEMhJASu","2008-07-14","AB-","0564426422",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("6","1","1","فيصل الدوسري","1006","$2y$10$0ZvLX7syx3Fr.z30lNjueesnpLCf1KUaRoxGvSxhSgbva71caGASW","2008-12-11","AB-","0575591835",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("7","1","2","حسن الزهراني","1007","$2y$10$XY1ego9jMcZ8tVbNuVoQg.sMXHD92RJUuUA.lG6VLgUr3h0V086Om","2009-09-07","A-","0542836412",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("8","1","2","ماجد البقمي","1008","$2y$10$LBElHtLnUDClrX03RasSx.IBsPTbu.cpLFZX.EaDpjpybqpyaJBEW","2009-09-18","A+","0569943805",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("9","1","2","إبراهيم الجهني","1009","$2y$10$3TCnHKNHA36.Uaf2MQhB6.w5R2C9BklqJukNZtN8XRyz.sk49ieG.","2010-02-09","A-","0560736079",NULL,"0",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("10","1","2","أحمد العتيبي","1010","$2y$10$25CPOOwBseK.lhPx38nsYuP7mdfk492c5BAnt.L/ImdIu60gJfa72","2009-11-06","A+","0552661715",NULL,"0",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("11","1","2","تركي العنزي","1011","$2y$10$tqxwwwnb1ay2R3sMXCJVAufT3xo6gdwv6Th3Ki6ylAONLAxv.LOAu","2009-11-22","AB+","0572623308",NULL,"1","2026-02-21 10:43:57","2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("12","1","2","طلال الشمري","1012","$2y$10$INbAL6TIvplOEyw2tdsgO.clCXIm4wMnDz0OPdhuKz1NBOhaKoG5G","2008-07-12","O-","0517431510",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("13","1","2","فيصل العتيبي","1013","$2y$10$GJr4YRSYSJ6hocY4541hHu2gzYy2njzXE6H7Dfd/FAtG7jw1L/JnG","2009-01-09","O+","0565013596",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("14","1","3","محمد العنزي","1014","$2y$10$PDfb2BRR0hySWiojLq7rReJPDWgOVhsV4Ah9Sa1Q8z6Bzyn7j2V6.","2010-06-24","AB+","0524365431",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("15","1","3","وليد البقمي","1015","$2y$10$6r2g76qTWXd06h9X98FfyeONU4KRKr.oXhoFyz1y8KBIsbkOmXata","2007-03-27","O+","0581758197",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("16","1","3","فيصل الزهراني","1016","$2y$10$LdsQ2vJ2wj0zp1T2MVx20euo/emE9ghuuBqS7FmV/1s3nSyGg0lg2","2007-02-19","B-","0583178330",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("17","1","3","تركي الرشيدي","1017","$2y$10$wVmORCdO5chbefD/7w9P4eYJuyBLqRDiWZmRTQzFbtOgJiwohGdHS","2009-01-12","AB-","0573471372",NULL,"0",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("18","1","3","تركي الشمري","1018","$2y$10$D2esAilVmKM0PTcAH7Qb8.bfFgCiRqngAhhowztKYlzTPo/9xSH/.","2009-05-22","AB+","0572378669",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("19","1","3","مشاري الجهني","1019","$2y$10$9NJolTgOuXQ2vq0Mmvk9HeAL9m5BqaCYmb/0geVx0YgRQsv0PxGb.","2007-10-06","O+","0576008212",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("20","1","3","علي البقمي","1020","$2y$10$4LUWW9vT.9Hjst1GCpMXK.i2QEOBgipOdVEoiuqY1JWauvvymp4Gm","2010-07-12","A-","0544087144",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("21","1","3","مشاري العتيبي","1021","$2y$10$c2iBMMJkuyWewBUHPttsAuhB/11Lq93Ayzu7/9mFSDJQnnz/CUqMm","2008-03-04","B-","0536819685",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("22","1","4","حسن البقمي","1022","$2y$10$ZVXWzB03Am/vE4dbtjC3quO3o0LIxffJLZrBN3tVPoNR8HfrHCko.","2009-09-07","AB-","0573777890",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("23","1","4","طلال الشمري","1023","$2y$10$/zVdVQ2vdmTcWl5b.cE7SOiAD1Qmrhgrs3UiKq7s7rAuqpJgIHBjG","2010-04-18","B-","0555373251",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("24","1","4","عبدالله السبيعي","1024","$2y$10$IPCtaItXky2y8g45cwIsI.jCINhGrNTwFipKNQos2D8a2B9bi6NfW","2010-10-14","AB-","0585166162",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("25","1","4","سلطان المطيري","1025","$2y$10$esUZN/vumLwIHKZ0TaN1Duo97PDPqhWn9vF5O2y6P1Tra1Xd.e9zS","2008-05-12","O+","0512629312",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("26","1","4","عمر الدوسري","1026","$2y$10$tij.uNz6wT0ZOG6y6tdJmerfWVmznoDulC/4otTOqqsuRFNrV9Ora","2009-12-21","A+","0564452035",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("27","1","4","حسن الحربي","1027","$2y$10$XkHT2MG7jX7/casd5QxR3.uCeNh1cUVDUNpe2RZV2tUWX0Vp2H9ne","2009-08-23","AB-","0536084740",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("28","1","4","طلال القحطاني","1028","$2y$10$InjMvSUZfvFG3uscZBeMuePcyecUioXzpjJ8zNYrz6gWP5Cm1BEsO","2010-05-12","A+","0565885342",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("29","1","4","علي العنزي","1029","$2y$10$ugjN6mHqbLyQFBxLO8F7mOHO2X4TMbXHo8ULgUpcbPGlxJI7XNvJu","2010-12-07","AB+","0553139658",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("30","1","5","علي الحربي","1030","$2y$10$t0rtXbM2shh6SraUavVt.usP8OyVhxtUErhgaiIzFJj.vySUR537e","2008-06-09","B-","0542555951",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("31","1","5","بندر القحطاني","1031","$2y$10$JfZHKBzgRRHJxzYht/6TY.0a9cX75PAF7yH.KsSzmjNdsLnrC12AW","2008-06-08","B+","0554086461",NULL,"0",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("32","1","5","يوسف الزهراني","1032","$2y$10$CUbglZjgyRmdaHVec1Eaeuo63wp2EID5AOTguL4CUb90NxfE0oxHu","2007-12-05","O+","0515790480",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("33","1","5","وليد العمري","1033","$2y$10$J5uOCJO5N9UKLtNHVE3jlOAbFHJOD/KTgP3mK84LdOMTjL1qCf7Jq","2010-09-02","O-","0537372194",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("34","1","5","عبدالرحمن الغامدي","1034","$2y$10$HQhgO68KDLc12FAy5yP83uMjHxIdBeOgUv1GSUXfNJzRzVl4Ad6R2","2007-10-20","O+","0523819798",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("35","1","6","خالد الجهني","1035","$2y$10$WvSujFfy6UZAq.R/8WGmEukldAR0wUiWWq4jybYwJFkony4mCTgwu","2010-07-17","A+","0568564623",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("36","1","6","عادل الشمري","1036","$2y$10$epEA2hTlPYhg45zz.E3fhOtfGl5ivaHQhpMJOy3JYdk25Wk8d1Pvi","2008-01-15","O-","0599346890",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("37","1","6","عادل الجهني","1037","$2y$10$V4P3zJrdvfPi4s7LsF8EGObf5yjYk0lmx/H0TBIZKtidG0.XiuQOq","2008-09-26","B+","0533199892",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("38","1","6","محمد البقمي","1038","$2y$10$ys/g19Il5J6Y1R4Q8mhPkuwc2U1yv4ypiSK7yoQqqn3ZkihlUWYxO","2009-12-24","A-","0587104856",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("39","1","6","علي العمري","1039","$2y$10$OHN9Vb2F/TVqnEUAAZQ1Ruez9ndRe8cBRSvObWzXp8gEQ8nOtoB9i","2009-01-04","B-","0557439122",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("40","1","7","بندر العتيبي","1040","$2y$10$5Xgbal31tqw.v5uzuKOc6OQuz0GergXFNy.rAn.Ouf.CBFEXn5qaO","2007-01-03","O-","0547336271",NULL,"0",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("41","1","7","حسن المطيري","1041","$2y$10$w2casIo/acf3u1KGrfeeZeavwX9bSiSlROnE/ZTEqecmEvZg52kEa","2009-11-17","A-","0553093809",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("42","1","7","خالد العنزي","1042","$2y$10$R.ghnKKowGyMxJbM/q2AGuHRokaC9panbwqA8Sfkbbqfe72PkD35C","2009-07-13","A-","0593738264",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("43","1","7","عمر الحربي","1043","$2y$10$e5/roGvNYJ./GcuOYrwtxeFy/TjAx7wIuLBFHinxW6g65Y/tek5cO","2007-09-15","A-","0512910247",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("44","1","7","سلطان الرشيدي","1044","$2y$10$krGLin1e85Zw0VunSCYsjO4L6BdxMgfNTArvA3sZfMcJkiIqI7xre","2007-02-13","A-","0534079978",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("45","1","7","راشد القحطاني","1045","$2y$10$Ob82HS7BzBSmVQivthWwZefb2F5NCB5U9zNkrdac8fP4ljalk38gC","2009-08-06","A+","0529925640",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("46","1","7","فيصل البقمي","1046","$2y$10$6F.9G1q5Lbn8WK2tYPapAeHXYOWhyObadZLaGAuk1rgwj3vurohXq","2009-04-18","A-","0515947117",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("47","1","7","راشد العمري","1047","$2y$10$3tySYTe0/X4uNb2cZMHmLeEgsNmew4aOXlvxGuoF3Gq4P1swfMAG6","2008-07-24","A+","0594622865",NULL,"1",NULL,"2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("48","1","1","ابراهيم عبدالعزيز ابراهيم الرويس","1151387352","$2y$10$9oEE/KM0kHgr0vhjswbfo.1Y9yG7Hmnchf20zNYUBtEWLBbRdRlXa","2008-05-15","A+","0512345678",NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("49","1","1","الوليد خالد بن حرشان الدوسري","1151587043","$2y$10$Ov/74P2iMUmUx0eZclDLLuY6h8Z.4yqiG6guK5QTz0dDOfyN4N906","2007-11-20","B+","0587654321","حساسية صدرية","1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("50","1","1","تركي ماجد معتق المطيري","1152248124","$2y$10$7jdsEkpnGPuqtkpKQlWT9uCN0NJ8My3F.lmDr9LCKCz92OE/KZ3im","2008-03-10","O+","0556789012",NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("51","1","1","خالد حمود حشر القحطاني","1152546519","$2y$10$dYUgVHtsJemQJWTn8s0ll.oq4f7q9kVGJMzRvswL4sZd0bxIVpMKC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("52","1","1","زياد احمد بن علي الشمراني","1152699987","$2y$10$KROexs0.QgY5jq.iNIQRJ.3NdAq/Wta6F1apOZNDTJCAYMRT.ndYa",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("53","1","1","سلمان حسن عبدالله البيشي","1147847360","$2y$10$7Xj78xL8.Ul0kn36JWLSCulk3Lgp97U1hEzEFP1r3fJti3UMDbDs2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("54","1","1","صقر قبلان صقر العتيبي","1150165734","$2y$10$p.50c1CpgnlB16UTXehRYuZldigslyqNkrmjjAcwDalQZiGl22rUS",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("55","1","1","عبدالرحمن سعيد عبدالرحمن العتيبي","1148909789","$2y$10$F6lXQFWJAwGOzoVsE/hkieU.nib0sDe9c0lPR/upVVdwoa7oKfCfy",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("56","1","1","عبدالعزيز محمد بن عبدالعزيز التميمي","1150741153","$2y$10$7kpLMFwDoz7xjxHg7oi8L.JxjJuOSKknQA7zfigS4lTHfnZ0mhqQS",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("57","1","1","عبدالله دواس بن مشلح الدوسري","1148295395","$2y$10$bAlIR2xWo/D5WDW/2oHiqOJwZOAHBiQVwtn/mugRSZXrQwpZcXudG",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("58","1","1","عبدالله سعد عبدالله القرني","1152082457","$2y$10$wvTmhh3XjMOwaJGn4jVvv.fbi6ucADP/NMqllGNkreUeohQkNL4p2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("59","1","1","فهد عبدالحميد فهد بن طلحه","1152001374","$2y$10$OFHRLfl22StUg1zMgay5O.fteLaq9KNu3tEnkgGBYOocarL/bimem",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("60","1","1","مازن فهد بن سلمان المطيري","1159708989","$2y$10$vEKHquqGQHdNaHwQLTf39OBdIz/WL3kKMTQ6nrq9KzHG6D1SBTYNm",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("61","1","1","مسفر شبيب بن مقعد الدوسري","1150825923","$2y$10$g6jhuL4wJxBQXfaxt3krgOw5K5LWylni0j.bV2uglcVHft53O.yoi",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("62","1","1","ناجي برغش ناجي الدوسري","1146932494","$2y$10$tT4rdXx94BU7AZYJBzNfFud4I7aXpCvfNbt0I27sySH6Sv03UBolG",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("63","1","1","نايف حمد بن محمد العمر","1152319412","$2y$10$S0kudKPB4GqseZdN/RhZjuyDL1qRYrs0SR5OpoJr4wwdDNMliGE3y",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("64","1","1","يزن حاكم بن ابراهيم الدوسري","1148551813","$2y$10$ygmqEwEOZ5RroYAdS2pIkeVznkzJnrK7Mo1EwJk2Wa54rTFAVuHeK",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("65","1","4","أنس السيد عطيه جاويش","2432655849","$2y$10$WsZa0Dt17tfUtQwxHvbn8umVNRnUhMcHwU9O2qyrKnz9.0JrPVg5W",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("66","1","4","احمد سلطان راشد الشلوان","1148142092","$2y$10$QL62Z6EMzs1Q6SNjfyFVqeugDCikX.asaynnag5DQ9Z98uq2oTIia",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("67","1","4","باسم سعود عوض الرشيدي","1144966965","$2y$10$rwPAoZ5OvwjKqtmEQeoyhOR0vyVEY76Rm2pjS4KLruKRXUjTLQG7i",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("68","1","4","تركي عادل مطلق العازمي","1161321599","$2y$10$19RipibJW4ik6EQP2VWejuLDQoxv6TgxorjjU.nXzrIwQK.WDlk7G",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("69","1","4","خالد عبدالله بن علي بن عفتان","1146343601","$2y$10$tdLerzq6RgPCteKSq/3.4unJrKeqw5tNJQ8mgvC9hKv3hx6nqUwda",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("70","1","4","راكان محمد بن عبدالله الدوسري","1147603409","$2y$10$xhfi5aVbrOkeQg/NWDJWteeU6n5gPadB9EVBHf15y3EK2GHwBcn8G",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("71","1","4","زياد وليد السيد الكتامى","2315235305","$2y$10$i.dKUqM/b5ZXkbjHU1kPx.o/NZsfBPhDsVHwIHuLtRJ8Mtb5.6xr6",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("72","1","4","صالح خالد صالح القدان","1140641323","$2y$10$wl58icU4lA./6.oSTKX9a.O6Wbndb.BDHnDHFrZVLBX7mToCIVb0K",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("73","1","4","طارق عبدالعزيز راشد الدريهم","1146122633","$2y$10$WSF0N0ljwWNxyj2z2MchdeOjhNb1W73tbZ0epGdxrOpVeFoNS7MQ.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("74","1","4","عبدالاله محمد مناور المطيري","1147901639","$2y$10$7nXPbXUA/FXOfa95klp6h.Yy0e2T1fl4smVMsOarstieZr0hQtJp.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("75","1","4","عبدالعزيز عبدالله عبدالعزيز البياهي","1147610651","$2y$10$IzT0/Bw3vEBWoUEf/KBtxewm7m3BDURZeLyBB8ZOgg1eGeONsuPUm",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("76","1","4","عبدالله سامي علي المكاوني","1148400755","$2y$10$2kJEp6vwbV5RR2Wrw7szoergV4ZjX5IJYhYZx3OUDrqdhSmXpd2je",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("77","1","4","عبدالله محسن بن عبدالله السبيعي","1149352062","$2y$10$8Cj0G3JFwpNx4rx7WyqiZO.9.0Hu8Zan8QuLRzoXTZyszd8o07t1i",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("78","1","4","عبيد فهد عبيد الدوسري","1146690829","$2y$10$0NHhvCKzMUjpfwMAB86xTu/LhdJTzDCbp70nVJmcJ9MNlZBsE2gx6",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("79","1","4","عماد غشام خضران الرشيدي","1145518542","$2y$10$IVyPa1kieeeQA1O/Tr.kIu0pHuoD.6Pct/1VH6eOVN5bzmGff8f6W",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("80","1","4","فهد مهناء فهد القباني","1148181645","$2y$10$ItvQ/UuXeWu13WzLOPQs1eKx8EZ..DivUNYdnXVfjbxzx5XIdM/Bq",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("81","1","4","فيصل سعيد عبدالله حسن","1149743732","$2y$10$COSOTex3ukDpsNPtM37Mb.qLYrByK/Tqb37ri.d17k5liuaomXj8.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("82","1","4","فيصل محمد معجب الدوسري","1146521636","$2y$10$qH45zUx7D.w0rdx8L0PnjudgawhNA1xa2YSBvzlguHHzLefsZE2.u",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("83","1","4","محمد حسن بن محمد الباهلي","1146843485","$2y$10$A/NTaSCsik5TH0rxPXsisOF8f/NRQ70LL/t3awkU9ShZEOqAxR83q",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("84","1","4","محمد راشد بن محمد المري","1155614876","$2y$10$rAH1m.rQkF0kSk7zlmAcw.Mya9NHKqHD9TGHaDhvOQa2aQejyyDd6",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("85","1","4","محمد علي حمدان المطيري","1147831497","$2y$10$T6xXP0rG76iwpP2hisuNruZWVLo0g5mIZrErJ1DEN13rLYwFvkNtO",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("86","1","4","محمد فلاح علوش الدوسري","1149999151","$2y$10$qRD6NxUrouG/aHR.ZBCXr.mfyjJm3WVjIPD3AV..pUIgUPVTKWdmy",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("87","1","4","محمد فيصل حسن العييناء","1147198962","$2y$10$dKzK4B3.iiNNjRYkTJ4gce1YLDAN./7CUoyiw4wskF1eDsdYRUz9C",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("88","1","4","محمد ناصر محمد ال مبارك","1146691454","$2y$10$bnr1.PDDWPCU58W2LSQlQ.iN5DfkB3DYIMzrjpHF8.nuw5KxbSU4y",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("89","1","4","مشعل حزام بن محمد السبيعي","1145454656","$2y$10$nMrOKLJ.t77ijVEkXdsxpOfS19WjScVi5a9rm3GtwvAAi9YvuH1FC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("90","1","4","مشعل فلاح بن عايض العنزي","1146675358","$2y$10$Pr77T0XcH0cUAkGiWjc2/uTGBHB6lV4FI7v90fYLYRiRUz0hhyHZq",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("91","1","4","مهاب يسري عبدالوهاب عبدالكريم طيب","2585394311","$2y$10$OIr/Yg/dCmWftMsZy7G1fONtr/86yFgOTI864IyrvW3AHTG401SUa",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("92","1","4","نادر تركي لاحق العتيبي","1146357098","$2y$10$tkfcPsrPJVFwvfITpUuFhOEiIkQ2/OUpaHmUnmu9B3O7s9AbiG0Hi",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("93","1","4","ياسر أحمد هادي عسيري","1147669327","$2y$10$CgE2QGCOA78qs2qhP4gDluAyPljw11sXRsU6PZ3cMPLJmfEccq1Dy",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("94","1","4","يوسف حامد حميد الرشيدي","1148879545","$2y$10$9WUklcIHKwuwqtB2GvF4.eFBXJoAdKsk2G49EDVNwJOuE5cYaFMVm",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("95","1","5","اسامه سعد سعد شلبى","2281273884","$2y$10$qcWs4U/PgtEd7TGv.TXiqeK.76QUzYKtWsizudsRpGH3Ff/q9f7s.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("96","1","5","اياد بندر بن مقبل المطيري","1144540968","$2y$10$JItvvRKQX3eFSWUVaeSSYeV3V74dy0GcQHmOd4f6i1p9Ia7qQJR.e",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("97","1","5","بندر فهد محمد العتيبي","1148667510","$2y$10$I0R8NuETySmk67ywd65mNejVK9BT8Zu1RU/Jxp6kvDzb9Gadf0aP2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("98","1","5","تركي خالد بن عيد الدوسري","1143862900","$2y$10$.p7g8n5ND7W.25vkbL/7N.sio5hoLYNZQx7QYThOgbZLdy2sbNmb6",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("99","1","5","تركي على عبدالعزيز الشقيفى","1147727679","$2y$10$pcCjSH0AXqr8y/htZfH/uuUJeQWQn8kQ4YpELhF31rMzzMglqgKue",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("100","1","5","حازم علي عائض الزهراني","1149176628","$2y$10$pU5s.0CnkNkcDP4OFrwh1uUcQTLx/tbj342LDRjoKjnfVqIUp2FFa",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("101","1","5","خالد رفاعي قريع الدوسري","1153976905","$2y$10$vSWkJvWDrkoajXw6RwFeQ.o6U26CN/rCorwScslTe5pUNPioenLh2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("102","1","5","خالد طلال علي الشقيفي","1147600892","$2y$10$08yMywKfsA8sA3LPlJXBnOm8exhl4yyh1sfcadVtiMuMdeer/2lpu",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("103","1","5","راكان مسفر بن مقعد الدوسري","1145575245","$2y$10$9s.GoNqNFHgD3cIz6F/C/Ofv3HDIrk97tJqwrrEUxsStmHZKzf.I2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("104","1","5","زياد محمد عبدالمقصود عبدالمقصود","2272907805","$2y$10$ugyykYnKxdV8EWqrxx70Su95wr1EJRaHgOPfnPT.XLlsJ3.7FNCzK",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("105","1","5","سلطان عبدالرحمن سلطان الدوسري","1148989898","$2y$10$lj4UpVjZr5fMV.buEtjKwONvBF4oKK/QQtVywA0D9Z7bbqI2v7LB.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("106","1","5","سلمان سعد سلمان الدخيني","1147432734","$2y$10$zZJDNUwI542odkJUnP84xe5Ba2bxeisHm.OMm9TUpWY7H93kuxck2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("107","1","5","صالح عبدالله صالح الموسى","1145795272","$2y$10$oYAlLY6yToT8ZX9f2Wp6C.jgYurGoe5mh458xOWtD68VIHUs4OJzC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("108","1","5","طلال يوسف بن سعيد العتيبي","1147406290","$2y$10$4e3Or3EpjxPudCqzERlZpOYrx.i9NktSmkZa4rQAPGrVjJE1naWK.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("109","1","5","عبدالرحمن مبارك بن عبدالرحمن العقيف","1148653395","$2y$10$QM/ElKPowcX2QxeOzxvtte60RpbVBaCVv0.a7LpaoBCXr.LKcfyhy",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("110","1","5","عبدالرحمن محمد بن موسم العتيبي","1153338023","$2y$10$21aFt6yUeK5uhbZcsHNdU.BnAFB/6KiZL.jXQmACrm85ONR5sC.W6",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("111","1","5","عبدالعزيز خالد ابراهيم الغنام","1145159438","$2y$10$7RgfN/3spCJPAFlleEgowODCXsB4pfqeN1hUwcu3uxJOEpsfrCsLK",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("112","1","5","عبدالله جمعان بن مطلق الدوسري","1147820045","$2y$10$XzcSJVpAk.uuIpEzSJiqweE2cDBYY4cFwpcLBsUcD0rRb2TKckk9e",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("113","1","5","فارس سعد محمد سعد عسيري","1147327033","$2y$10$.l56UwLEoU57fK4R7sK/uuqxagGy1N0ToC9qvONOdNnitKGakSiCC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("114","1","5","فهد يوسف عثمان المطرود","1148909623","$2y$10$IDjHfMS.l1aBbVDZmqxck.IFmin/JX/OLL8teMURk0nsQfMVz/Ukq",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("115","1","5","محمد عبدالله بن محمد الخريش","1145205132","$2y$10$cMcyjAOa6eJEMKJaPtiF7u/je20BwjpCPFvwE0bJhpGOTfigkY.mG",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("116","1","5","محمد عبدالله بن محمد الخضير","1147651317","$2y$10$5E2ve03XqJQ7kEA8gHSH7O9mQStv5wk64m4NUEKbCNMc0fqfysK7e",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("117","1","5","محمد فالح محمد البلوي","1146575277","$2y$10$Obiis6B5XDZH9lzNKP6O.eLmcVz.GVY/kjKG7Kv1BRs1tWjlg/SJ.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("118","1","5","محمد فهيد بخيتان الدوسري","1147582223","$2y$10$hklSSijCgGMGLAvCNco45ub21mdlJHmV5rVBchgJMNbsXDxOUEiZS",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("119","1","5","محمد مهند بن محمد القعيضب","1147095424","$2y$10$16mn.S2DEPQeUY9ymNZt9OdjyMYMZ4M7iiPhc1axu5580yykFvDCu",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("120","1","5","مشعل مسلط محصن الشيباني","1158408862","$2y$10$T0bZeHH1UwRPAmKCIzWU7unkIAuNxRHgjn5OA14OdNZSp1Nru8QlW",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("121","1","5","معاذ بن إبراهيم بن سليمان الهندي","1146083439","$2y$10$klka2cqXEw2NjYXw90xv1ORglnKiNsp74/.E0Q9g8WRk7uenJGS.2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("122","1","5","ناصر عبدالعزيز بن خالد المطيويع","1148375619","$2y$10$2XtdUVYUFz6Nx37VgdHI1.GRKTSbJRdNrBP8JZKum6xj55eheXfC.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("123","1","5","ناصر عبدالله سعد البعيجان","1145623151","$2y$10$442PXQpl7ww/4Voj6KBDWeQ1CltUycST57bfQ9tekUAir4J5GjhCC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("124","1","5","نايف بن ممدوح بن عقاب بن نحيت","1153492663","$2y$10$Sc1XSFV/htua.qCcIJ470eYpTpfsf5nNqABTIMQicR6UMojhaayNO",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("125","1","9","أحمد شقدوف محمد عقدي","1146521727","$2y$10$3xEC5mvHodYot3FIKPS3QuCcIh7CtVxFAHTnKd9tNyQ4EurZn1mTa",NULL,NULL,NULL,NULL,"1","2026-02-21 06:15:13","2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("126","1","9","تميم عبدالرحمن محمد العتيبي","1148623059","$2y$10$GawH7jHwdhu35qzOPsDXDuAR9JrhIAeC7PhGT79QJjp.hwWYc9pPO",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("127","1","9","خالد ناصر عبدالله المقابلة الدوسري","1142615507","$2y$10$eCYWJ.kgdHrzdhEfLYFPAOPrFBA1oW24.QQt/qFxMgyi9ZXOC/y5O",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("128","1","9","درع بن ناصر بن محمد الدرع","1148644089","$2y$10$vOtyNvCPOccO2zYdtpnu.eXmwRQBu4zv4u2JVt6TuChRjc62eu.c2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("129","1","9","راكان عبدالعزيز عبدالله الداعج","1146753999","$2y$10$LpKEZM4aFeon3wI.d4UmV.nqxw.6NL8GaBX6drvNOnYNi9xs.aAqG",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("130","1","9","سلطان خالد سعد الزمامي","1154690927","$2y$10$yBjQOdAXxYETPMbJjPyyaeczOiCVYvLLYQZPTJ8r1YRrR8EZ/XslG",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("131","1","9","سلطان رشيد سعد الحربي","1145444046","$2y$10$mJqQ6DLClzZmKF79Kvo0SuYv1Pd5nEo0k8xHxTHWVEZcvCOeyz8OK",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("132","1","9","طارد عبدالهادي ضيف الله الكبرى","1145308498","$2y$10$Fc7zu0UMzWOwxczKE8KL7OKPyfOciw/bi.wtjWlnkS6OpmSC5NFIu",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("133","1","9","عبدالعزيز ناصر عبدالله السبيعي","1149034546","$2y$10$VRWiImgpefP0jS6Pjtd6XeubwBkiEIgBOV0UniQikX6lqYLSztYvK",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("134","1","9","عبدالكريم فهد ميزان البدراني","1146223019","$2y$10$YHvuGUhuKSZpcCIF7SiEeO.dQExCn/ctKE.NJ7FM/ceBnos5JNZBS",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("135","1","9","عبدالله راشد عبدالرحمن الكنهل","1148125436","$2y$10$ZH6FABFpYJoAX.MT5XP1O.MPaRchCe5//ItUdBz/vPFlu6yqQ7ofC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("136","1","9","عبدالله مبخوت محمد الدوسري","1144720826","$2y$10$SOBlR4s3lpUwiPNjCuMJEOMvCt25WzWPpmDtlL0kiMuWcrFLsk9wO",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("137","1","9","عبدالملك عبدالله محمد التميمي","1147295370","$2y$10$SfzTXPG04zQSyQHw5LGvGuyz1PCtuECkgj1j.1PoSnkzSop/18oU.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("138","1","9","عزام طارق ناصر الجمعه","1148192048","$2y$10$REndww4zPup3kk3imj/08ezQ2O2lBfuS1BybtQHrdhQAMX7xuKaEK",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("139","1","9","عزام فهد بن سعد الجهيم","1149668160","$2y$10$ujm6XOnM0mAfc0Z1CE/toOrOVrPHjTB07BCLIhP.PF0zBglc7ToUK",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("140","1","9","فراج ناصر بن فراج الدوسري","1151582861","$2y$10$5AqULSyyWurEHxvzhBvv1Oux2PVCNDFGoqVLSQobHMTMWfwqRDKwO",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("141","1","9","فهد خالد نفل الحارثي","1147289316","$2y$10$Eo9/fxF301ZiwBgF9OQd..5NEm1Sdi3PBZGEPtju2HS20USh0IO6u",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("142","1","9","مشاري خالد بن هلال العتيبي","1145764260","$2y$10$zTdbhdooOiseE71/LBll3Oq6TwpfNedSAXUUe5e..TxlRApKoWDv.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("143","1","9","معاذ بندر بن ابراهيم الفرحان","1147262826","$2y$10$3gC7hjR/C9nRr43NNH9yCultZn73oLDGH.Ut/5hcm0sYn59PDNPmu",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("144","1","9","معاذ مناحي عايض البقمي","1148125865","$2y$10$A7PgRWWEjsF9EXCgBpL5TOxK2WXyEU1UBQVDya8oRDRCY2H/8CcK.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("145","1","9","معجب سالم عجب الدوسري","1148964529","$2y$10$qaNgT1Z4nPXR0g2187tI8OWUNGh7oVN4PrM1.2Cf/HbTEmK1LKn0y",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("146","1","9","نايف احمد بن ابراهيم الفرحان","1147602039","$2y$10$kug39SEqvdlNkdNB1NggeeZpyj1opEdDCYdJPiMOimx9EncgonGZC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("147","1","2","أمير حسين بن أحمد محنشي","1153670979","$2y$10$zuXLxKuT4/kncKb2MaNA/ep9i38o3195iBJq7OmcKpk064K4uaJ6W",NULL,NULL,NULL,NULL,"1","2026-02-21 14:03:07","2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("148","1","2","راكان عبدالله عبدالعزيز العبيداء","1152855472","$2y$10$ACjc5o/5dZvIILd/1CIWceQAlwMRtPvoIbsG3SfnHlTb7.e56DxKC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("149","1","2","ريان عبدالعزيز بن سالم المبارك","1153382880","$2y$10$EumRZqAH9gmvy94CwxoBIuBpRLGPlzl7/dLWCDy5PK7TOXPn.JgKy",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("150","1","2","سالم حزيم سالم الدوسري","1148082710","$2y$10$aqFG6z.wpuxoqaSroZN3t..PTkemGU9IQw84qpWiAMMmIgtQwuiBC",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("151","1","2","سالم خالد سالم المبارك","1152767503","$2y$10$Dsc5dsPXiObkUG7s0peI5ePB7Dp/OOjUWARtc7AEcgJuWZvX2v9I6",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("152","1","2","عبدالاله ابراهيم بن علي العبيداء","1153152812","$2y$10$jMrvFR4O7NXfmJnhjk6rBucAxj43VbNbcQjL1LdFFEzJtRQKGfc7W",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("153","1","2","عبدالرحمن عبدالله بن نفل الدوسري","1154521205","$2y$10$Nb/hL7sC2HLtullk/PF35.b9HGInl/NMk29hqDHLwJA3SY5a7DRgS",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("154","1","2","عبدالرحمن يحيى علي بجوي","1152797682","$2y$10$cpZ90ekjmnWrBl6mzXQ8d.UPJO/vfDylAHXjSxNbH4p.AzWq0CFF6",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("155","1","2","عبدالله عبدالرحمن بن عويد الحربي","1146635006","$2y$10$JTyY/yFGojrk9/vE05Rz5Ov.A4q2rLRKV1l6H9JQGlAmcRuQRYR6O",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("156","1","2","عبدالله عبدالرحمن ناصر البعيجان","1151476254","$2y$10$c7pn9DTkYnDF2/wimGYwUen.0./l3GhX3xHHVHf/8LIj4f8v/PE3C",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("157","1","2","عبدالمجيد حسن محمد عسيري","1151834700","$2y$10$WK8pNyfiZMoF9kInYhImReBV/eEsU6srrSiZ8JRHFOZBPwzeC5zY2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("158","1","2","فايز أحمد فايز الحربي","1146675259","$2y$10$YvpqpSx7ZY1Swele0hvOMONO9rPNywCB5tYjZPmYJKPPzmzuXiTAm",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("159","1","2","فهد نواف فهد القباني","1173207109","$2y$10$OVN9YNPTOATIqqaRO76keeLSnCnLxYEMxDHMdAMNGwL0VXLh8.1Ji",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("160","1","2","محمد بدر بن محمد الدوسري","1151753389","$2y$10$WFV45bXlIiWhD5Qv9IEWJOiimz1UiLjVsBg6p1WAngkTGs7YFS8Se",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("161","1","2","محمد خالد بن محمد الأحمري","1153558240","$2y$10$rd1/bAQJRs/BMyiXvqUijeufQOlTCHgT7a71VaIRSClc6wfjRPgP2",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("162","1","2","محمد ناصر معجب الدوسري","1152446256","$2y$10$GluTF1/TjVq4XGfzWUyHTeCz140bL5oUmIIqW81xg3GnHNT9Y.2rm",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("163","1","2","ناصر عبدالاله ناصر المعيبد","1152800668","$2y$10$8csJf8mxrK7jZx2l4On9beFupjmEnJ2owSJd4CkR4FpMqhv/nfbaa",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("164","1","2","وافي خالد محمد البقمي","1152149785","$2y$10$bylneGgiSutZZm.8LzEoCuLcT.3dvL1/2UgvZ2KFMy1C6rlyzuiEi",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");
INSERT INTO `students` VALUES("165","1","2","وسام احمد بن فالح الرشيدي","1152244735","$2y$10$Goa6Zf.KuKfuwe0ZIhDu0u5Xzz1bH8dIEw6daTFL5B8V31406uvI.",NULL,NULL,NULL,NULL,"1",NULL,"2026-02-15 20:34:00","2026-02-28 06:14:44");





CREATE TABLE `teacher_classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `is_temporary` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = تعيين مؤقت من الإدارة',
  `assigned_by` int(10) unsigned DEFAULT NULL COMMENT 'من قام بالتعيين (admin_id)',
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` date DEFAULT NULL COMMENT 'تاريخ انتهاء التعيين المؤقت',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_teacher_class` (`teacher_id`,`class_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_temp` (`is_temporary`),
  KEY `fk_tc_assigned` (`assigned_by`),
  CONSTRAINT `fk_tc_assigned` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tc_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tc_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ربط المعلمين بفصولهم (دائم أو مؤقت)';

INSERT INTO `teacher_classes` VALUES("1","2","1","0",NULL,"2026-02-21 02:21:29",NULL);
INSERT INTO `teacher_classes` VALUES("2","2","2","0",NULL,"2026-02-21 02:21:29",NULL);
INSERT INTO `teacher_classes` VALUES("3","2","4","0",NULL,"2026-02-21 02:21:29",NULL);
INSERT INTO `teacher_classes` VALUES("4","2","5","0",NULL,"2026-02-21 02:21:29",NULL);
INSERT INTO `teacher_classes` VALUES("8","2","9","0",NULL,"2026-02-21 02:21:29",NULL);
INSERT INTO `teacher_classes` VALUES("9","4","6","0","1","2026-02-21 03:09:48",NULL);
INSERT INTO `teacher_classes` VALUES("10","4","7","0","1","2026-02-21 03:09:53",NULL);
INSERT INTO `teacher_classes` VALUES("11","4","8","0","1","2026-02-21 03:09:56",NULL);
INSERT INTO `teacher_classes` VALUES("12","8","1","0","1","2026-02-21 03:10:12",NULL);





CREATE TABLE `team_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `jersey_number` int(10) unsigned DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `status` enum('active','substitute','injured','suspended') NOT NULL DEFAULT 'active',
  `joined_at` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_team_student` (`team_id`,`student_id`),
  KEY `idx_team` (`team_id`),
  KEY `idx_student` (`student_id`),
  CONSTRAINT `fk_tm_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tm_team` FOREIGN KEY (`team_id`) REFERENCES `sports_teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `team_members` VALUES("6","1","48",NULL,NULL,"substitute","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:12:53");
INSERT INTO `team_members` VALUES("7","1","49",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("8","1","50",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("9","1","51",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("10","1","52",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("11","1","53",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("12","1","54",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("13","1","55",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("14","1","56",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("15","1","57",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("16","1","58",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("17","1","59",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("18","1","60",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("19","1","61",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("20","1","62",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("21","1","63",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:09:21","2026-02-21 01:09:21");
INSERT INTO `team_members` VALUES("38","6","65",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:41:17","2026-02-21 01:41:17");
INSERT INTO `team_members` VALUES("39","6","67",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:41:17","2026-02-21 01:41:17");
INSERT INTO `team_members` VALUES("40","6","136",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:41:17","2026-02-21 01:41:17");
INSERT INTO `team_members` VALUES("41","6","43",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:41:17","2026-02-21 01:41:17");
INSERT INTO `team_members` VALUES("42","6","47",NULL,NULL,"active","2026-02-21",NULL,"2026-02-21 01:41:17","2026-02-21 01:41:17");
INSERT INTO `team_members` VALUES("63","11","2",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("64","11","7",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("66","11","11",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("68","11","13",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("69","11","147",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("70","11","148",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("71","11","149",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("72","11","150",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("73","11","151",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("75","11","153",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("76","11","154",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("78","11","156",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("80","11","158",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("81","11","159",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("82","11","160",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("84","11","162",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 03:50:54","2026-02-23 03:50:54");
INSERT INTO `team_members` VALUES("88","12","3",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("89","12","22",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("90","12","23",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("91","12","24",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("92","12","25",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("93","12","26",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("94","12","27",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("95","12","28",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("96","12","29",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("97","12","65",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("98","12","66",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("99","12","67",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("100","12","68",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("101","12","69",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("102","12","70",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("103","12","71",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("104","12","72",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("105","12","73",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("106","12","74",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("107","12","75",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("108","12","76",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("109","12","77",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("110","12","78",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("111","12","79",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("112","12","80",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("113","12","81",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("114","12","82",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("115","12","83",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("116","12","84",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("117","12","85",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("118","12","86",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("119","12","87",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("120","12","88",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("121","12","89",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("122","12","90",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("123","12","91",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("124","12","92",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("125","12","93",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("126","12","94",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:02","2026-02-23 04:03:02");
INSERT INTO `team_members` VALUES("127","13","30",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("128","13","32",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("129","13","33",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("130","13","34",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("131","13","95",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("132","13","96",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("133","13","97",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("134","13","98",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("135","13","99",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("136","13","100",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("137","13","101",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("138","13","102",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("139","13","103",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("140","13","104",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("141","13","105",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("142","13","106",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("143","13","107",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("144","13","108",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("145","13","109",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("146","13","110",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("147","13","111",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("148","13","112",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("149","13","113",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("150","13","114",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("151","13","115",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("152","13","116",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("153","13","117",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("154","13","118",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("155","13","119",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("156","13","120",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("157","13","121",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("158","13","122",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("159","13","123",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("160","13","124",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:03:38","2026-02-23 04:03:38");
INSERT INTO `team_members` VALUES("161","14","147",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:13:43","2026-02-23 04:13:43");
INSERT INTO `team_members` VALUES("162","14","48",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:13:48","2026-02-23 04:13:48");
INSERT INTO `team_members` VALUES("163","14","49",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:13:51","2026-02-23 04:13:51");
INSERT INTO `team_members` VALUES("164","14","65",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:13:55","2026-02-23 04:13:55");
INSERT INTO `team_members` VALUES("165","14","67",NULL,NULL,"active","2026-02-23",NULL,"2026-02-23 04:14:03","2026-02-23 04:14:03");
INSERT INTO `team_members` VALUES("166","14","96",NULL,NULL,"substitute","2026-02-23",NULL,"2026-02-23 04:15:13","2026-02-23 04:15:13");





CREATE TABLE `tournament_player_stats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tournament_id` int(10) unsigned NOT NULL,
  `school_id` int(10) unsigned DEFAULT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `team_id` int(10) unsigned NOT NULL,
  `goals` int(10) unsigned DEFAULT 0,
  `own_goals` int(10) unsigned DEFAULT 0,
  `assists` int(10) unsigned DEFAULT 0,
  `yellow_cards` int(10) unsigned DEFAULT 0,
  `red_cards` int(10) unsigned DEFAULT 0,
  `man_of_match` int(10) unsigned DEFAULT 0,
  `matches_played` int(10) unsigned DEFAULT 0,
  `awards` varchar(255) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cheers_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tps_tour_student` (`tournament_id`,`student_id`),
  KEY `idx_tps_goals` (`goals`),
  KEY `idx_tps_mom` (`man_of_match`),
  KEY `idx_saas_school` (`school_id`),
  CONSTRAINT `fk_tps_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournaments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;






CREATE TABLE `tournament_teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `tournament_id` int(10) unsigned NOT NULL COMMENT 'معرف البطولة',
  `class_id` int(10) unsigned DEFAULT NULL COMMENT 'معرف الفصل (اختياري)',
  `sports_team_id` int(10) unsigned DEFAULT NULL,
  `team_name` varchar(100) NOT NULL COMMENT 'اسم الفريق',
  `team_color` varchar(20) DEFAULT '#10b981' COMMENT 'لون الفريق',
  `seed_number` int(10) unsigned DEFAULT NULL COMMENT 'رقم البذرة/الترتيب',
  `is_eliminated` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'هل تم إقصاؤه',
  `elimination_count` int(10) unsigned DEFAULT 0 COMMENT 'عدد مرات الخسارة (للخروج المزدوج)',
  `current_round` int(10) unsigned DEFAULT 1 COMMENT 'الجولة الحالية',
  `final_rank` int(10) unsigned DEFAULT NULL COMMENT 'الترتيب النهائي',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `group_name` varchar(10) DEFAULT NULL,
  `cheers_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_tournament` (`tournament_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_eliminated` (`is_eliminated`),
  KEY `idx_seed` (`seed_number`),
  CONSTRAINT `fk_tt_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tt_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournaments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='فرق البطولات';

INSERT INTO `tournament_teams` VALUES("9","1","2","1",NULL,"الأول الثانوي - 1/1","#ef4444","6","1","0","1",NULL,"2026-02-14 00:46:14",NULL,"0");
INSERT INTO `tournament_teams` VALUES("10","1","2","2",NULL,"الأول الثانوي - 1/2","#3b82f6","2","1","0","1",NULL,"2026-02-14 00:46:14",NULL,"0");
INSERT INTO `tournament_teams` VALUES("11","1","2","4",NULL,"الثاني الثانوي - 2/1","#10b981","4","1","0","1",NULL,"2026-02-14 00:46:14",NULL,"0");
INSERT INTO `tournament_teams` VALUES("12","1","2","5",NULL,"الثاني الثانوي - 2/2","#f59e0b","5","0","0","1",NULL,"2026-02-14 00:46:14",NULL,"0");
INSERT INTO `tournament_teams` VALUES("13","1","2","6",NULL,"الثالث الثانوي - 3/1","#8b5cf6","1","1","0","1",NULL,"2026-02-14 00:46:14",NULL,"0");
INSERT INTO `tournament_teams` VALUES("14","1","2","7",NULL,"الثالث الثانوي - 3/2","#ec4899","3","0","0","1",NULL,"2026-02-14 00:46:14",NULL,"0");
INSERT INTO `tournament_teams` VALUES("15","1","3","1",NULL,"الأول الثانوي - 1/1","#ef4444","4","0","0","1",NULL,"2026-02-14 02:00:24",NULL,"0");
INSERT INTO `tournament_teams` VALUES("16","1","3","2",NULL,"الأول الثانوي - 1/2","#3b82f6","6","0","0","1",NULL,"2026-02-14 02:00:24",NULL,"0");
INSERT INTO `tournament_teams` VALUES("17","1","3","4",NULL,"الثاني الثانوي - 2/1","#10b981","2","0","0","1",NULL,"2026-02-14 02:00:24",NULL,"0");
INSERT INTO `tournament_teams` VALUES("18","1","3","5",NULL,"الثاني الثانوي - 2/2","#f59e0b","1","0","0","1",NULL,"2026-02-14 02:00:24",NULL,"0");
INSERT INTO `tournament_teams` VALUES("19","1","3","6",NULL,"الثالث الثانوي - 3/1","#8b5cf6","3","0","0","1",NULL,"2026-02-14 02:00:24",NULL,"0");
INSERT INTO `tournament_teams` VALUES("20","1","3","7",NULL,"الثالث الثانوي - 3/2","#ec4899","5","0","0","1",NULL,"2026-02-14 02:00:24",NULL,"0");
INSERT INTO `tournament_teams` VALUES("21","1","4","1",NULL,"الأول الثانوي - 1/1","#ef4444","5","0","1","1",NULL,"2026-02-14 02:04:30",NULL,"0");
INSERT INTO `tournament_teams` VALUES("22","1","4","2",NULL,"الأول الثانوي - 1/2","#3b82f6","1","0","1","1",NULL,"2026-02-14 02:04:30",NULL,"0");
INSERT INTO `tournament_teams` VALUES("23","1","4","4",NULL,"الثاني الثانوي - 2/1","#10b981","2","0","1","1",NULL,"2026-02-14 02:04:30",NULL,"0");
INSERT INTO `tournament_teams` VALUES("24","1","4","5",NULL,"الثاني الثانوي - 2/2","#f59e0b","4","0","1","1",NULL,"2026-02-14 02:04:30",NULL,"0");
INSERT INTO `tournament_teams` VALUES("25","1","4","6",NULL,"الثالث الثانوي - 3/1","#8b5cf6","6","0","0","1",NULL,"2026-02-14 02:04:30",NULL,"0");
INSERT INTO `tournament_teams` VALUES("26","1","4","7",NULL,"الثالث الثانوي - 3/2","#ec4899","3","0","0","1",NULL,"2026-02-14 02:04:30",NULL,"0");
INSERT INTO `tournament_teams` VALUES("41","1","6","1",NULL,"الأول الثانوي - 1/1","#ef4444","4","0","1","1",NULL,"2026-02-15 10:46:59",NULL,"0");
INSERT INTO `tournament_teams` VALUES("42","1","6","2",NULL,"الأول الثانوي - 1/2","#3b82f6","2","0","0","1",NULL,"2026-02-15 10:46:59",NULL,"0");
INSERT INTO `tournament_teams` VALUES("43","1","6","3",NULL,"الأول الثانوي - 1/3","#10b981","5","0","1","1",NULL,"2026-02-15 10:46:59",NULL,"0");
INSERT INTO `tournament_teams` VALUES("44","1","6","4",NULL,"الثاني الثانوي - 2/1","#f59e0b","7","0","1","1",NULL,"2026-02-15 10:46:59",NULL,"0");
INSERT INTO `tournament_teams` VALUES("45","1","6","5",NULL,"الثاني الثانوي - 2/2","#8b5cf6","6","0","1","1",NULL,"2026-02-15 10:46:59",NULL,"0");
INSERT INTO `tournament_teams` VALUES("46","1","6","6",NULL,"الثالث الثانوي - 3/1","#ec4899","1","0","1","1",NULL,"2026-02-15 10:46:59",NULL,"0");
INSERT INTO `tournament_teams` VALUES("47","1","6","7",NULL,"الثالث الثانوي - 3/2","#06b6d4","3","0","1","1",NULL,"2026-02-15 10:46:59",NULL,"0");
INSERT INTO `tournament_teams` VALUES("48","1","7","1",NULL,"الأول الثانوي - 1/1","#ef4444","3","0","0","1",NULL,"2026-02-15 11:40:15",NULL,"0");
INSERT INTO `tournament_teams` VALUES("49","1","7","2",NULL,"الأول الثانوي - 1/2","#3b82f6","4","0","1","1",NULL,"2026-02-15 11:40:15",NULL,"0");
INSERT INTO `tournament_teams` VALUES("50","1","7","3",NULL,"الأول الثانوي - 1/3","#10b981","5","0","0","1",NULL,"2026-02-15 11:40:15",NULL,"0");
INSERT INTO `tournament_teams` VALUES("51","1","7","4",NULL,"الثاني الثانوي - 2/1","#f59e0b","6","0","1","1",NULL,"2026-02-15 11:40:15",NULL,"0");
INSERT INTO `tournament_teams` VALUES("52","1","7","5",NULL,"الثاني الثانوي - 2/2","#8b5cf6","1","0","0","1",NULL,"2026-02-15 11:40:15",NULL,"0");
INSERT INTO `tournament_teams` VALUES("53","1","7","6",NULL,"الثالث الثانوي - 3/1","#ec4899","7","0","0","1",NULL,"2026-02-15 11:40:15",NULL,"0");
INSERT INTO `tournament_teams` VALUES("54","1","7","7",NULL,"الثالث الثانوي - 3/2","#06b6d4","2","0","1","1",NULL,"2026-02-15 11:40:15",NULL,"0");
INSERT INTO `tournament_teams` VALUES("63","1","9",NULL,NULL,"Team A","#3b82f6","2","1","2","1",NULL,"2026-02-20 23:18:17",NULL,"0");
INSERT INTO `tournament_teams` VALUES("64","1","9",NULL,NULL,"Team B","#10b981","3","1","2","1",NULL,"2026-02-20 23:18:50",NULL,"0");
INSERT INTO `tournament_teams` VALUES("65","1","9",NULL,NULL,"Team C","#f59e0b","1","0","1","1",NULL,"2026-02-20 23:19:27",NULL,"0");
INSERT INTO `tournament_teams` VALUES("66","1","9",NULL,NULL,"Team D","#ef4444","4","1","2","1",NULL,"2026-02-20 23:20:05",NULL,"0");
INSERT INTO `tournament_teams` VALUES("79","1","17",NULL,NULL,"الأسود","#ef4444","2","0","0","1",NULL,"2026-02-22 04:38:42",NULL,"0");
INSERT INTO `tournament_teams` VALUES("80","1","17",NULL,NULL,"النمور","#3b82f6","4","0","0","1",NULL,"2026-02-22 04:38:42",NULL,"0");
INSERT INTO `tournament_teams` VALUES("81","1","17",NULL,NULL,"الصقور","#10b981","1","0","0","1",NULL,"2026-02-22 04:38:42",NULL,"0");
INSERT INTO `tournament_teams` VALUES("82","1","17",NULL,NULL,"الفهود","#f59e0b","3","0","0","1",NULL,"2026-02-22 04:38:42",NULL,"0");
INSERT INTO `tournament_teams` VALUES("92","1","19","1",NULL,"الأول الثانوي - 1/1","#ef4444","2","0","0","1",NULL,"2026-02-22 15:35:07","B","0");
INSERT INTO `tournament_teams` VALUES("93","1","19","2",NULL,"الأول الثانوي - 1/2","#3b82f6","8","0","0","1",NULL,"2026-02-22 15:35:07","B","0");
INSERT INTO `tournament_teams` VALUES("94","1","19","4",NULL,"الثاني الثانوي - 2/1","#10b981","6","0","0","1",NULL,"2026-02-22 15:35:07","B","0");
INSERT INTO `tournament_teams` VALUES("95","1","19","5",NULL,"الثاني الثانوي - 2/2","#f59e0b","3","0","0","1",NULL,"2026-02-22 15:35:07","A","0");
INSERT INTO `tournament_teams` VALUES("96","1","19","9",NULL,"الثاني الثانوي - 2/3","#8b5cf6","5","0","0","1",NULL,"2026-02-22 15:35:07","A","0");
INSERT INTO `tournament_teams` VALUES("97","1","19","6",NULL,"الثالث الثانوي - 3/1","#ec4899","7","0","0","1",NULL,"2026-02-22 15:35:07","A","0");
INSERT INTO `tournament_teams` VALUES("98","1","19","7",NULL,"الثالث الثانوي - 3/2","#06b6d4","1","0","0","1",NULL,"2026-02-22 15:35:07","A","0");
INSERT INTO `tournament_teams` VALUES("99","1","19","8",NULL,"الثالث الثانوي - 3/3","#84cc16","4","0","0","1",NULL,"2026-02-22 15:35:07","B","0");
INSERT INTO `tournament_teams` VALUES("100","1","20","1",NULL,"الأول الثانوي - 1/1","#ef4444","6","0","0","1",NULL,"2026-02-23 02:55:32","B","0");
INSERT INTO `tournament_teams` VALUES("101","1","20","2",NULL,"الأول الثانوي - 1/2","#3b82f6","1","0","0","1",NULL,"2026-02-23 02:55:32","A","0");
INSERT INTO `tournament_teams` VALUES("102","1","20","4",NULL,"الثاني الثانوي - 2/1","#10b981","7","0","0","1",NULL,"2026-02-23 02:55:32","A","0");
INSERT INTO `tournament_teams` VALUES("103","1","20","5",NULL,"الثاني الثانوي - 2/2","#f59e0b","5","0","0","1",NULL,"2026-02-23 02:55:32","A","0");
INSERT INTO `tournament_teams` VALUES("104","1","20","9",NULL,"الثاني الثانوي - 2/3","#8b5cf6","8","0","0","1",NULL,"2026-02-23 02:55:32","B","0");
INSERT INTO `tournament_teams` VALUES("105","1","20","6",NULL,"الثالث الثانوي - 3/1","#ec4899","3","0","0","1",NULL,"2026-02-23 02:55:32","A","0");
INSERT INTO `tournament_teams` VALUES("106","1","20","7",NULL,"الثالث الثانوي - 3/2","#06b6d4","2","0","0","1",NULL,"2026-02-23 02:55:32","B","0");
INSERT INTO `tournament_teams` VALUES("107","1","20","8",NULL,"الثالث الثانوي - 3/3","#84cc16","4","0","0","1",NULL,"2026-02-23 02:55:32","B","0");
INSERT INTO `tournament_teams` VALUES("108","1","21","1",NULL,"الأول الثانوي - 1/1","#ef4444","5","0","0","1",NULL,"2026-02-23 03:07:16","A","0");
INSERT INTO `tournament_teams` VALUES("109","1","21","2",NULL,"الأول الثانوي - 1/2","#3b82f6","6","0","0","1",NULL,"2026-02-23 03:07:16","B","0");
INSERT INTO `tournament_teams` VALUES("110","1","21","4",NULL,"الثاني الثانوي - 2/1","#10b981","7","0","0","1",NULL,"2026-02-23 03:07:16","A","0");
INSERT INTO `tournament_teams` VALUES("111","1","21","5",NULL,"الثاني الثانوي - 2/2","#f59e0b","2","1","0","1",NULL,"2026-02-23 03:07:16","B","0");
INSERT INTO `tournament_teams` VALUES("112","1","21","9",NULL,"الثاني الثانوي - 2/3","#8b5cf6","8","0","0","1",NULL,"2026-02-23 03:07:16","B","0");
INSERT INTO `tournament_teams` VALUES("113","1","21","6",NULL,"الثالث الثانوي - 3/1","#ec4899","1","0","0","1",NULL,"2026-02-23 03:07:16","A","0");
INSERT INTO `tournament_teams` VALUES("114","1","21","7",NULL,"الثالث الثانوي - 3/2","#06b6d4","3","1","0","1",NULL,"2026-02-23 03:07:16","A","0");
INSERT INTO `tournament_teams` VALUES("115","1","21","8",NULL,"الثالث الثانوي - 3/3","#84cc16","4","1","0","1",NULL,"2026-02-23 03:07:16","B","0");
INSERT INTO `tournament_teams` VALUES("116","1","22","1",NULL,"الأول الثانوي - 1/1","#ef4444","7","0","0","1",NULL,"2026-02-23 03:35:38","A","0");
INSERT INTO `tournament_teams` VALUES("117","1","22","2",NULL,"الأول الثانوي - 1/2","#3b82f6","2","0","0","1",NULL,"2026-02-23 03:35:38","B","0");
INSERT INTO `tournament_teams` VALUES("118","1","22","4",NULL,"الثاني الثانوي - 2/1","#10b981","1","0","0","1",NULL,"2026-02-23 03:35:38","A","0");
INSERT INTO `tournament_teams` VALUES("119","1","22","5",NULL,"الثاني الثانوي - 2/2","#f59e0b","5","0","0","1",NULL,"2026-02-23 03:35:38","A","0");
INSERT INTO `tournament_teams` VALUES("120","1","22","9",NULL,"الثاني الثانوي - 2/3","#8b5cf6","8","0","0","1",NULL,"2026-02-23 03:35:38","B","0");
INSERT INTO `tournament_teams` VALUES("121","1","22","6",NULL,"الثالث الثانوي - 3/1","#ec4899","3","0","0","1",NULL,"2026-02-23 03:35:38","A","0");
INSERT INTO `tournament_teams` VALUES("122","1","22","7",NULL,"الثالث الثانوي - 3/2","#06b6d4","6","0","0","1",NULL,"2026-02-23 03:35:38","B","0");
INSERT INTO `tournament_teams` VALUES("123","1","22","8",NULL,"الثالث الثانوي - 3/3","#84cc16","4","0","0","1",NULL,"2026-02-23 03:35:38","B","0");
INSERT INTO `tournament_teams` VALUES("145","1","16",NULL,"1","فصل ١ / ١","#1b10b7","1","0","0","1",NULL,"2026-02-23 06:09:09",NULL,"0");
INSERT INTO `tournament_teams` VALUES("146","1","16",NULL,"2","منتخب كرة القدم بالمدرسة","#10b981","6","0","0","1",NULL,"2026-02-23 06:09:09",NULL,"0");
INSERT INTO `tournament_teams` VALUES("147","1","16",NULL,"6","فريق النسور","#f59e0b","7","0","0","1",NULL,"2026-02-23 06:09:09",NULL,"0");
INSERT INTO `tournament_teams` VALUES("148","1","16",NULL,"11","فريق فصل ١ / ٢","#b7107a","5","0","0","1",NULL,"2026-02-23 06:09:09",NULL,"0");
INSERT INTO `tournament_teams` VALUES("149","1","16",NULL,"12","فصل ٢ / ١","#102cb7","2","0","0","1",NULL,"2026-02-23 06:09:09",NULL,"0");
INSERT INTO `tournament_teams` VALUES("150","1","16",NULL,"13","فريق فصل ٢ / ٢","#8ab710","3","0","0","1",NULL,"2026-02-23 06:09:09",NULL,"0");
INSERT INTO `tournament_teams` VALUES("151","1","16",NULL,"14","فصل ٣ / ١","#b71058","4","0","0","1",NULL,"2026-02-23 06:09:09",NULL,"0");





CREATE TABLE `tournaments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(150) NOT NULL COMMENT 'اسم البطولة',
  `description` text DEFAULT NULL COMMENT 'وصف البطولة',
  `type` enum('single_elimination','double_elimination','round_robin_single','round_robin_double','mixed') NOT NULL,
  `team_mode` enum('class_based','student_based') NOT NULL DEFAULT 'class_based' COMMENT 'وضع الفرق',
  `sport_type` varchar(50) DEFAULT 'كرة قدم' COMMENT 'نوع الرياضة',
  `start_date` date DEFAULT NULL COMMENT 'تاريخ البدء',
  `end_date` date DEFAULT NULL COMMENT 'تاريخ الانتهاء',
  `randomize_teams` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'ترتيب عشوائي للفرق',
  `balance_method` enum('none','skill_level','random') NOT NULL DEFAULT 'none',
  `auto_generate` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'توليد المباريات تلقائياً',
  `teams_per_match` int(10) unsigned DEFAULT 2 COMMENT 'عدد الفرق في المباراة',
  `points_win` int(10) unsigned DEFAULT 3 COMMENT 'نقاط الفوز',
  `points_draw` int(10) unsigned DEFAULT 1 COMMENT 'نقاط التعادل',
  `points_loss` int(10) unsigned DEFAULT 0 COMMENT 'نقاط الخسارة',
  `status` enum('draft','registration','in_progress','completed','cancelled') NOT NULL DEFAULT 'draft' COMMENT 'حالة البطولة',
  `winner_team_id` int(10) unsigned DEFAULT NULL COMMENT 'الفريق الفائز',
  `public_token` varchar(64) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned DEFAULT NULL COMMENT 'منشئ البطولة',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `public_token` (`public_token`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_tournaments_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول البطولات';

INSERT INTO `tournaments` VALUES("2","1","تجربة","","single_elimination","class_based","كرة طائرة",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-14 00:45:47","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("3","1","jdljd","","single_elimination","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-14 01:59:41","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("4","1","2","","double_elimination","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-14 02:03:44","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("6","1","تجربة خروج المغلوب من مباراتين","","double_elimination","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-15 10:46:48","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("7","1","بطولة خروج المغلوب من مرتين تجربة (2)","","double_elimination","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-15 11:40:08","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("9","1","Test Double Elimination","","double_elimination","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-20 23:11:26","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("16","1","تجربة التوزيع العشوائي","","single_elimination","class_based","كرة قدم","2026-03-01",NULL,"1","skill_level","1","2","3","1","0","in_progress",NULL,"cf937b6becb85add184e8ab25c30e3b9","1","1","2026-02-22 04:37:13","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("17","1","تجربة خروج المغلوب من مرتين","","double_elimination","student_based","كرة قدم",NULL,NULL,"1","skill_level","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-22 04:38:26","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("19","1","تجربة طريقة الخلط والمزج","","mixed","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-22 15:34:57","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("20","1","تجربة ٢ لطريقة المزيج","","mixed","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,NULL,"0","1","2026-02-23 02:55:18","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("21","1","تجربة ٣","","mixed","class_based","كرة قدم",NULL,NULL,"1","none","1","2","3","1","0","in_progress",NULL,"89711f96e8fd991bd2275edf76a1d9cf","1","1","2026-02-23 03:07:09","2026-02-28 06:14:44");
INSERT INTO `tournaments` VALUES("22","1","تجربة ٤","","mixed","class_based","كرة قدم","2026-04-01",NULL,"1","none","1","2","3","1","0","in_progress",NULL,"b5e1ac7070f5805064afe0c88a62e4be","1","1","2026-02-23 03:35:17","2026-02-28 06:14:44");





CREATE TABLE `training_attendance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `status` enum('present','absent','late','excused') NOT NULL DEFAULT 'present',
  `performance` tinyint(3) unsigned DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_session_student` (`session_id`,`student_id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_student` (`student_id`),
  CONSTRAINT `fk_ta_session` FOREIGN KEY (`session_id`) REFERENCES `training_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ta_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;






CREATE TABLE `training_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` int(10) unsigned NOT NULL,
  `title` varchar(150) NOT NULL DEFAULT 'تدريب',
  `session_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `venue` varchar(100) DEFAULT NULL,
  `focus` varchar(200) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `coach_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_team` (`team_id`),
  KEY `idx_date` (`session_date`),
  CONSTRAINT `fk_ts_team` FOREIGN KEY (`team_id`) REFERENCES `sports_teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;






CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `education` varchar(100) DEFAULT NULL,
  `experience_years` int(10) unsigned DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `role` enum('admin','teacher','viewer','supervisor') NOT NULL DEFAULT 'teacher',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_school_username` (`school_id`,`username`),
  KEY `idx_role` (`role`),
  KEY `idx_active` (`active`),
  KEY `idx_users_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES("1","1","admin","$2y$12$ASMTifKdJyFQMNeJpvxVue6VEK.dTYoVoWe4CC1PjBkGhZEl4KFA.","إسماعيل البساوي","esm1774@gmail.com","0507949591","مصارعة","بكالوريوس تربية رياضية","0","",NULL,"admin","1","2026-03-01 04:01:24","2026-02-14 06:42:23","2026-03-01 04:01:24");
INSERT INTO `users` VALUES("2","1","teacher","$2y$12$NDnF/tWCyT3rotUALBkmNOdKVTe2O6519ZjlpXKcJ2qpmisZ/DJXS","إسماعيل البساوي","esm1774@gmail.com","0507949591","مصارعة","بكالوريوس تربية بدنية","26","","1974-11-17","teacher","1","2026-02-23 08:19:39","2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `users` VALUES("3","1","viewer","$2y$12$7ZfT/tVrdPGMxYoA17FQiecYmRGF5bHO7uUxnlAsyqVY9sfGoBPsi","مدير المدرسة",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"viewer","1","2026-02-15 20:43:27","2026-02-14 06:42:23","2026-02-28 06:14:44");
INSERT INTO `users` VALUES("4","1","teacher1","$2y$12$TfM1oBamBsXEiRkDrOmxVeB/54DgvI/c/RMCgfzzvS/jzO7U/f7z.","أيمن محمد",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"teacher","1","2026-02-15 22:02:34","2026-02-15 22:01:56","2026-02-28 06:14:44");
INSERT INTO `users` VALUES("8","1","testuser","$2y$12$LMGpAkB8oJt4MvkheOdqjeFA/RZYOV3BmSDoGz8DYPtgSPMXSHTbO","Test",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"teacher","1",NULL,"2026-02-21 02:36:38","2026-02-28 06:14:44");
INSERT INTO `users` VALUES("9","1","testusersuper1","$2y$12$CEORltmwwzawvXZSH1hf5u1UW0FF/KD7wOaXkQjPLDjEe3qCMt52S","Supervisor Test",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"supervisor","1",NULL,"2026-02-21 03:29:08","2026-02-28 06:14:44");
INSERT INTO `users` VALUES("10","1","testusermarwan","$2y$12$WQyDM/tknv2b86iqx8Vhee4iJEYbgkf6kvPNlj3dng8spi/yGp4uW","Marwan Supervisor",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"teacher","0",NULL,"2026-02-21 03:37:40","2026-02-28 06:14:44");
INSERT INTO `users` VALUES("14","2","sch_test1","$2y$12$Ree6vplSKRPA.phu0czveOTPFxhBRXMM/ORfHVj9j4T8rpYM5jJnq","sch_test1",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"admin","1","2026-02-28 14:24:59","2026-02-28 06:19:45","2026-02-28 14:24:59");





CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_attendance_summary` AS select `s`.`id` AS `student_id`,`s`.`name` AS `student_name`,`s`.`class_id` AS `class_id`,concat(`g`.`name`,' - ',`c`.`name`) AS `full_class_name`,sum(case when `a`.`status` = 'present' then 1 else 0 end) AS `present_count`,sum(case when `a`.`status` = 'absent' then 1 else 0 end) AS `absent_count`,sum(case when `a`.`status` = 'late' then 1 else 0 end) AS `late_count`,count(`a`.`id`) AS `total_records` from (((`students` `s` join `classes` `c` on(`s`.`class_id` = `c`.`id`)) join `grades` `g` on(`c`.`grade_id` = `g`.`id`)) left join `attendance` `a` on(`a`.`student_id` = `s`.`id`)) where `s`.`active` = 1 group by `s`.`id`,`s`.`name`,`s`.`class_id`,concat(`g`.`name`,' - ',`c`.`name`);



CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_class_rankings` AS select `c`.`id` AS `class_id`,`c`.`name` AS `class_name`,`g`.`name` AS `grade_name`,concat(`g`.`name`,' - ',`c`.`name`) AS `full_name`,count(distinct `s`.`id`) AS `students_count`,coalesce(avg(`sf`.`score`),0) AS `avg_score`,coalesce(sum(`sf`.`score`),0) AS `total_score`,round(coalesce(avg(`sf`.`score`),0) * 10,0) AS `points` from (((`classes` `c` join `grades` `g` on(`c`.`grade_id` = `g`.`id`)) left join `students` `s` on(`s`.`class_id` = `c`.`id` and `s`.`active` = 1)) left join `student_fitness` `sf` on(`sf`.`student_id` = `s`.`id`)) where `c`.`active` = 1 group by `c`.`id` order by coalesce(avg(`sf`.`score`),0) desc;



CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_matches_full` AS select `m`.`id` AS `id`,`m`.`tournament_id` AS `tournament_id`,`m`.`school_id` AS `school_id`,`m`.`round_number` AS `round_number`,`m`.`match_number` AS `match_number`,`m`.`bracket_type` AS `bracket_type`,`m`.`team1_id` AS `team1_id`,`m`.`team2_id` AS `team2_id`,`m`.`team1_score` AS `team1_score`,`m`.`team2_score` AS `team2_score`,`m`.`winner_team_id` AS `winner_team_id`,`m`.`loser_team_id` AS `loser_team_id`,`m`.`is_bye` AS `is_bye`,`m`.`match_date` AS `match_date`,`m`.`match_time` AS `match_time`,`m`.`venue` AS `venue`,`m`.`status` AS `status`,`m`.`next_match_id` AS `next_match_id`,`m`.`next_match_slot` AS `next_match_slot`,`m`.`loser_next_match_id` AS `loser_next_match_id`,`m`.`loser_next_match_slot` AS `loser_next_match_slot`,`m`.`notes` AS `notes`,`m`.`man_of_match_student_id` AS `man_of_match_student_id`,`m`.`man_of_match_name` AS `man_of_match_name`,`m`.`created_at` AS `created_at`,`m`.`updated_at` AS `updated_at`,`m`.`group_name` AS `group_name`,`t`.`name` AS `tournament_name`,`t`.`type` AS `tournament_type`,`t1`.`team_name` AS `team1_name`,`t1`.`team_color` AS `team1_color`,`t2`.`team_name` AS `team2_name`,`t2`.`team_color` AS `team2_color`,`w`.`team_name` AS `winner_name` from ((((`matches` `m` join `tournaments` `t` on(`m`.`tournament_id` = `t`.`id`)) left join `tournament_teams` `t1` on(`m`.`team1_id` = `t1`.`id`)) left join `tournament_teams` `t2` on(`m`.`team2_id` = `t2`.`id`)) left join `tournament_teams` `w` on(`m`.`winner_team_id` = `w`.`id`));



CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_standings_full` AS select `s`.`id` AS `id`,`s`.`tournament_id` AS `tournament_id`,`s`.`school_id` AS `school_id`,`s`.`team_id` AS `team_id`,`s`.`played` AS `played`,`s`.`wins` AS `wins`,`s`.`draws` AS `draws`,`s`.`losses` AS `losses`,`s`.`goals_for` AS `goals_for`,`s`.`goals_against` AS `goals_against`,`s`.`goal_difference` AS `goal_difference`,`s`.`points` AS `points`,`s`.`form` AS `form`,`s`.`last_updated` AS `last_updated`,`s`.`group_name` AS `group_name`,`tt`.`team_name` AS `team_name`,`tt`.`team_color` AS `team_color`,`tt`.`class_id` AS `class_id`,`c`.`name` AS `class_name`,`t`.`name` AS `tournament_name`,`t`.`type` AS `tournament_type` from (((`standings` `s` join `tournament_teams` `tt` on(`s`.`team_id` = `tt`.`id`)) join `tournaments` `t` on(`s`.`tournament_id` = `t`.`id`)) left join `classes` `c` on(`tt`.`class_id` = `c`.`id`)) order by `s`.`tournament_id`,`s`.`points` desc,`s`.`goal_difference` desc,`s`.`goals_for` desc;



CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_student_latest_measurements` AS select `sm`.`id` AS `id`,`sm`.`student_id` AS `student_id`,`sm`.`measurement_date` AS `measurement_date`,`sm`.`height_cm` AS `height_cm`,`sm`.`weight_kg` AS `weight_kg`,`sm`.`bmi` AS `bmi`,`sm`.`bmi_category` AS `bmi_category`,`sm`.`waist_cm` AS `waist_cm`,`sm`.`resting_heart_rate` AS `resting_heart_rate`,`sm`.`notes` AS `notes`,`sm`.`recorded_by` AS `recorded_by`,`sm`.`created_at` AS `created_at`,`sm`.`updated_at` AS `updated_at` from (`student_measurements` `sm` join (select `pe_smart_school`.`student_measurements`.`student_id` AS `student_id`,max(`pe_smart_school`.`student_measurements`.`measurement_date`) AS `latest_date` from `student_measurements` group by `pe_smart_school`.`student_measurements`.`student_id`) `latest` on(`sm`.`student_id` = `latest`.`student_id` and `sm`.`measurement_date` = `latest`.`latest_date`));



CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_students_full` AS select `s`.`id` AS `id`,`s`.`name` AS `name`,`s`.`student_number` AS `student_number`,`s`.`class_id` AS `class_id`,`s`.`active` AS `active`,`s`.`date_of_birth` AS `date_of_birth`,`s`.`blood_type` AS `blood_type`,`s`.`guardian_phone` AS `guardian_phone`,`s`.`medical_notes` AS `medical_notes`,`c`.`name` AS `class_name`,`c`.`section` AS `section`,`c`.`grade_id` AS `grade_id`,`g`.`name` AS `grade_name`,`g`.`code` AS `grade_code`,concat(`g`.`name`,' - ',`c`.`name`) AS `full_class_name`,timestampdiff(YEAR,`s`.`date_of_birth`,curdate()) AS `age` from ((`students` `s` join `classes` `c` on(`s`.`class_id` = `c`.`id`)) join `grades` `g` on(`c`.`grade_id` = `g`.`id`));



CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_tournaments_summary` AS select `t`.`id` AS `id`,`t`.`school_id` AS `school_id`,`t`.`name` AS `name`,`t`.`description` AS `description`,`t`.`type` AS `type`,`t`.`team_mode` AS `team_mode`,`t`.`sport_type` AS `sport_type`,`t`.`start_date` AS `start_date`,`t`.`end_date` AS `end_date`,`t`.`randomize_teams` AS `randomize_teams`,`t`.`balance_method` AS `balance_method`,`t`.`auto_generate` AS `auto_generate`,`t`.`teams_per_match` AS `teams_per_match`,`t`.`points_win` AS `points_win`,`t`.`points_draw` AS `points_draw`,`t`.`points_loss` AS `points_loss`,`t`.`status` AS `status`,`t`.`winner_team_id` AS `winner_team_id`,`t`.`public_token` AS `public_token`,`t`.`is_public` AS `is_public`,`t`.`created_by` AS `created_by`,`t`.`created_at` AS `created_at`,`t`.`updated_at` AS `updated_at`,count(distinct `tt`.`id`) AS `team_count`,count(distinct `m`.`id`) AS `match_count`,sum(case when `m`.`status` = 'completed' then 1 else 0 end) AS `completed_matches`,`u`.`name` AS `created_by_name` from (((`tournaments` `t` left join `tournament_teams` `tt` on(`tt`.`tournament_id` = `t`.`id`)) left join `matches` `m` on(`m`.`tournament_id` = `t`.`id`)) left join `users` `u` on(`u`.`id` = `t`.`created_by`)) group by `t`.`id`;

SET FOREIGN_KEY_CHECKS=1;
