<?php
/**
 * PE Smart School - Tournament Archive & Evidence Report
 * Designed for Teacher Portfolio / Achievement File
 */
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير ختامي - البطولة الرياضية</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #059669;
            --primary-dark: #065f46;
            --primary-light: #ecfdf5;
            --accent: #10b981;
            --gold: #f59e0b;
            --bg: #f8fafc;
            --text: #1e293b;
            --text-light: #64748b;
            --card-bg: #ffffff;
            --border: #e2e8f0;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Cairo', sans-serif;
            background-color: var(--bg);
            color: var(--text);
            line-height: 1.6;
        }

        .container { 
            width: 100%; 
            max-width: 1000px; 
            margin: 0 auto; 
            padding: 1rem; 
        }

        @media (min-width: 768px) {
            .container { padding: 2rem; }
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            inset: 0;
            background: white;
            z-index: 100;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid var(--primary-light);
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* Report Header */
        .report-header {
            text-align: center;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: white;
            padding: 2.5rem 1.5rem;
            border-radius: 1.5rem md:2rem;
            margin-bottom: 1.5rem md:2rem;
            box-shadow: 0 10px 30px rgba(5, 150, 105, 0.15);
            position: relative;
            overflow: hidden;
        }
        .report-header::after {
            content: "🏆";
            position: absolute;
            top: -20px;
            right: -20px;
            font-size: 6rem md:8rem;
            opacity: 0.1;
            transform: rotate(-15deg);
        }
        .report-header h1 { 
            font-size: 1.75rem; 
            font-weight: 900; 
            margin-bottom: 0.5rem; 
            line-height: 1.2;
        }
        @media (min-width: 768px) {
            .report-header h1 { font-size: 2.5rem; }
            .report-header { padding: 3.5rem 2rem; }
        }
        .report-header p { opacity: 0.9; font-size: 0.9rem md:1.1rem; font-weight: 700; }

        /* Sections */
        .section {
            background: var(--card-bg);
            border-radius: 1.5rem;
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
            border: 1px solid var(--border);
        }
        @media (min-width: 768px) {
            .section { padding: 2rem; margin-bottom: 2rem; }
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.25rem;
            font-weight: 900;
            margin-bottom: 1.5rem;
            color: var(--primary-dark);
            border-bottom: 2px solid var(--primary-light);
            padding-bottom: 0.75rem;
        }
        @media (min-width: 768px) {
            .section-title { font-size: 1.5rem; }
        }

        /* Champion Banner */
        .champion-card {
            background: linear-gradient(to right, #fffbeb, #fef3c7);
            border: 3px solid #fbbf24;
            text-align: center;
            padding: 2rem 1.5rem;
            border-radius: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 15px -3px rgba(251, 191, 36, 0.2);
        }
        .champion-name { 
            font-size: 1.75rem; 
            font-weight: 900; 
            color: #92400e; 
            margin: 0.5rem 0;
            text-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        @media (min-width: 768px) {
            .champion-name { font-size: 2.5rem; }
        }

        /* Stats Grid */
        .stats-grid { 
            display: grid; 
            grid-template-columns: 1fr; 
            gap: 1.5rem; 
            margin-bottom: 2rem;
        }
        @media (min-width: 768px) { 
            .stats-grid { grid-template-columns: repeat(2, 1fr); } 
        }

        /* Tables & Mobile Views */
        .table-container {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        table { width: 100%; border-collapse: collapse; margin-top: 0.5rem; }
        th { 
            background: var(--primary-light); 
            color: var(--primary-dark);
            text-align: right; 
            padding: 1rem; 
            font-size: 0.8rem; 
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        td { padding: 1rem; border-bottom: 1px solid var(--border); font-size: 0.95rem; }
        
        tr:hover td { background-color: var(--primary-light); transition: background 0.2s; }

        /* Match Row */
        .match-card {
            background: white;
            border: 1px solid var(--border);
            padding: 1rem;
            border-radius: 1.25rem;
            margin-bottom: 0.75rem;
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
            text-align: center;
        }
        @media (min-width: 640px) {
            .match-card { flex-direction: row; justify-content: space-between; text-align: right; }
        }

        /* Award Card */
        .award-item {
            background: var(--bg);
            padding: 1rem;
            border-radius: 1.25rem;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 0.75rem;
            border: 1px solid transparent;
            transition: all 0.3s;
        }
        .award-item:hover {
            border-color: var(--primary);
            background: white;
            box-shadow: 0 4px 12px rgba(5, 150, 105, 0.05);
        }
        .award-icon { 
            width: 45px;
            height: 45px;
            background: var(--primary-light);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem; 
        }

        /* Print Controls */
        .controls {
            display: flex;
            flex-direction: column-reverse;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        @media (min-width: 640px) {
            .controls { flex-direction: row; justify-content: center; }
        }
        .btn {
            flex: 1;
            max-width: 300px;
            padding: 0.85rem 1.5rem;
            border-radius: 1rem;
            font-weight: 800;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 0.95rem;
        }
        .btn-print { 
            background: var(--primary); 
            color: white; 
            box-shadow: 0 4px 14px rgba(5, 150, 105, 0.4);
        }
        .btn-print:hover { background: var(--primary-dark); transform: translateY(-2px); }
        .btn-back { background: #fff; color: var(--text); border: 1px solid var(--border); }
        .btn-back:hover { background: var(--bg); }

        /* Media Gallery */
        .media-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 12px;
            margin-top: 1rem;
        }
        @media (min-width: 768px) {
            .media-grid { grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px; }
        }
        .media-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 1.25rem;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
            transition: transform 0.3s;
        }
        .media-card:hover { transform: scale(1.02); }
        .media-card img {
            width: 100%;
            aspect-ratio: 4/3;
            object-fit: cover;
            display: block;
        }
        .media-info {
            padding: 10px;
            font-size: 0.7rem;
            color: var(--text-light);
            text-align: center;
            font-weight: 700;
        }

        /* Printable Mode */
        @media print {
            body { background: white; color: black; }
            .container { margin: 0; padding: 0; max-width: 100%; }
            .controls { display: none; }
            .section { 
                box-shadow: none !important; 
                border: 1px solid #ddd !important; 
                break-inside: avoid; 
                margin-bottom: 15px !important; 
                padding: 1.5rem !important;
            }
            .report-header { 
                border-radius: 0 !important; 
                background: #f1f5f9 !important; 
                color: black !important;
                border-bottom: 2px solid #000 !important;
                box-shadow: none !important;
            }
            .report-header h1 { color: #000 !important; }
            .report-header p { color: #333 !important; }
            .champion-card { border: 2px solid #000 !important; background: #fff !important; }
            .btn, .loading-overlay { display: none !important; }
            .award-icon { background: #eee !important; border: 1px solid #ddd !important; }
            th { background: #eee !important; color: #000 !important; border-bottom: 1px solid #000 !important; }
        }
    </style>
</head>
<body>

    <div id="loading" class="loading-overlay">
        <div class="spinner"></div>
        <p style="margin-top: 1rem;">جاري تحضير التقرير الختامي...</p>
    </div>

    <div class="container">
        <!-- Controls -->
        <div class="controls">
            <a href="index.php" class="btn btn-back">⬅️ عودة للوحة التحكم</a>
            <button onclick="window.print()" class="btn btn-print">🖨️ طباعة التقرير (أو حفظ كـ PDF)</button>
        </div>

        <div id="report-content">
            <!-- Header -->
            <header class="report-header">
                <p id="report-date">التاريخ: ...</p>
                <h1 id="tournament-name">تقرير الإنجاز - البطولة الرياضية</h1>
                <p id="tournament-meta">... | ...</p>
            </header>

            <!-- Winner Section -->
            <div id="champion-section" style="display: none;">
                <div class="champion-card">
                    <p style="font-size: 1.2rem; margin-bottom: 0.5rem;">🥇 بطل النسخة 🏅</p>
                    <div id="champion-name" class="champion-name">...</div>
                    <p id="champion-celebration">بطل البطولة بجدارة واستحقاق</p>
                </div>
            </div>

            <!-- Standings Table -->
            <div class="section">
                <h2 class="section-title">📊 الترتيب النهائي للفرق</h2>
                <table id="standings-table">
                    <thead>
                        <tr>
                            <th>الترتيب</th>
                            <th>الفريق / الفصل</th>
                            <th>لعب</th>
                            <th>فوز</th>
                            <th>أهداف له</th>
                            <th>النقاط</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <!-- Awards & Honors -->
            <div class="stats-grid">
                <div class="section">
                    <h2 class="section-title">⭐ الطلاب المتميزون (شواهد)</h2>
                    <div id="awards-list"></div>
                </div>
                <div class="section">
                    <h2 class="section-title">⚽ هدافو البطولة</h2>
                    <div id="scorers-list"></div>
                </div>
            </div>

            <!-- Evidence Gallery -->
            <div class="section">
                <h2 class="section-title">📸 شواهد مصورة من قلب الحدث</h2>
                <div id="media-gallery" class="media-grid"></div>
            </div>

            <!-- Match History Summary -->
            <div class="section">
                <h2 class="section-title">⚔️ سجل المواجهات والنتائج</h2>
                <div id="matches-summary"></div>
            </div>

            <footer style="text-align: center; margin-top: 4rem; padding-top: 2rem; border-top: 1px solid #eee; color: #999;">
                <p>صُدر هذا التقرير آلياً بواسطة نظام PE Smart School</p>
                <p>يُعتبر هذا التقرير مستنداً رسمياً لإنجازات المعلم في النشاط الرياضي</p>
            </footer>
        </div>
    </div>

    <script>
        const tournamentId = new URLSearchParams(window.location.search).get('id');
        
        async function loadReport() {
            if (!tournamentId) {
                alert('عذراً، معرّف البطولة مفقود');
                return;
            }

            try {
                const res = await fetch(`modules/tournaments/api.php?action=tournament_full_report&id=${tournamentId}`);
                const result = await res.json();

                if (result.success) {
                    renderReport(result.data);
                } else {
                    alert(result.error || 'فشل تحميل بيانات التقرير');
                }
            } catch (e) {
                console.error(e);
                alert('خطأ في الاتصال بالخادم');
            } finally {
                document.getElementById('loading').style.display = 'none';
            }
        }

        function renderReport(data) {
            const t = data.tournament;
            
            // Header
            document.getElementById('tournament-name').textContent = t.name;
            document.getElementById('tournament-meta').textContent = `${t.sport_type} | نوع البطولة: ${t.type.replace(/_/g,' ')}`;
            document.getElementById('report-date').textContent = `تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')}`;

            // Champion
            if (data.champion) {
                document.getElementById('champion-section').style.display = 'block';
                document.getElementById('champion-name').textContent = data.champion.team_name;
            }

            // Standings
            const standingsBody = document.querySelector('#standings-table tbody');
            data.standings.forEach((s, ix) => {
                const row = `
                    <tr>
                        <td><b>${ix + 1}</b></td>
                        <td>
                            <div style="display:flex; align-items:center; gap:8px">
                                <div style="width:12px; height:12px; border-radius:50%; background:${s.team_color}"></div>
                                <span>${s.team_name}</span>
                            </div>
                        </td>
                        <td>${s.played}</td>
                        <td>${s.wins}</td>
                        <td>${s.goals_for}</td>
                        <td><b>${s.points}</b></td>
                    </tr>
                `;
                standingsBody.innerHTML += row;
            });

            // Awards
            const awardsList = document.getElementById('awards-list');
            if (data.awards && data.awards.length > 0) {
                data.awards.forEach(a => {
                    awardsList.innerHTML += `
                        <div class="award-item">
                            <span class="award-icon">🌟</span>
                            <div>
                                <div style="font-weight:bold">${a.student_name}</div>
                                <div style="font-size:0.8rem; color:#666">${a.awards || 'نجم البطولة'} | ${a.team_name}</div>
                            </div>
                        </div>
                    `;
                });
            } else {
                awardsList.innerHTML = '<p style="color:#999; text-align:center">لم يتم رصد جوائز بعد</p>';
            }

            // Scorers
            const scorersList = document.getElementById('scorers-list');
            if (data.scorers && data.scorers.length > 0) {
                data.scorers.forEach((s, ix) => {
                    scorersList.innerHTML += `
                        <div class="award-item">
                            <span class="award-icon">⚽</span>
                            <div style="flex:1">
                                <div style="font-weight:bold">${s.student_name}</div>
                                <div style="font-size:0.8rem; color:#666">${s.team_name}</div>
                            </div>
                            <div style="font-weight:900; color:var(--accent)">${s.goals}</div>
                        </div>
                    `;
                });
            } else {
                scorersList.innerHTML = '<p style="color:#999; text-align:center">لا يوجد هدافون مسجلون</p>';
            }

            // Gallery
            const gallery = document.getElementById('media-gallery');
            if (data.media && data.media.length > 0) {
                data.media.forEach(m => {
                    if (m.media_type === 'photo') {
                        gallery.innerHTML += `
                            <div class="media-card">
                                <img src="${m.media_url}" loading="lazy">
                                <div class="media-info">${m.t1} ضد ${m.t2} ${m.description || ''}</div>
                            </div>
                        `;
                    }
                });
            } else {
                gallery.parentElement.style.display = 'none';
            }

            // Matches
            const matchSummary = document.getElementById('matches-summary');
            data.matches.forEach(m => {
                matchSummary.innerHTML += `
                    <div class="match-card">
                        <div style="flex:1; text-align:right">
                            <span style="font-weight:bold">${m.team1_name || '؟'}</span>
                        </div>
                        <div style="padding:0 1rem; text-align:center">
                            <div style="font-weight:900; background:#f1f5f9; padding:0.4rem 1rem; border-radius:0.5rem">
                                ${m.team1_score ?? '-'} : ${m.team2_score ?? '-'}
                            </div>
                            <div style="font-size:0.7rem; color:#999; margin-top:4px">الجولة ${m.round_number}</div>
                        </div>
                        <div style="flex:1; text-align:left">
                            <span style="font-weight:bold">${m.team2_name || '؟'}</span>
                        </div>
                    </div>
                `;
            });

        }

        window.onload = loadReport;
    </script>
</body>
</html>
