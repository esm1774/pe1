/**
 * PE Smart School System - Competition Page
 */

async function renderCompetition(sid = null) {
    const mc = document.getElementById('mainContent');
    mc.innerHTML = showLoading();

    let parentStudents = [];
    if (currentUser && currentUser.role === 'parent') {
        const pr = await API.get('parent_dashboard');
        if (pr && pr.success) parentStudents = pr.data || [];

        if (!sid && parentStudents.length > 0) {
            sid = parentStudents[0].id; // Default to first child
        }
    }

    const r = await API.get('competition', { student_id: sid });
    if (!r || !r.success) return;

    const { classRanking, topStudents, studentData } = r.data;

    // Redesign for Parents
    if (currentUser.role === 'parent') {
        renderParentCompetition(parentStudents, studentData, classRanking, topStudents);
        return;
    }

    // Standard view for Admin/Teacher
    mc.innerHTML = `
    <div class="fade-in px-4 md:px-0">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
            <div>
                <h2 class="text-3xl font-black text-gray-800">🏆 مركز التصنيف والتميز</h2>
                <p class="text-gray-500 font-bold mt-1">تتبع أداء الفصول والطلاب المتفوقين في الأنشطة الرياضية</p>
            </div>
        </div>

        <!-- Podium for Classes -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            ${classRanking.slice(0, 3).map((c, i) => `
            <div class="group bg-white rounded-[3rem] shadow-sm border-2 ${i === 0 ? 'border-yellow-400 md:order-2 md:-mt-6 scale-105' : i === 1 ? 'border-gray-200 md:order-1' : 'border-orange-200 md:order-3'} p-10 text-center relative overflow-hidden transition-all duration-500 hover:shadow-2xl">
                <div class="absolute inset-0 bg-gradient-to-b ${i === 0 ? 'from-yellow-400/5 to-transparent' : i === 1 ? 'from-gray-400/5 to-transparent' : 'from-orange-400/5 to-transparent'} opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div class="text-7xl mb-6 transform transition group-hover:scale-125 duration-500">${i === 0 ? '🥇' : i === 1 ? '🥈' : '🥉'}</div>
                <h3 class="font-black text-2xl text-gray-800 group-hover:text-emerald-700 transition">${esc(c.full_class_name)}</h3>
                <div class="mt-6 flex flex-col items-center">
                    <p class="text-5xl font-black text-emerald-600">${c.points}</p>
                    <p class="text-[10px] text-gray-400 font-black uppercase tracking-widest mt-1">نقاط التميز</p>
                </div>
                <div class="mt-8 flex items-center justify-center gap-2">
                    <span class="bg-gray-50 text-gray-500 text-[10px] font-black px-4 py-2 rounded-full border border-gray-100">${c.students_count} بطل مشارك</span>
                </div>
            </div>
            `).join('')}
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <!-- Full Ranking -->
            <div class="bg-white rounded-[3rem] shadow-sm border border-gray-100 p-8 md:p-10">
                <div class="flex items-center justify-between mb-8">
                    <h3 class="font-black text-xl text-gray-800 flex items-center gap-3">
                        <span class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-lg">📊</span>
                        ترتيب الفصول العام
                    </h3>
                </div>
                <div class="space-y-4">
                    ${classRanking.map((c, i) => `
                        <div class="group flex items-center gap-5 p-5 rounded-[2rem] ${i < 3 ? 'bg-emerald-50/50' : 'bg-gray-50/50'} transition-all hover:bg-white hover:shadow-xl border border-transparent hover:border-emerald-100">
                            <span class="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg transition-transform group-hover:scale-110 ${i === 0 ? 'bg-yellow-500 text-white shadow-lg shadow-yellow-200' : i === 1 ? 'bg-gray-400 text-white shadow-lg shadow-gray-200' : i === 2 ? 'bg-orange-400 text-white shadow-lg shadow-orange-200' : 'bg-white text-gray-400 border border-gray-100'}">${i + 1}</span>
                            <div class="flex-1">
                                <p class="font-black text-gray-800 group-hover:text-emerald-700 transition">${esc(c.full_class_name)}</p>
                                <p class="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">${c.students_count} طالب مسجل</p>
                            </div>
                            <div class="text-left">
                                <span class="text-2xl font-black text-gray-800">${c.points}</span>
                                <p class="text-[10px] text-gray-400 font-black uppercase tracking-widest">نقطة</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>

            <!-- Top Students -->
            <div class="bg-white rounded-[3rem] shadow-sm border border-gray-100 p-8 md:p-10">
                <div class="flex items-center justify-between mb-8">
                    <h3 class="font-black text-xl text-gray-800 flex items-center gap-3">
                        <span class="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-lg">⭐</span>
                        قائمة العشرة الأوائل (طلاب)
                    </h3>
                </div>
                <div class="space-y-4">
                    ${topStudents.map((s, i) => `
                        <div class="group flex items-center gap-5 p-5 rounded-[2rem] ${i < 3 ? 'bg-amber-50/50' : 'bg-gray-50/50'} transition-all hover:bg-white hover:shadow-xl border border-transparent hover:border-amber-100">
                            <span class="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black transition-transform group-hover:scale-110 ${i === 0 ? 'bg-amber-500 text-white shadow-lg shadow-amber-200' : i === 1 ? 'bg-amber-400 text-white' : i === 2 ? 'bg-amber-300 text-white' : 'bg-white text-gray-400 border border-gray-100'}">${i + 1}</span>
                            <div class="flex-1">
                                <p class="font-black text-gray-800 text-sm group-hover:text-amber-700 transition">${esc(s.name)}</p>
                                <p class="text-[10px] text-gray-400 font-black uppercase tracking-tighter">${esc(s.class_name)}</p>
                            </div>
                            <div class="text-left">
                                <span class="text-xl font-black text-emerald-600">${s.avg_score}</span>
                                <p class="text-[10px] text-gray-300 font-black uppercase tracking-widest">المعدل</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    </div>`;
}

function renderParentCompetition(children, currentChild, classRanking, topStudents) {
    const mc = document.getElementById('mainContent');
    const sid = currentChild ? currentChild.studentId : (children.length > 0 ? children[0].id : null);

    mc.innerHTML = `
    <div class="fade-in">
        <div class="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
                <h2 class="text-3xl font-black text-gray-800">🏆 تنافس الأبناء</h2>
                <p class="text-gray-500 mt-2">تابع ترتيب أبنائك وتفوقهم بين زملائهم</p>
            </div>
        </div>

        <!-- Children Selection Tabs -->
        <div class="flex flex-wrap gap-3 mb-8 no-print">
            ${children.map(c => `
                <button onclick="renderCompetition(${c.id})" class="px-6 py-3 rounded-2xl font-bold transition flex items-center gap-3 ${sid == c.id ? 'bg-gray-900 text-white shadow-xl scale-105' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-100'} cursor-pointer">
                    <span class="text-xl">👦</span>
                    <span>${esc(c.name)}</span>
                    ${sid == c.id ? '<span class="w-2 h-2 bg-green-400 rounded-full animate-ping"></span>' : ''}
                </button>
            `).join('')}
        </div>

        ${currentChild ? `
        <!-- Focused Child Stats -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
            <div class="bg-gradient-to-br from-indigo-600 via-blue-600 to-blue-700 rounded-3xl shadow-xl p-8 text-white relative overflow-hidden group">
                <div class="absolute -right-4 -top-4 text-9xl opacity-10 transform rotate-12 transition group-hover:scale-110">🎖️</div>
                <div class="flex items-center justify-between mb-8">
                    <h3 class="font-bold text-xl flex items-center gap-2"><span>🎖️</span> الترتيب في المدرسة</h3>
                    <span class="bg-white/20 backdrop-blur-md px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">رتبة المدرسة</span>
                </div>
                <div class="flex items-end gap-1">
                    <span class="text-7xl font-black leading-none">${currentChild.schoolRank}</span>
                    <span class="text-2xl font-bold opacity-60 mb-2">/${currentChild.totalInSchool}</span>
                </div>
                <p class="text-blue-100 text-sm mt-4 font-medium italic opacity-80">"أداء متميز يسعى للقمة!"</p>
                <div class="mt-8 h-2 bg-white/20 rounded-full overflow-hidden">
                    <div class="h-full bg-white shadow-lg" style="width: ${((currentChild.totalInSchool - currentChild.schoolRank + 1) / currentChild.totalInSchool) * 100}%"></div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-emerald-600 via-teal-600 to-teal-700 rounded-3xl shadow-xl p-8 text-white relative overflow-hidden group">
                <div class="absolute -right-4 -top-4 text-9xl opacity-10 transform rotate-12 transition group-hover:scale-110">🏫</div>
                <div class="flex items-center justify-between mb-8">
                    <h3 class="font-bold text-xl flex items-center gap-2"><span>🏫</span> الترتيب في الفصل</h3>
                    <span class="bg-white/20 backdrop-blur-md px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">رتبة الفصل</span>
                </div>
                <div class="flex items-end gap-1">
                    <span class="text-7xl font-black leading-none">${currentChild.classRank}</span>
                    <span class="text-2xl font-bold opacity-60 mb-2">/${currentChild.totalInClass}</span>
                </div>
                <p class="text-teal-100 text-sm mt-4 font-medium italic opacity-80">"يتنافس مع ألمع الطلاب في فصله"</p>
                <div class="mt-8 h-2 bg-white/20 rounded-full overflow-hidden">
                    <div class="h-full bg-white shadow-lg" style="width: ${((currentChild.totalInClass - currentChild.classRank + 1) / currentChild.totalInClass) * 100}%"></div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Stars of the Class -->
            <div class="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                <div class="flex items-center justify-between mb-8">
                    <h3 class="font-black text-xl text-gray-800">🌟 نجوم الفصل</h3>
                    <span class="text-xs text-indigo-600 font-bold bg-indigo-50 px-3 py-1 rounded-full uppercase">أفضل الأداء</span>
                </div>
                <div class="space-y-4">
                    ${currentChild.classTop3.map((s, i) => `
                        <div class="flex items-center gap-4 p-4 rounded-2xl ${s.id == sid ? 'bg-indigo-600 text-white shadow-lg ring-4 ring-indigo-50' : 'bg-gray-50 hover:bg-white border border-transparent hover:border-gray-100 hover:shadow-md'} transition">
                            <div class="w-10 h-10 flex items-center justify-center text-2xl">${i === 0 ? '🥇' : i === 1 ? '🥈' : '🥉'}</div>
                            <div class="flex-1">
                                <p class="font-black text-sm">${esc(s.name)} ${s.id == sid ? '<span class="text-xs opacity-70">(ابنك)</span>' : ''}</p>
                                <p class="text-[10px] ${s.id == sid ? 'text-indigo-200' : 'text-gray-400'} font-bold uppercase tracking-wider">متوسط الدرجات</p>
                            </div>
                            <span class="text-xl font-black ${s.id == sid ? 'text-white' : 'text-indigo-600'}">${s.avg_score}</span>
                        </div>
                    `).join('')}
                </div>
                <div class="mt-8 p-4 bg-yellow-50 rounded-2xl border border-yellow-100 flex items-center gap-3">
                    <span class="text-2xl">💡</span>
                    <p class="text-xs text-yellow-800 leading-relaxed font-medium">كلما شارك الطالب في المزيد من اختبارات اللياقة، زادت فرصته في الحصول على مركز أفضل.</p>
                </div>
            </div>

            <!-- Global Context (Mini Ranking) -->
            <div class="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                <h3 class="font-black text-xl text-gray-800 mb-8">🏫 وضع الفصل في المدرسة</h3>
                <div class="space-y-4">
                    ${classRanking.slice(0, 5).map((c, i) => `
                        <div class="flex items-center gap-4 p-4 rounded-2xl ${currentChild.classId == c.class_id ? 'bg-orange-600 text-white shadow-lg ring-4 ring-orange-100' : 'bg-gray-50'}">
                            <span class="w-8 h-8 rounded-lg flex items-center justify-center font-black ${currentChild.classId == c.class_id ? 'bg-white text-orange-600' : 'bg-gray-200 text-gray-500'} text-xs font-bold">${i + 1}</span>
                            <div class="flex-1">
                                <p class="font-black text-sm">${esc(c.full_class_name)} ${currentChild.classId == c.class_id ? '<span class="text-xs opacity-70">(فصل ابنك)</span>' : ''}</p>
                            </div>
                            <span class="font-black">${c.points} <span class="text-[10px] opacity-70">نقطة</span></span>
                        </div>
                    `).join('')}
                    <div class="pt-4 border-t border-gray-50 flex justify-center">
                        <p class="text-gray-400 text-[10px] font-bold uppercase tracking-widest italic">تم التحديث مؤخراً بناءً على متوسط الدرجات</p>
                    </div>
                </div>
            </div>
        </div>
        ` : `
        <div class="p-12 text-center bg-white rounded-3xl border-2 border-dashed border-gray-100 min-h-[400px] flex flex-col items-center justify-center">
            <div class="text-6xl mb-4">📈</div>
            <p class="text-gray-400 font-bold">يرجى اختيار أحد الأبناء أعلاه لعرض بياناته التنافسية</p>
        </div>`}
    </div>`;
}
