/**
 * PE Smart School System - Students Page
 */

let studentFilter = { grade_id: '', class_id: '', search: '' };

async function renderStudents() {
    const mc = document.getElementById('mainContent');
    mc.innerHTML = showLoading();

    const [gr, cl, st] = await Promise.all([
        API.get('grades'),
        API.get('classes', { grade_id: studentFilter.grade_id }),
        API.get('students', studentFilter)
    ]);

    if (!st || !st.success) {
        mc.innerHTML = `
        <div class="fade-in text-center py-12">
            <p class="text-5xl mb-4">⚠️</p>
            <p class="text-red-600 text-xl font-bold mb-2">خطأ في تحميل بيانات الطلاب</p>
            <p class="text-gray-500 mb-1">${esc(st?.error || 'تحقق من الاتصال بقاعدة البيانات')}</p>
            <p class="text-gray-400 text-sm mb-6">تأكد من تشغيل <strong>install.php</strong> لإنشاء الجداول المطلوبة</p>
            <div class="flex gap-3 justify-center">
                <button onclick="renderStudents()" class="bg-green-600 text-white px-6 py-3 rounded-xl font-semibold cursor-pointer hover:bg-green-700">🔄 إعادة المحاولة</button>
                <a href="install.php" target="_blank" class="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700">🔧 تشغيل المثبّت</a>
            </div>
        </div>`;
        return;
    }

    const grades = gr?.data || [];
    const classes = cl?.data || [];
    const students = st?.data || [];

    mc.innerHTML = `
    <div class="fade-in px-4 md:px-0">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
                <h2 class="text-2xl md:text-3xl font-black text-gray-800">👨‍🎓 الطلاب</h2>
                <p class="text-gray-500 font-bold tracking-tight">(${students.length} طالب مسجل)</p>
            </div>
            <div class="flex flex-wrap gap-2">
                ${canEdit() ? `
                <button onclick="showStudentForm()" class="flex-1 md:flex-none bg-green-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-green-700 transition shadow-lg shadow-green-100 cursor-pointer text-sm">+ طالب جديد</button>
                <button onclick="showImportModal()" class="flex-1 md:flex-none bg-blue-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-blue-700 transition shadow-lg shadow-blue-100 cursor-pointer text-sm">📥 استيراد</button>
                ` : ''}
                <div class="flex gap-2 w-full md:w-auto">
                    <button onclick="downloadTemplate(false)" class="flex-1 md:flex-none bg-white border border-gray-200 text-gray-700 px-4 py-2.5 rounded-xl font-bold hover:bg-gray-50 transition cursor-pointer text-sm">📄 القالب</button>
                    ${students.length > 0 ? `<button onclick="downloadTemplate(true)" class="flex-1 md:flex-none bg-purple-50 text-purple-700 border border-purple-100 px-4 py-2.5 rounded-xl font-bold hover:bg-purple-100 transition cursor-pointer text-sm">📤 تصدير</button>` : ''}
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="bg-gray-50/50 backdrop-blur-sm rounded-[2rem] p-4 mb-6 flex flex-col md:flex-row gap-3 border border-gray-100">
            <div class="grid grid-cols-2 md:contents gap-2">
                <select onchange="studentFilter.grade_id=this.value;studentFilter.class_id='';renderStudents()" class="bg-white px-4 py-3 border-2 border-gray-100 rounded-2xl focus:border-green-500 focus:outline-none font-bold text-gray-700 shadow-sm">
                    <option value="">كل الصفوف</option>
                    ${grades.map(g => `<option value="${g.id}" ${studentFilter.grade_id == g.id ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}
                </select>
                <select onchange="studentFilter.class_id=this.value;renderStudents()" class="bg-white px-4 py-3 border-2 border-gray-100 rounded-2xl focus:border-green-500 focus:outline-none font-bold text-gray-700 shadow-sm">
                    <option value="">كل الفصول</option>
                    ${classes.map(c => `<option value="${c.id}" ${studentFilter.class_id == c.id ? 'selected' : ''}>${esc(c.full_name || c.name)}</option>`).join('')}
                </select>
            </div>
            <div class="relative flex-1">
                <span class="absolute right-4 top-1/2 -translate-y-1/2 grayscale">🔍</span>
                <input type="text" onkeyup="studentFilter.search=this.value;clearTimeout(window._st);window._st=setTimeout(()=>renderStudents(),400)" value="${studentFilter.search}" class="w-full bg-white pr-10 pl-4 py-3 border-2 border-gray-100 rounded-2xl focus:border-green-500 focus:outline-none font-bold shadow-sm" placeholder="بحث باسم الطالب أو رقم القيد...">
            </div>
        </div>

        <!-- Desktop View (Table) -->
        <div class="hidden lg:block bg-white rounded-3xl shadow-xl shadow-gray-100/50 border border-gray-100 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50/50 border-b border-gray-100">
                            <th class="px-4 py-4 text-right text-xs font-black text-gray-400 uppercase tracking-widest">#</th>
                            <th class="px-4 py-4 text-right text-xs font-black text-gray-400 uppercase tracking-widest">الرقم</th>
                            <th class="px-4 py-4 text-right text-xs font-black text-gray-400 uppercase tracking-widest">اسم الطالب</th>
                            <th class="px-4 py-4 text-right text-xs font-black text-gray-400 uppercase tracking-widest">الفصل الدراسي</th>
                            <th class="px-4 py-4 text-center text-xs font-black text-gray-400 uppercase tracking-widest">العمر</th>
                            <th class="px-4 py-4 text-center text-xs font-black text-gray-400 uppercase tracking-widest">الفصيلة</th>
                            <th class="px-4 py-4 text-center text-xs font-black text-gray-400 uppercase tracking-widest">الحالة</th>
                            <th class="px-4 py-4 text-center text-xs font-black text-gray-400 uppercase tracking-widest">الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${students.map((s, i) => `
                        <tr class="border-t border-gray-50 hover:bg-green-50/30 transition-colors group">
                            <td class="px-4 py-4 text-sm text-gray-400 font-bold">${i + 1}</td>
                            <td class="px-4 py-4 text-sm font-mono font-bold text-gray-500">${esc(s.student_number)}</td>
                            <td class="px-4 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center text-xl group-hover:bg-green-100 transition-colors">👦</div>
                                    <span class="font-bold text-gray-800">${esc(s.name)}</span>
                                </div>
                            </td>
                            <td class="px-4 py-4"><span class="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-black">${esc(s.full_class_name)}</span></td>
                            <td class="px-4 py-4 text-center text-sm font-bold text-gray-600">${s.age || calcAge(s.date_of_birth)} سنة</td>
                            <td class="px-4 py-4 text-center"><span class="px-2 py-1 bg-purple-50 text-purple-700 rounded-lg text-xs font-black">${s.blood_type || '-'}</span></td>
                            <td class="px-4 py-4 text-center">${s.health_alerts > 0 ? `<span class="px-3 py-1 bg-red-50 text-red-600 rounded-full text-xs font-black">⚠️ ${s.health_alerts}</span>` : '<span class="text-green-500 font-bold">● مستقر</span>'}</td>
                            <td class="px-4 py-4 text-center">
                                <div class="flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onclick="window._profileStudentId=${s.id};navigateTo('studentProfile')" class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center hover:bg-indigo-600 hover:text-white transition cursor-pointer" title="ملف الطالب">👤</button>
                                    ${canEdit() ? `
                                    <button onclick="showStudentForm(${s.id})" class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition cursor-pointer" title="تعديل">✏️</button>
                                    <button onclick="deleteStudent(${s.id})" class="w-8 h-8 rounded-lg bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition cursor-pointer" title="حذف">🗑️</button>
                                    ` : ''}
                                </div>
                            </td>
                        </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Mobile/Tablet View (Cards) -->
        <div class="lg:hidden grid grid-cols-1 md:grid-cols-2 gap-4">
            ${students.map(s => `
            <div class="bg-white rounded-3xl p-5 border border-gray-100 shadow-sm relative group active:scale-95 transition-transform">
                <div class="flex items-start justify-between mb-4">
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-green-50 to-emerald-50 text-2xl flex items-center justify-center text-white shadow-inner">👦</div>
                        <div>
                            <h3 class="font-black text-gray-800">${esc(s.name)}</h3>
                            <p class="text-xs text-gray-400 font-bold font-mono tracking-tighter">ID: ${esc(s.student_number)} • ${esc(s.full_class_name)}</p>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-2 mb-4">
                    <div class="bg-gray-50 rounded-2xl p-2 text-center">
                        <p class="text-[9px] text-gray-400 font-black uppercase mb-1">العمر</p>
                        <p class="font-black text-gray-700 text-sm">${s.age || calcAge(s.date_of_birth)}</p>
                    </div>
                    <div class="bg-gray-50 rounded-2xl p-2 text-center">
                        <p class="text-[9px] text-gray-400 font-black uppercase mb-1">الفصيلة</p>
                        <p class="font-black text-purple-700 text-sm">${s.blood_type || '-'}</p>
                    </div>
                    <div class="bg-gray-50 rounded-2xl p-2 text-center">
                        <p class="text-[9px] text-gray-400 font-black uppercase mb-1">الحالة</p>
                        <p class="font-black ${s.health_alerts > 0 ? 'text-red-500' : 'text-green-500'} text-sm">${s.health_alerts > 0 ? '⚠️' : '✅'}</p>
                    </div>
                </div>

                <div class="flex gap-2">
                    <button onclick="window._profileStudentId=${s.id};navigateTo('studentProfile')" class="flex-1 py-3 bg-indigo-50 text-indigo-700 rounded-2xl font-black text-xs hover:bg-indigo-600 hover:text-white transition">استعراض الملف</button>
                    ${canEdit() ? `
                    <button onclick="showStudentForm(${s.id})" class="w-12 h-12 flex items-center justify-center bg-gray-50 text-emerald-600 rounded-2xl hover:bg-emerald-600 hover:text-white transition">✏️</button>
                    <button onclick="deleteStudent(${s.id})" class="w-12 h-12 flex items-center justify-center bg-gray-50 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition">🗑️</button>
                    ` : ''}
                </div>
            </div>
            `).join('')}
        </div>

        ${students.length === 0 ? `
        <div class="text-center py-20 bg-white rounded-3xl border border-dashed border-gray-200">
            <p class="text-6xl mb-4 grayscale opacity-20">🔎</p>
            <p class="text-gray-400 font-bold">عذراً، لم يتم العثور على أي طلاب مطابقين للبحث</p>
        </div>` : ''}
    </div>`;
}

// Student Form
async function showStudentForm(id = null) {
    const [gr, cl] = await Promise.all([
        API.get('grades'),
        API.get('classes')
    ]);

    const grades = gr?.data || [];
    const allClasses = cl?.data || [];

    let student = null;
    if (id) {
        const r = await API.get('students', { search: '' });
        student = (r?.data || []).find(s => s.id == id);
    }

    const selectedGrade = student ? student.grade_id : (grades[0]?.id || '');
    const filteredClasses = allClasses.filter(c => c.grade_id == selectedGrade);
    window._allClasses = allClasses;

    showModal(`
        <div class="p-6">
            <h3 class="text-xl font-bold mb-4">${student ? 'تعديل' : 'إضافة'} طالب</h3>
            <div class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">اسم الطالب *</label>
                        <input type="text" id="studentName" value="${student ? esc(student.name) : ''}" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">رقم الطالب *</label>
                        <input type="text" id="studentNumber" value="${student ? esc(student.student_number) : ''}" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">الصف</label>
                        <select id="studentGrade" onchange="updateStudentClasses()" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">
                            ${grades.map(g => `<option value="${g.id}" ${selectedGrade == g.id ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">الفصل</label>
                        <select id="studentClass" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">
                            ${filteredClasses.map(c => `<option value="${c.id}" ${student && student.class_id == c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
                        </select>
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">تاريخ الميلاد</label>
                        <input type="date" id="studentDOB" value="${student?.date_of_birth || ''}" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">فصيلة الدم</label>
                        <select id="studentBlood" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">
                            <option value="">اختر</option>
                            ${BLOOD_TYPES.map(b => `<option value="${b}" ${student?.blood_type === b ? 'selected' : ''}>${b}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">رقم ولي الأمر</label>
                        <input type="tel" id="studentGuardian" value="${student?.guardian_phone || ''}" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none" placeholder="05XXXXXXXX">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">ملاحظات طبية</label>
                    <textarea id="studentMedical" rows="2" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">${student?.medical_notes || ''}</textarea>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">كلمة مرور بوابة الطالب ${student ? '<span class="text-xs text-gray-400">(اتركها فارغة لعدم التغيير)</span>' : ''}</label>
                    <input type="password" id="studentPassword" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none" placeholder="${student ? '••••••••' : 'اسم الطالب هو رقم هويته'}">
                </div>
                <div class="flex gap-3 pt-2">
                    <button onclick="saveStudent(${id || 'null'})" class="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold hover:bg-green-700 cursor-pointer">حفظ</button>
                    <button onclick="closeModal()" class="flex-1 bg-gray-200 text-gray-700 py-3 rounded-xl font-bold hover:bg-gray-300 cursor-pointer">إلغاء</button>
                </div>
            </div>
        </div>
    `);
}

function updateStudentClasses() {
    const gradeId = document.getElementById('studentGrade').value;
    const filtered = (window._allClasses || []).filter(c => c.grade_id == gradeId);
    document.getElementById('studentClass').innerHTML = filtered.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
}

async function saveStudent(id) {
    const data = {
        id,
        name: document.getElementById('studentName').value.trim(),
        student_number: document.getElementById('studentNumber').value.trim(),
        class_id: document.getElementById('studentClass').value,
        date_of_birth: document.getElementById('studentDOB').value,
        blood_type: document.getElementById('studentBlood').value,
        guardian_phone: document.getElementById('studentGuardian').value.trim(),
        medical_notes: document.getElementById('studentMedical').value.trim(),
        password: document.getElementById('studentPassword').value
    };

    if (!data.name || !data.student_number) {
        showToast('أكمل الحقول المطلوبة', 'error');
        return;
    }

    if (!data.class_id) {
        showToast('اختر الفصل', 'error');
        return;
    }

    const r = await API.post('student_save', data);
    if (r && r.success) {
        closeModal();
        showToast(r.message);
        renderStudents();
    } else {
        showToast(r?.error || 'خطأ في حفظ الطالب', 'error');
    }
}

async function deleteStudent(id) {
    if (!confirm('حذف الطالب؟')) return;
    const r = await API.post('student_delete', null, { id });
    if (r && r.success) {
        showToast(r.message);
        renderStudents();
    }
}

// ============================================================
// IMPORT / EXPORT STUDENTS
// ============================================================

/**
 * Download CSV Template
 */
function downloadTemplate(withData = false) {
    const classId = studentFilter.class_id || '';
    let url = `api.php?action=students_template&with_data=${withData ? '1' : '0'}`;
    if (classId) url += `&class_id=${classId}`;

    // Open download in new tab
    window.open(url, '_blank');

    if (!withData) {
        showToast('جاري تحميل القالب... افتحه في Excel واملأ البيانات', 'info');
    } else {
        showToast('جاري تصدير بيانات الطلاب...', 'info');
    }
}

/**
 * Show Import Modal
 */
async function showImportModal() {
    const cl = await API.get('classes');
    const classes = cl?.data || [];

    showModal(`
        <div class="p-6">
            <h3 class="text-xl font-bold mb-4">📥 استيراد الطلاب من ملف Excel/CSV</h3>
            
            <!-- Instructions -->
            <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-4">
                <h4 class="font-bold text-blue-800 mb-2">📋 التعليمات:</h4>
                <ol class="text-sm text-blue-700 space-y-1 list-decimal mr-5">
                    <li>حمّل <button onclick="downloadTemplate(false)" class="text-blue-600 underline font-bold cursor-pointer">القالب الفارغ</button> أولاً</li>
                    <li>افتحه في Excel واملأ بيانات الطلاب</li>
                    <li>احفظ الملف بصيغة <strong>CSV UTF-8</strong> (ملف ← حفظ باسم ← CSV UTF-8)</li>
                    <li>ارفع الملف هنا</li>
                </ol>
            </div>
            
            <!-- Required Columns -->
            <div class="bg-gray-50 border border-gray-200 rounded-xl p-4 mb-4">
                <h4 class="font-bold text-gray-700 mb-2">📊 الأعمدة المطلوبة:</h4>
                <div class="grid grid-cols-2 gap-2 text-sm">
                    <div class="flex items-center gap-1">
                        <span class="text-red-500 font-bold">*</span>
                        <span class="font-semibold">اسم الطالب</span>
                        <span class="text-gray-400">(إجباري)</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-red-500 font-bold">*</span>
                        <span class="font-semibold">رقم الطالب</span>
                        <span class="text-gray-400">(إجباري)</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-blue-500">○</span>
                        <span>رمز الصف</span>
                        <span class="text-gray-400">(1, 2, 3)</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-blue-500">○</span>
                        <span>رقم الفصل</span>
                        <span class="text-gray-400">(1, 2, 3)</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-blue-500">○</span>
                        <span>تاريخ الميلاد</span>
                        <span class="text-gray-400">(YYYY-MM-DD)</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-blue-500">○</span>
                        <span>فصيلة الدم</span>
                        <span class="text-gray-400">(A+, B-, O+...)</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-blue-500">○</span>
                        <span>رقم ولي الأمر</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-blue-500">○</span>
                        <span>ملاحظات طبية</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <span class="text-blue-500">○</span>
                        <span class="font-bold">كلمة المرور</span>
                        <span class="text-gray-400 text-[10px]">(اختياري - الافتراضي: رقم الطالب)</span>
                    </div>
                </div>
            </div>
            
            <!-- Default Class (if not in file) -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-gray-700 mb-1">الفصل الافتراضي <span class="text-gray-400 font-normal">(إذا لم يُحدد في الملف)</span></label>
                <select id="importDefaultClass" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none">
                    <option value="">اختر الفصل</option>
                    ${classes.map(c => `<option value="${c.id}">${esc(c.full_name || c.name)}</option>`).join('')}
                </select>
            </div>
            
            <!-- File Upload -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-gray-700 mb-1">اختر ملف CSV</label>
                <div id="dropZone" class="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-green-400 hover:bg-green-50 transition cursor-pointer"
                     onclick="document.getElementById('importFile').click()"
                     ondragover="event.preventDefault();this.classList.add('border-green-500','bg-green-50')"
                     ondragleave="this.classList.remove('border-green-500','bg-green-50')"
                     ondrop="event.preventDefault();this.classList.remove('border-green-500','bg-green-50');handleFileDrop(event)">
                    <span class="text-4xl block mb-2">📂</span>
                    <p class="text-gray-500 font-semibold">اسحب الملف هنا أو اضغط لاختياره</p>
                    <p class="text-gray-400 text-sm mt-1">CSV أو TXT (محفوظ من Excel)</p>
                    <p id="selectedFileName" class="text-green-600 font-bold mt-2 hidden"></p>
                </div>
                <input type="file" id="importFile" accept=".csv,.txt" class="hidden" onchange="handleFileSelect(this)">
            </div>
            
            <!-- Import Result -->
            <div id="importResult" class="hidden mb-4"></div>
            
            <!-- Buttons -->
            <div class="flex gap-3 pt-2">
                <button onclick="executeImport()" id="importBtn" class="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold hover:bg-green-700 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                    📥 استيراد
                </button>
                <button onclick="closeModal()" class="flex-1 bg-gray-200 text-gray-700 py-3 rounded-xl font-bold hover:bg-gray-300 cursor-pointer">إلغاء</button>
            </div>
        </div>
    `);
}

/**
 * Handle file selection
 */
function handleFileSelect(input) {
    const file = input.files[0];
    if (file) {
        showSelectedFile(file);
    }
}

/**
 * Handle file drop
 */
function handleFileDrop(event) {
    const file = event.dataTransfer.files[0];
    if (file) {
        // Set file to input
        const input = document.getElementById('importFile');
        const dt = new DataTransfer();
        dt.items.add(file);
        input.files = dt.files;
        showSelectedFile(file);
    }
}

/**
 * Show selected file name
 */
function showSelectedFile(file) {
    const nameEl = document.getElementById('selectedFileName');
    const btn = document.getElementById('importBtn');
    const ext = file.name.split('.').pop().toLowerCase();

    if (!['csv', 'txt'].includes(ext)) {
        nameEl.textContent = '❌ صيغة غير مدعومة! استخدم CSV أو TXT';
        nameEl.className = 'text-red-600 font-bold mt-2';
        nameEl.classList.remove('hidden');
        btn.disabled = true;
        return;
    }

    const sizeMB = (file.size / 1024 / 1024).toFixed(2);
    nameEl.textContent = `✅ ${file.name} (${sizeMB} MB)`;
    nameEl.className = 'text-green-600 font-bold mt-2';
    nameEl.classList.remove('hidden');
    btn.disabled = false;
}

/**
 * Execute Import
 */
async function executeImport() {
    const fileInput = document.getElementById('importFile');
    const defaultClass = document.getElementById('importDefaultClass')?.value || '';
    const resultDiv = document.getElementById('importResult');
    const btn = document.getElementById('importBtn');

    if (!fileInput.files[0]) {
        showToast('اختر ملف أولاً', 'error');
        return;
    }

    // Check if class is selected when no grade/section in file
    if (!defaultClass) {
        if (!confirm('لم تختر فصلاً افتراضياً. إذا كان الملف لا يحتوي على أعمدة "رمز الصف" و"رقم الفصل"، سيتم تخطي الطلاب. هل تريد المتابعة؟')) {
            return;
        }
    }

    // Show loading
    btn.disabled = true;
    btn.innerHTML = '<span class="inline-block animate-spin">⏳</span> جاري الاستيراد...';
    resultDiv.classList.add('hidden');

    // Build FormData
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    if (defaultClass) formData.append('default_class_id', defaultClass);

    try {
        const response = await fetch(`api.php?action=students_import`, {
            method: 'POST',
            body: formData
        });

        const r = await response.json();

        if (r.success) {
            const d = r.data;
            let html = `
                <div class="bg-green-50 border border-green-200 rounded-xl p-4">
                    <h4 class="font-bold text-green-800 mb-2">✅ ${esc(r.message)}</h4>
                    <div class="grid grid-cols-3 gap-3 text-center mb-3">
                        <div class="bg-white rounded-lg p-2">
                            <p class="text-2xl font-bold text-green-600">${d.imported}</p>
                            <p class="text-xs text-gray-500">طالب جديد</p>
                        </div>
                        <div class="bg-white rounded-lg p-2">
                            <p class="text-2xl font-bold text-blue-600">${d.updated}</p>
                            <p class="text-xs text-gray-500">تم تحديثه</p>
                        </div>
                        <div class="bg-white rounded-lg p-2">
                            <p class="text-2xl font-bold text-red-600">${d.skipped}</p>
                            <p class="text-xs text-gray-500">تم تخطيه</p>
                        </div>
                    </div>`;

            if (d.errors && d.errors.length > 0) {
                html += `
                    <div class="mt-2">
                        <p class="text-sm font-semibold text-red-700 mb-1">⚠️ أخطاء:</p>
                        <div class="max-h-32 overflow-y-auto bg-white rounded-lg p-2 text-xs text-red-600 space-y-1">
                            ${d.errors.map(e => `<p>• ${esc(e)}</p>`).join('')}
                        </div>
                    </div>`;
            }

            html += '</div>';
            resultDiv.innerHTML = html;
            resultDiv.classList.remove('hidden');

            showToast(r.message);

            // Refresh students list after 1 second
            setTimeout(() => renderStudents(), 1000);
        } else {
            resultDiv.innerHTML = `
                <div class="bg-red-50 border border-red-200 rounded-xl p-4">
                    <p class="font-bold text-red-800">❌ ${esc(r.error)}</p>
                </div>`;
            resultDiv.classList.remove('hidden');
            showToast(r.error, 'error');
        }
    } catch (e) {
        resultDiv.innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-xl p-4">
                <p class="font-bold text-red-800">❌ خطأ في الاتصال: ${esc(e.message)}</p>
            </div>`;
        resultDiv.classList.remove('hidden');
        showToast('خطأ في الاتصال', 'error');
    }

    // Reset button
    btn.disabled = false;
    btn.innerHTML = '📥 استيراد';
}
