/**
 * PE Smart School System - Reports Page
 */

let reportType = 'student';

async function renderReports() {
    if (currentUser && currentUser.role === 'student') {
        document.getElementById('mainContent').innerHTML = `
        <div class="fade-in">
            <div class="mb-6">
                <h2 class="text-2xl font-bold text-gray-800">📈 تقريري</h2>
                <p class="text-gray-500 mt-1">تقرير اللياقة البدنية والنتائج الشخصية</p>
            </div>
            <div id="reportContent">${showLoading()}</div>
            <div id="reportOutput"></div>
        </div>`;

        // Load personal report directly
        const r = await API.get('report_student', { student_id: currentUser.id });
        if (r && r.success) {
            renderStudentReportDirect(r.data);
        } else {
            document.getElementById('reportContent').innerHTML = '<p class="text-red-500 text-center py-8">خطأ في تحميل التقرير</p>';
        }
        return;
    }

    if (currentUser && currentUser.role === 'parent') {
        const mc = document.getElementById('mainContent');
        mc.innerHTML = `
        <div class="fade-in max-w-6xl mx-auto">
            <div class="mb-8">
                <h2 class="text-3xl font-black text-gray-800">📊 تقارير الأداء البدني</h2>
                <p class="text-gray-500 mt-2">استعرض التقارير التفصيلية والنمو البدني لأبنائك</p>
            </div>
            
            <div id="parentChildrenCards" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10 no-print">
                <!-- Data loaded via API -->
                ${showLoading()}
            </div>

            <div id="reportOutput" class="space-y-8"></div>
        </div>`;

        // Load linked students
        const r = await API.get('parent_dashboard');
        const container = document.getElementById('parentChildrenCards');

        if (r && r.success && r.data) {
            const children = r.data;
            if (children.length === 0) {
                container.innerHTML = '<div class="col-span-full py-12 text-center text-gray-400 font-bold bg-white rounded-3xl border-2 border-dashed">لم يتم العثور على أبناء مربوطين بالحساب</div>';
            } else {
                container.innerHTML = children.map(s => `
                    <div onclick="generateParentStudentReport(${s.id})" class="child-report-card bg-white p-6 rounded-3xl border border-gray-100 shadow-sm cursor-pointer transition hover:shadow-xl hover:scale-[1.02] group" data-student-id="${s.id}">
                        <div class="flex items-center gap-4">
                            <div class="w-14 h-14 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center text-3xl transition group-hover:bg-green-600 group-hover:text-white">👦</div>
                            <div class="flex-1">
                                <h4 class="font-black text-gray-800 group-hover:text-green-700 transition">${esc(s.name)}</h4>
                                <p class="text-xs text-gray-400 font-bold uppercase">${esc(s.full_class_name)}</p>
                            </div>
                        </div>
                    </div>
                `).join('');

                // Auto-generate for the first child
                generateParentStudentReport(children[0].id);
            }
        } else {
            container.innerHTML = '<div class="col-span-full py-12 text-center text-red-500 font-bold">فشل في جلب بيانات الأبناء</div>';
        }
        return;
    }

    document.getElementById('mainContent').innerHTML = `
    <div class="fade-in px-4 md:px-0">
        <div class="mb-8">
            <h2 class="text-3xl font-black text-gray-800">📊 مركز التقارير والذكاء الرياضي</h2>
            <p class="text-gray-500 font-bold mt-2">تحليل البيانات البدنية واستخراج تقارير الأداء المتقدمة</p>
        </div>
        
        <div class="flex overflow-x-auto gap-2 mb-8 no-print scrollbar-hide pb-2">
            <button onclick="reportType='student';renderReports()" class="whitespace-nowrap px-8 py-3 rounded-2xl font-black transition-all duration-300 ${reportType === 'student' ? 'bg-emerald-600 text-white shadow-xl shadow-emerald-100 scale-105' : 'bg-white text-gray-400 border border-gray-100 hover:text-gray-600'} cursor-pointer">📄 تقرير الطالب الفردي</button>
            <button onclick="reportType='class';renderReports()" class="whitespace-nowrap px-8 py-3 rounded-2xl font-black transition-all duration-300 ${reportType === 'class' ? 'bg-green-600 text-white shadow-xl shadow-green-100 scale-105' : 'bg-white text-gray-400 border border-gray-100 hover:text-gray-600'} cursor-pointer">🏫 تقرير الفصل التعليمي</button>
            <button onclick="reportType='compare';renderReports()" class="whitespace-nowrap px-8 py-3 rounded-2xl font-black transition-all duration-300 ${reportType === 'compare' ? 'bg-teal-600 text-white shadow-xl shadow-teal-100 scale-105' : 'bg-white text-gray-400 border border-gray-100 hover:text-gray-600'} cursor-pointer">⚖️ لوحة مقارنة الأداء</button>
        </div>
        
        <div id="reportContent" class="mb-12">${showLoading()}</div>
    </div>`;

    if (reportType === 'student') renderStudentReport();
    else if (reportType === 'class') renderClassReport();
    else renderCompareReport();
}

function renderStudentReportDirect(data) {
    document.getElementById('reportContent').innerHTML = `
    <div class="flex justify-end mb-4 no-print">
        <button onclick="window.print()" class="bg-blue-600 text-white px-6 py-2 rounded-xl font-semibold hover:bg-blue-700 cursor-pointer flex items-center gap-2">
            <span>🖨️ طباعة التقرير</span>
        </button>
    </div>`;

    // Use existing generator logic but inject data directly
    const reportOutput = document.getElementById('reportOutput');
    renderStudentReportHTML(data, reportOutput);
}

async function renderStudentReport() {
    const cl = await API.get('classes');

    document.getElementById('reportContent').innerHTML = `
    <div class="fade-in">
        <div class="bg-white rounded-[2.5rem] shadow-xl shadow-gray-100/50 border border-gray-100 p-6 md:p-8 mb-10 no-print">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                <div class="space-y-2">
                    <label class="block text-xs font-black text-gray-400 uppercase tracking-widest mr-2">اختيار الفصل</label>
                    <select id="reportClass" onchange="updateReportStudents()" class="w-full px-6 py-4 bg-gray-50 border-2 border-gray-50 rounded-[1.5rem] focus:bg-white focus:border-blue-500 focus:outline-none transition-all font-bold text-gray-700 appearance-none cursor-pointer">
                        <option value="">-- اضغط للاختيار --</option>
                        ${(cl?.data || []).map(c => `<option value="${c.id}">${esc(c.full_name || c.name)}</option>`).join('')}
                    </select>
                </div>
                <div class="space-y-2">
                    <label class="block text-xs font-black text-gray-400 uppercase tracking-widest mr-2">اختيار الطالب</label>
                    <select id="reportStudent" class="w-full px-6 py-4 bg-gray-50 border-2 border-gray-50 rounded-[1.5rem] focus:bg-white focus:border-emerald-500 focus:outline-none transition-all font-bold text-gray-700 appearance-none cursor-pointer">
                        <option value="">-- اختر الفصل أولاً --</option>
                    </select>
                </div>
                <div class="pt-2">
                    <button onclick="generateStudentReport()" class="w-full bg-emerald-600 text-white px-8 py-4 rounded-[1.5rem] font-black hover:bg-emerald-700 transition shadow-xl shadow-emerald-100 flex items-center justify-center gap-3 active:scale-95">
                        <span class="text-xl">📄</span> عرض التقرير
                    </button>
                </div>
                <div class="pt-2">
                    <button onclick="window.print()" class="w-full bg-gray-900 text-white px-8 py-4 rounded-[1.5rem] font-black hover:bg-black transition shadow-xl shadow-gray-200 flex items-center justify-center gap-3 active:scale-95">
                        <span class="text-xl">🖨️</span> طباعة فورية
                    </button>
                </div>
            </div>
        </div>
        <div id="reportOutput" class="scroll-mt-20">
            <div class="text-center py-24 bg-white rounded-[3rem] border-2 border-dashed border-gray-100">
                <div class="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center text-4xl mx-auto mb-6 grayscale opacity-30">👤</div>
                <p class="text-gray-400 font-black text-xl">يرجى اختيار الطالب لاستعراض تقريره</p>
                <p class="text-gray-300 text-sm mt-1">التقارير تتضمن القياسات البدنية، اللياقة، والحضور</p>
            </div>
        </div>
    </div>`;
}

async function updateReportStudents() {
    const cid = document.getElementById('reportClass').value;
    if (!cid) return;

    const r = await API.get('students', { class_id: cid });
    document.getElementById('reportStudent').innerHTML = `<option value="">اختر</option>` +
        (r?.data || []).map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
}

async function generateStudentReport() {
    const sid = document.getElementById('reportStudent').value;
    if (!sid) {
        showToast('اختر طالب', 'error');
        return;
    }

    const r = await API.get('report_student', { student_id: sid });
    if (!r || !r.success) return;

    renderStudentReportHTML(r.data, document.getElementById('reportOutput'));
}

async function generateParentStudentReport(sid) {
    if (!sid) {
        const select = document.getElementById('parentStudentSelect');
        if (select) sid = select.value;
    }
    if (!sid) return;

    // Highlight selected card if it exists
    document.querySelectorAll('.child-report-card').forEach(el => {
        if (el.dataset.studentId == sid) {
            el.classList.add('ring-4', 'ring-green-500', 'bg-green-50', 'border-green-200');
            el.classList.remove('border-gray-100');
        } else {
            el.classList.remove('ring-4', 'ring-green-500', 'bg-green-50', 'border-green-200');
            el.classList.add('border-gray-100');
        }
    });

    const ro = document.getElementById('reportOutput');
    if (ro) ro.innerHTML = showLoading();

    const r = await API.get('report_student', { student_id: sid });
    if (r && r.success) {
        renderStudentReportHTML(r.data, ro);
    } else if (ro) {
        ro.innerHTML = '<p class="text-red-500 text-center py-8">خطأ في تحميل التقرير</p>';
    }
}

function renderStudentReportHTML(d, container) {
    const s = d.student;
    const m = d.measurement;
    const h = d.health || [];
    const att = d.attendance;

    container.innerHTML = `
    <div class="bg-white rounded-[2rem] shadow-2xl border border-gray-100 p-8 md:p-12 fade-in relative overflow-hidden">
        <!-- Decoration Decor -->
        <div class="absolute top-0 right-0 w-64 h-64 bg-green-50 rounded-full -mr-32 -mt-32 opacity-50"></div>
        
        <div class="relative z-10">
            <div class="print-only text-center mb-10 border-b-2 border-gray-100 pb-6">
                <h1 class="text-3xl font-black text-gray-900">🏃 PE Smart School System</h1>
                <p class="text-gray-500 font-bold uppercase tracking-widest mt-2">تقرير اللياقة البدنية الشامل</p>
            </div>

            <div class="flex flex-wrap justify-between items-start gap-6 mb-10 pb-8 border-b border-gray-50">
                <div class="flex items-center gap-6">
                    <div class="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-600 rounded-3xl flex items-center justify-center text-4xl text-white shadow-lg">👤</div>
                    <div>
                        <h3 class="text-3xl font-black text-gray-800">${esc(s.name)}</h3>
                        <p class="text-lg text-green-600 font-bold">${esc(s.full_class_name)}</p>
                        <div class="flex flex-wrap gap-2 mt-3">
                            <span class="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-xs font-bold">🆔 ${esc(s.student_number)}</span>
                            ${s.age ? `<span class="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-xs font-bold">🎂 ${s.age} سنة</span>` : ''}
                            ${s.blood_type ? `<span class="bg-purple-50 text-purple-600 px-3 py-1 rounded-full text-xs font-bold">🩸 ${s.blood_type}</span>` : ''}
                        </div>
                    </div>
                </div>
                <div class="bg-gray-900 text-white p-6 rounded-3xl text-center shadow-xl min-w-[140px]">
                    <p class="text-5xl font-black ${d.percentage >= 70 ? 'text-green-400' : d.percentage >= 50 ? 'text-yellow-400' : 'text-red-400'}">${d.percentage}%</p>
                    <p class="text-[10px] font-bold uppercase tracking-widest mt-2 opacity-60">التقييم العام</p>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
                <!-- Measurements -->
                <div class="lg:col-span-2">
                    <h4 class="font-black text-gray-800 mb-6 flex items-center gap-2 text-lg">
                        <span class="text-2xl text-blue-500">📏</span> القياسات الجسمية والنمو
                    </h4>
                    ${m ? `
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                        <div class="bg-blue-50/50 border border-blue-100 rounded-2xl p-4 text-center">
                            <p class="text-[10px] text-blue-400 font-black uppercase mb-1">الطول</p>
                            <p class="text-xl font-black text-blue-900">${m.height_cm} <span class="text-xs">سم</span></p>
                        </div>
                        <div class="bg-emerald-50/50 border border-emerald-100 rounded-2xl p-4 text-center">
                            <p class="text-[10px] text-emerald-400 font-black uppercase mb-1">الوزن</p>
                            <p class="text-xl font-black text-emerald-900">${m.weight_kg} <span class="text-xs">كجم</span></p>
                        </div>
                        <div class="rounded-2xl p-4 text-center border bmi-${m.bmi_category}-light">
                            <p class="text-[10px] font-black uppercase mb-1 opacity-60">BMI</p>
                            <p class="text-xl font-black">${m.bmi}</p>
                            <p class="text-[10px] font-bold mt-1 text-center">${BMI_AR[m.bmi_category] || ''}</p>
                        </div>
                        <div class="bg-orange-50/50 border border-orange-100 rounded-2xl p-4 text-center">
                            <p class="text-[10px] text-orange-400 font-black uppercase mb-1">النبض</p>
                            <p class="text-xl font-black text-orange-900">${m.resting_heart_rate || '-'} <span class="text-xs">ن/د</span></p>
                        </div>
                    </div>
                    ` : '<div class="p-6 bg-gray-50 rounded-2xl text-center text-gray-400 font-bold">لا يوجد بيانات قياسات حالية</div>'}
                </div>

                <!-- Health Status -->
                <div>
                    <h4 class="font-black text-gray-800 mb-6 flex items-center gap-2 text-lg">
                        <span class="text-2xl text-red-500">🏥</span> الحالة الصحية
                    </h4>
                    ${h.length > 0 ? `
                    <div class="space-y-3">
                        ${h.map(c => `
                        <div class="health-alert-mini rounded-2xl p-3 border border-red-100 bg-red-50/30">
                            <p class="font-bold text-gray-800 text-sm">${esc(c.condition_name)}</p>
                            <span class="badge severity-${c.severity} mt-1">${SEVERITY_AR[c.severity]}</span>
                        </div>
                        `).join('')}
                    </div>
                    ` : `
                    <div class="p-6 bg-green-50 rounded-2xl text-center">
                        <span class="text-3xl block mb-2">✅</span>
                        <p class="text-green-800 font-bold text-sm">الحالة الصحية مستقرة</p>
                    </div>`}
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
                <!-- Fitness Results -->
                <div>
                    <h4 class="font-black text-gray-800 mb-6 flex items-center gap-2 text-lg">
                        <span class="text-2xl text-indigo-500">💪</span> نتائج اختبارات اللياقة
                    </h4>
                    <div class="bg-gray-50 rounded-3xl overflow-hidden border border-gray-100">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="px-5 py-4 text-right text-xs font-black text-gray-400 uppercase tracking-widest">الاختبار</th>
                                    <th class="px-5 py-4 text-center text-xs font-black text-gray-400 uppercase tracking-widest">القيمة</th>
                                    <th class="px-5 py-4 text-center text-xs font-black text-gray-400 uppercase tracking-widest">الدرجة</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                ${d.fitness.map(f => `
                                <tr>
                                    <td class="px-5 py-4 font-bold text-gray-700 text-sm">${esc(f.test_name)}</td>
                                    <td class="px-5 py-4 text-center text-gray-600 font-medium">${f.value !== null ? f.value + ' <span class="text-[10px]">' + f.unit + '</span>' : '-'}</td>
                                    <td class="px-5 py-4 text-center font-black text-indigo-600">${f.score !== null ? f.score + '/' + f.max_score : '-'}</td>
                                </tr>
                                `).join('')}
                                <tr class="bg-indigo-50 font-black">
                                    <td class="px-5 py-4 text-indigo-900" colspan="2">إجمالي نقاط اللياقة</td>
                                    <td class="px-5 py-4 text-center text-xl text-indigo-700">${d.totalScore}/${d.totalMax}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Attendance -->
                <div class="flex flex-col">
                    <h4 class="font-black text-gray-800 mb-6 flex items-center gap-2 text-lg">
                        <span class="text-2xl text-orange-500">📋</span> إحصائيات الحضور والغياب
                    </h4>
                    <div class="bg-white border-2 border-gray-50 rounded-[2rem] p-8 flex-1 flex flex-col justify-center">
                        <div class="grid grid-cols-3 gap-6">
                            <div class="text-center group">
                                <div class="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center mx-auto mb-3 transition group-hover:scale-110 group-hover:bg-green-500 group-hover:text-white shadow-sm">
                                    <span class="text-2xl font-black">${att.present}</span>
                                </div>
                                <p class="text-[10px] font-black text-gray-400 uppercase tracking-widest">حضور</p>
                            </div>
                            <div class="text-center group">
                                <div class="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-3 transition group-hover:scale-110 group-hover:bg-red-500 group-hover:text-white shadow-sm">
                                    <span class="text-2xl font-black">${att.absent}</span>
                                </div>
                                <p class="text-[10px] font-black text-gray-400 uppercase tracking-widest">غياب</p>
                            </div>
                            <div class="text-center group">
                                <div class="w-16 h-16 bg-yellow-50 rounded-2xl flex items-center justify-center mx-auto mb-3 transition group-hover:scale-110 group-hover:bg-yellow-500 group-hover:text-white shadow-sm">
                                    <span class="text-2xl font-black">${att.late}</span>
                                </div>
                                <p class="text-[10px] font-black text-gray-400 uppercase tracking-widest">تأخر</p>
                            </div>
                        </div>
                        
                        <div class="mt-10">
                            <div class="flex justify-between text-xs font-black text-gray-400 uppercase mb-2">
                                <span>الانتظام الميداني</span>
                                <span>${att.present + att.absent + att.late > 0 ? Math.round(att.present / (att.present + att.absent + att.late) * 100) : 100}%</span>
                            </div>
                            <div class="h-4 bg-gray-100 rounded-full overflow-hidden flex shadow-inner">
                                <div class="bg-green-500 h-full shadow-lg" style="width:${att.present + att.absent + att.late > 0 ? (att.present / (att.present + att.absent + att.late) * 100) : 100}%"></div>
                                <div class="bg-yellow-400 h-full shadow-lg" style="width:${att.present + att.absent + att.late > 0 ? (att.late / (att.present + att.absent + att.late) * 100) : 0}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center text-[10px] text-gray-400 mt-12 pt-6 border-t border-gray-50 italic font-medium">
                تم استخراج هذا التقرير آلياً عبر نظام PE Smart School System - ${new Date().toLocaleDateString('ar-SA')}
            </div>
        </div>
    </div>`;
}

async function renderClassReport() {
    const cl = await API.get('classes');

    document.getElementById('reportContent').innerHTML = `
    <div class="fade-in">
        <div class="bg-white rounded-[2.5rem] shadow-xl shadow-gray-100/50 border border-gray-100 p-6 md:p-8 mb-10 no-print">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                <div class="space-y-2">
                    <label class="block text-xs font-black text-gray-400 uppercase tracking-widest mr-2">اختيار الفصل المستهدف</label>
                    <select id="classReportSelect" class="w-full px-6 py-4 bg-gray-50 border-2 border-gray-50 rounded-[1.5rem] focus:bg-white focus:border-green-500 focus:outline-none transition-all font-bold text-gray-700 appearance-none cursor-pointer">
                        <option value="">-- اضغط للاختيار --</option>
                        ${(cl?.data || []).map(c => `<option value="${c.id}">${esc(c.full_name || c.name)}</option>`).join('')}
                    </select>
                </div>
                <div class="pt-2">
                    <button onclick="generateClassReport()" class="w-full bg-green-600 text-white px-8 py-4 rounded-[1.5rem] font-black hover:bg-green-700 transition shadow-xl shadow-green-100 flex items-center justify-center gap-3 active:scale-95">
                        <span class="text-xl">🏫</span> عرض تقرير الفصل
                    </button>
                </div>
                <div class="pt-2">
                    <button onclick="window.print()" class="w-full bg-gray-900 text-white px-8 py-4 rounded-[1.5rem] font-black hover:bg-black transition shadow-xl shadow-gray-200 flex items-center justify-center gap-3 active:scale-95">
                        <span class="text-xl">🖨️</span> طباعة القائمة
                    </button>
                </div>
            </div>
        </div>
        <div id="reportOutput">
            <div class="text-center py-24 bg-white rounded-[3rem] border-2 border-dashed border-gray-100">
                <div class="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center text-4xl mx-auto mb-6 grayscale opacity-30">🏆</div>
                <p class="text-gray-400 font-black text-xl">يرجى اختيار الفصل لتحليل النتائج الجماعية</p>
                <p class="text-gray-300 text-sm mt-1">يستعرض هذا التقرير ترتيب الطلاب ومعدل أداء الفصل</p>
            </div>
        </div>
    </div>`;
}

async function generateClassReport() {
    const cid = document.getElementById('classReportSelect').value;
    if (!cid) {
        showToast('اختر فصل', 'error');
        return;
    }

    const r = await API.get('report_class', { class_id: cid });
    if (!r || !r.success) return;

    const d = r.data;

    document.getElementById('reportOutput').innerHTML = `
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <div class="print-only text-center mb-6 border-b pb-4">
            <h1 class="text-2xl font-bold">🏃 PE Smart School System</h1>
        </div>

        <div class="flex justify-between items-center mb-6 border-b pb-4">
            <div>
                <h3 class="text-xl font-bold">${esc(d.class.full_name)}</h3>
                <p class="text-gray-500">${d.totalStudents} طالب</p>
            </div>
            <div class="text-left">
                <p class="text-3xl font-black text-green-600">${d.classAverage}%</p>
            </div>
        </div>

        <table class="w-full">
            <thead>
                <tr class="bg-gray-50">
                    <th class="px-3 py-2 text-right text-sm font-bold">#</th>
                    <th class="px-3 py-2 text-right text-sm font-bold">الطالب</th>
                    <th class="px-3 py-2 text-center text-sm font-bold">الدرجة</th>
                    <th class="px-3 py-2 text-center text-sm font-bold">النسبة</th>
                    <th class="px-3 py-2 text-center text-sm font-bold">BMI</th>
                    <th class="px-3 py-2 text-center text-sm font-bold">صحة</th>
                    <th class="px-3 py-2 text-center text-sm font-bold">حضور</th>
                    <th class="px-3 py-2 text-center text-sm font-bold">غياب</th>
                </tr>
            </thead>
            <tbody>
                ${d.students.map((s, i) => `
                <tr class="border-t border-gray-100 ${i < 3 ? 'bg-green-50' : ''}">
                    <td class="px-3 py-2 text-sm">${i + 1} ${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : ''}</td>
                    <td class="px-3 py-2 font-semibold text-sm">${esc(s.name)}</td>
                    <td class="px-3 py-2 text-center text-sm font-bold">${s.total_score}/${s.total_max || 0}</td>
                    <td class="px-3 py-2 text-center"><span class="badge ${s.percentage >= 70 ? 'bg-green-100 text-green-700' : s.percentage >= 50 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}">${s.percentage}%</span></td>
                    <td class="px-3 py-2 text-center">${s.latest_bmi ? `<span class="badge bmi-${s.bmi_category || 'normal'}">${s.latest_bmi}</span>` : '-'}</td>
                    <td class="px-3 py-2 text-center">${s.health_alerts > 0 ? `<span class="badge severity-severe">⚠️ ${s.health_alerts}</span>` : '✅'}</td>
                    <td class="px-3 py-2 text-center text-sm text-green-600">${s.present_count}</td>
                    <td class="px-3 py-2 text-center text-sm text-red-600">${s.absent_count}</td>
                </tr>
                `).join('')}
            </tbody>
        </table>
    </div>`;
}

async function renderCompareReport() {
    const r = await API.get('report_compare');
    if (!r || !r.success) return;

    const classes = r.data;

    document.getElementById('reportContent').innerHTML = `
    <div class="fade-in">
        <div class="flex justify-end mb-8 no-print px-1">
            <button onclick="window.print()" class="bg-gray-900 text-white px-10 py-4 rounded-2xl font-black hover:bg-black transition shadow-xl flex items-center justify-center gap-3 active:scale-95">
                <span class="text-2xl">🖨️</span> طباعة اللوحة
            </button>
        </div>
        
        <div class="bg-white rounded-[3rem] shadow-2xl shadow-gray-200/50 border border-gray-100 p-8 md:p-12 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-64 h-64 bg-purple-50 rounded-full -mr-32 -mt-32 opacity-30"></div>
            
            <div class="relative z-10">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                    <div>
                        <h3 class="text-3xl font-black text-gray-800">⚖️ تحليل مقارنة الفصول</h3>
                        <p class="text-gray-400 font-bold mt-1">مؤشرات الأداء البدني لجميع الفصول التعليمية</p>
                    </div>
                    <div class="bg-green-50 px-6 py-2 rounded-2xl border border-green-100">
                        <span class="text-xs text-green-600 font-black uppercase tracking-widest block mb-1">إجمالي الفصول</span>
                        <span class="text-3xl font-black text-green-900">${classes.length}</span>
                    </div>
                </div>

                <div class="space-y-6">
                    ${classes.map((c, i) => `
                    <div class="group bg-gray-50/50 hover:bg-white hover:shadow-xl transition-all duration-300 p-6 rounded-[1.5rem] border border-transparent hover:border-green-100">
                        <div class="flex flex-col md:flex-row md:items-center gap-6">
                            <div class="w-12 h-12 rounded-2xl ${i < 3 ? 'bg-green-600 text-white shadow-lg' : 'bg-white text-gray-400'} font-black flex items-center justify-center text-lg flex-shrink-0 transition-transform group-hover:scale-110">
                                ${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1)}
                            </div>
                            
                            <div class="flex-1 w-full">
                                <div class="flex justify-between items-end mb-3">
                                    <div>
                                        <h5 class="font-black text-gray-800 text-lg">${esc(c.class_name)}</h5>
                                        <p class="text-[10px] text-gray-400 font-black uppercase tracking-tighter">${c.students_count} طالب مسجل</p>
                                    </div>
                                    <div class="text-right">
                                        <span class="text-2xl font-black text-green-600">${c.percentage}%</span>
                                    </div>
                                </div>
                                <div class="w-full bg-gray-200/50 rounded-full h-4 overflow-hidden shadow-inner ring-4 ring-white">
                                    <div class="h-full rounded-full transition-all duration-1000 ${i === 0 ? 'bg-gradient-to-l from-yellow-400 to-yellow-500' : i === 1 ? 'bg-gradient-to-l from-gray-300 to-gray-400' : 'bg-gradient-to-l from-green-500 to-green-600'}" style="width:${c.bar_width}%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    `).join('')}
                </div>
            </div>
        </div>
    </div>`;
}
